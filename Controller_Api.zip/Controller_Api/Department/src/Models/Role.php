<?php

namespace Modules\Department\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ModuleSection;
// use Modules\Department\Traits\HasPermissionsTrait;
use Modules\Department\Models\RoleHasPermission;
use App\Models\User;

class Role extends Model
{
    use HasFactory;
    protected $primaryKey = "roles_id";
    protected $guarded = [
        'roles_id',
    ];

    public function sections() {
        return $this->belongsToMany(ModuleSection::class,config('dbtable.common_role_has_permissions'),'roles_id', 'section_id');
    }

    public function permissionsTypeList() {

        return $this->hasMany(RoleHasPermission::class,'roles_id','roles_id');
    }

    // public function sections() {
    //    return $this->belongsToMany(ModuleSection::class,config('dbtable.usr_role_has_permissions'),'roles_id', 'section_id');
    // }

     public function users() {
       return $this->belongsToMany(User::class,config('dbtable.common_user_has_roles'), 'roles_id', 'users_id');       
    }
    
    public function getTable()
    {
        return config('dbtable.common_roles');
    }

}
