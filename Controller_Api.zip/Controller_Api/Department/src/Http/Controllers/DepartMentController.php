<?php

namespace Modules\Department\Http\Controllers;

use App\Http\Controllers\Controller;
use Request;

class DepartMentController extends Controller
{
    public function index()
    {
        echo "department package called";
        die;
    }
}