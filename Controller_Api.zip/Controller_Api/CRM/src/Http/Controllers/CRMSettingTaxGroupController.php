<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\CRMSettingTax;

class CRMSettingTaxGroupController extends Controller
{

    public $page = 'tax_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMSettingTaxGroup::with('tax_info');

        if (!empty($search))
            $data_query = $data_query->where("tax_group_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('tax_group_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) {
            $data->status = ($data->status == 1) ? "Active" : "Inactive";
            
            if(empty($data->tax_info))
                $data->tax_list = '';
            else{
                $tax_name = '';
                foreach ($data->tax_info as $key => $tax) {
                    $tax_name .= $tax->tax_name.',';
                }
                $data->tax_list = $tax_name;
            }
            return $data;
        });

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        $tax = CRMSettingTax::select('tax_id as value','tax_name as label')->get();
        $res = [
            'tax'=>$tax
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'tax_group_name' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only('tax_group_name','status');
        $prdopval = CRMSettingTaxGroup::create($data);

        if($request->has('tax')){
            if(!empty($request->tax) && sizeof($request->tax) > 0 ){
                $payment_term_data =  [];
                foreach ($request->tax as $key => $term) {
                    array_push($payment_term_data, [
                        'tax_group_id'=>$prdopval->tax_group_id,
                        'tax_id'=>$term,
                    ]);
                }
                $prdopval->tax_info()->attach($payment_term_data);
            }
        }


        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_TAX_GROUP_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_ADD');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $response = CRMSettingTaxGroup::with('tax_info')->find($request->tax_group_id);
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'tax_group_name' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only(['tax_group_name', 'status']);

        $prdopval = CRMSettingTaxGroup::
                    where('tax_group_id', $request->tax_group_id)
                    ->update($data);

        $prdopval = CRMSettingTaxGroup::find($request->tax_group_id);
        
        if($request->has('tax')){
            if(!empty($request->tax) && sizeof($request->tax) > 0 ){
                // detach data
                $prdopval->tax_info()->detach();

                $payment_term_data =  [];
                foreach ($request->tax as $key => $term) {
                    array_push($payment_term_data, [
                        'tax_group_id'=>$request->tax_group_id,
                        'tax_id'=>$term,
                    ]);
                }
                $prdopval->tax_info()->attach($payment_term_data);
            }
        }



        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_TAX_GROUP_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_UPDATE');
        }
    }

     public function changeStatus(Request $request){
        $Id = $request->tax_group_id;

        $data = CRMSettingTaxGroup::find($Id);
        $data->status = ($data->status == 1) ? 0:1;
        $data->save();
        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
        

    }
}
