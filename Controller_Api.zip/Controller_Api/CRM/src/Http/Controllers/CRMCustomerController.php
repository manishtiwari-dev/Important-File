<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Country;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMCustomerContact;


class CRMCustomerController extends Controller
{

    public $page = 'customers';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMCustomer::with('crm_customer_contact');


        if (!empty($search))
            $data_query = $data_query->where("company_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('customer_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();
       
     //   return ApiHelper::JSON_RESPONSE(true, $data_list, '');
        if (!empty($data_list)) {
            $data_list = $data_list->map(function ($data) {
                // $data->customer_name = $data->crm_customer_contact->map(function($name){
                //   $data->contact_name=$name->contact_name;
                //   return $customer_name;

                // });
              //  $data->contact_email = $data->crm_customer_contact->contact_email;
                return $data;
            });
        }

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        $leaddata = CRMLead::all();
        $countrydata = Country::all();
        $res = [
            'lead' => $leaddata,
            'country' => $countrydata,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        //validation check 
        $rules = [
            'lead_id' => 'required',
            'company_name' => 'required',
            'website' => 'required|string',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data1 = $request->only(['lead_id', 'first_name', 'email', 'date_of_birth','contact', 'gender','company_name', 'website']);

        $prdopval1 = CRMCustomer::create($data1);
        $customer_id = $prdopval1->customer_id;

        $mulAddress = $request->mulAddress;
        foreach ($mulAddress as $key => $value) {
            $crmcustomeraddress = CRMCustomerAddress::create([
                'customer_id' => $customer_id,
                'address_type' => $value['address_type'],
                'street_address' => $value['street_address'],
                'city' => $value['city'],
                'state' => $value['state'],
                'zipcode' => $value['zipcode'],
                'countries_id' => $value['countries_id'],
                'phone' => $value['phone'],
                //'is_default'=>$value['is_default'],
            ]);
        }
        // $contact = $request->contact;
        // foreach ($contact as $key => $value) {
        //     $crmcustomercontact = CRMCustomerContact::create([
        //         'customer_id' => $customer_id,
        //         'contact_name' => $value['contact_name'],
        //         'contact_email' => $value['contact_email'],
        //         //'is_default'=>$value['is_default'],
        //     ]);
        // }
        $data = [
            'customerdata' => $prdopval1,
            'crmcustomeraddress' => $crmcustomeraddress,
            // 'crmcustomercontact' => $crmcustomercontact,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CUSTOMER_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_ADD');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $response = CRMCustomer::find($request->customer_id);
        if (!empty($response)) {
            $response->crm_customer_address = $response->crm_customer_address()->select(
                'address_id',
                'address_type',
                'street_address',
                'city',
                'state',
                'zipcode',
                'countries_id',
                'phone'
            )->get();
            $response->crm_customer_contact = $response->crm_customer_contact()->select('contact_id', 'contact_name', 'contact_email')->get();
        }
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        
         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $rules = [
            'lead_id' => 'required',
            'company_name' => 'required',
            'website' => 'required|string',
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());








        $customer = CRMCustomer::where(['customer_id' => $request->customer_id])->update(
            [
                'lead_id' => $request->lead_id,
                 'first_name'=>$request->first_name,
                 'email'=>$request->email,
                 'date_of_birth'=>$request->date_of_birth,
                 'contact'=>$request->contact,
                 'gender'=>$request->gender,
                'company_name' => $request->company_name,
                'website' => $request->website,
            ],
        );


        /* Co,mment: Update Or Create Address */
        $mulAddress = $request->mulAddress;
        if (!empty($mulAddress)) {

          //  CRMCustomerAddress::where('customer_id', $request->customer_id)->delete();

            foreach ($mulAddress as $key => $value) {
                $insData = [
                    'customer_id' => $request->customer_id,
                    'address_type' => $value['address_type'],
                    'street_address' => $value['street_address'],
                    'city' => $value['city'],
                    'state' => $value['state'],
                    'zipcode' => $value['zipcode'],
                    'countries_id' => $value['countries_id'],
                    'phone' => $value['phone'],
                    //'is_default' => $value['is_default'],
                    //'status' => $value['status'],
                ];
                if (!empty($value['address_id']))
                    CRMCustomerAddress::where('address_id', $value['address_id'])->update($insData);
                else
                    CRMCustomerAddress::create($insData);
            }
        }

        // $contact = $request->contactInfo;
        // if (!empty($contact)) {

        //     CRMCustomerContact::where('customer_id', $request->customer_id)->delete();

        //     foreach ($contact as $key => $value) {
        //         $insData = [
        //             'customer_id' => $request->customer_id,
        //             'contact_name' => $value['contact_name'],
        //             'contact_email' => $value['contact_email'],
        //             //'is_default' => $value['is_default'],
        //         ];
        //         if (!empty($value['contact_id']))
        //             CRMCustomerContact::where('contact_id', $value['contact_id'])->update($insData);
        //         else
        //             CRMCustomerContact::create($insData);
        //     }
        // }

        if ($customer)
            return ApiHelper::JSON_RESPONSE(true, $customer, 'SUCCESS_CUSTOMER_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_UPDATE');
    }

    //view

    public function view(Request $request)
    {
        $response = CRMCustomer::find($request->customer_id);
        if (!empty($response)) {
            $response->crm_customer_address = $response->crm_customer_address;
            $response->crm_customer_contact = $response->crm_customer_contact;
        }
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function isdefaultupdate(Request $request)
    {
        $upid = $request->update_id;
        $type = $request->type;
        if ($type == 'address') {
            $data = CRMCustomerAddress::find($upid);

            CRMCustomerAddress::where('customer_id', $data->customer_id)->update([
                'is_default' => 0
            ]);

            $data->is_default = 1;
            $data->save();
            return ApiHelper::JSON_RESPONSE(true, ' ', 'ADDRESS-ISDEFAULT_UPDATED');
        } else {
            $contactdata = CRMCustomerContact::find($upid);
            CRMCustomerContact::where('customer_id', $contactdata->customer_id)->update([
                'is_default' => 0,
            ]);
            $contactdata->is_default = 1;
            $contactdata->save();
            return ApiHelper::JSON_RESPONSE(true, '', 'CONTACT-ISDEFAULT_UPDATED');
        }
    }
}
