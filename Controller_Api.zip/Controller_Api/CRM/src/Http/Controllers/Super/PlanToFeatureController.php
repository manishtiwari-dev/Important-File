<?php

namespace Modules\CRM\Http\Controllers\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\Industry;
use Modules\Department\Models\Role;
use Illuminate\Support\Str;
use DB;
use Modules\CRM\Models\Super\PlanFeature;
use Modules\CRM\Models\Super\PlanToFeature;
use App\Models\SubscriptionPlanToIndustry;
use App\Models\SubscriptionPlan;
use Modules\Ecommerce\Models\Feature;

class PlanToFeatureController extends Controller
{
    public $page = 'planfeature';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageupdate = 'update';


    // sectionList 
    public function AllIndustryList(Request $request)
    {
        $api_token = $request->api_token;
        $language = $request->language;
        $planList = [];
        $usType = ($request->userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;
        $industryList = Industry::all();
        return ApiHelper::JSON_RESPONSE(true, $industryList, '');
    }




    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)){
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        // }

        // get all request val
        $language = $request->language;
        $usType = ($request->userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $industry_id = $request->industry_id;
        

        $feature_query = PlanFeature::query();

     


      $plan_data=  SubscriptionPlanToIndustry::where('industry_id',$industry_id)->get();
 // return ApiHelper::JSON_RESPONSE(true,$plan_data,'SUCCESS_PLAN_DATA_UPDATE');

            $plan_data = $plan_data->map(function($data){
            if(!empty($data->subscription_plan_details)){
                $data->subscription_plan_details = $data->subscription_plan_details;
            }
            return $data;
        }); 

    //    $plan_data = SubscriptionPlan::all();

        // search
        if (!empty($search))
            $feature_query = $feature_query->where("feature_title", "LIKE", "%{$search}%");

        // order by sorting 
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $feature_query = $feature_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $feature_query = $feature_query->orderBy('sort_order', 'ASC');
        }

        $data_list = $feature_query->orderBy('sort_order','ASC')->get();

        // if (!empty($data_list)) {
        //     $data_list->map(function ($planTofeature) {
        //         $planTofeature['feature_status'] = PlanToFeature::where('feature_id', $planTofeature->feature_id)->get();
        //         return $planTofeature;
        //     });
        // }


        if (!empty($data_list)) { 
            $data_list->map(function($data){
                // $data->status = ($data->status == "1")?'active':'deactive';
                $data->featureGroup = ($data->feature_group == 1) ?'Website':( ($data->feature_group == 2) ? 'Backend':'Marketing');
                $data->FeatureId=$data->feature_id;
                return $data;
            });
        }

        $res = [
            'feature_list' => $data_list,
            'plan_data' => $plan_data,
        ];
        

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $api_token = $request->api_token;

       
        $api_token = $request->api_token;

        $industry_list = Industry::all();
      
    
        
        $res = [
           
           
             'industry_list'=>$industry_list,
        ];

        return ApiHelper::JSON_RESPONSE(true,$res,'');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        $industry_id = $request->industry_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

      //  $plan_data=SubscriptionPlan::all();
        $feature_data=PlanFeature::all();
        $plan_data=  SubscriptionPlanToIndustry::all();


       // return ApiHelper::JSON_RESPONSE(true, $plan_data, 'FEATURE_STATUS_CREATED');

        $plantofeature='';
        foreach($plan_data as $planKey=>$planVal)
        {
            foreach($feature_data as $featKey=>$featVal)
            {
                $plan_id = $planVal->plan_id;
                $feature_id = $featVal->feature_id;
                $feature_status ='';

                if(isset($request->{"status_".$plan_id."_".$feature_id}))
                {
                    $feature_status = $request->{"status_".$plan_id."_".$feature_id};
                    
                    $plantofeature = PlanToFeature::updateOrCreate(
                        ['plan_id' => $plan_id, 'feature_id' => $feature_id],
                        ['status' => $feature_status,
                         
                        ]
                    );
                }

                // if((isset($request->{"status_".$plan_id."_".$feature_id})) && (isset($request->feature_limit)))
                // {
                //     $feature_status = $request->{"status_".$plan_id."_".$feature_id};
                //     $plantofeature = PlanToFeature::updateOrCreate(
                //         ['plan_id' => $plan_id, 'feature_id' => $feature_id],
                //         ['status' => $feature_status,
                //           'feature_limit'=>$request->feature_limit
                //         ]
                //     );
                // }
                
                
            }
        }

        // $feature_id = (int)$request->feature_id;
        // $plan_id = (int)$request->plan_id;
        // $feature_status = $request->status;


        // $plantofeature = PlanToFeature::updateOrCreate(
        //     ['plan_id' => $plan_id, 'feature_id' => $feature_id],
        //     ['status' => $feature_status]
        // );



        if ($plantofeature) return ApiHelper::JSON_RESPONSE(true, $plantofeature, 'FEATURE_STATUS_CREATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_CREATE_FEATURE_STATUS');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function edit(Request $request)
    // {
    //     $api_token = $request->api_token;
    //     if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
    //         return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


    //     $role_list = Role::with('permissionsTypeList')->find($request->updateId);

    //     // $role_list->sections = ApiHelper::byRoleIdSectionsPermissionList($role_list->roles_id);
    //     return ApiHelper::JSON_RESPONSE(true, $role_list, '');
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */



    // public function sortOrder(Request $request)
    // {
    //     $api_token = $request->api_token;
    //     $roles_id = $request->roles_id;
    //     $sort_order = $request->sort_order;

    //     $infoData =  Role::find($roles_id);
    //     if (empty($infoData)) {
    //         $infoData = new Role();
    //         $infoData->roles_id = $roles_id;
    //         $infoData->sort_order = $sort_order;
    //         $infoData->status = 1;

    //         $infoData->save();
    //     } else {
    //         $infoData->sort_order = $sort_order;
    //         $infoData->save();
    //     }

    //     return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    // }







    // public function update(Request $request)
    // {
    //     $api_token = $request->api_token;
    //     if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
    //         return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
    //     }

    //     $user_id = ApiHelper::get_adminid_from_token($api_token);

    //     $role_name = $request->role_name;

    //     $role = Role::where('roles_name', $role_name)->first();

    //     // if new role coming than will update else not
    //     if ($role !== null) {
    //         Role::find($request->updatedId)->update(['roles_name' => $role_name, 'roles_key' => Str::slug($role_name)]);
    //         $role = Role::find($request->updatedId);
    //     }


    //     // role permission updated
    //     $permissionList = [];

    //     if (sizeof($request->permission) > 0) {

    //         $role->sections()->detach();    // detach relationship data 

    //         foreach ($request->permission as $sectionId => $permission) {

    //             if (!empty($permission)) {

    //                 foreach ($permission as $pId => $pTyeId) {

    //                     if (!empty($pTyeId)) {
    //                         array_push($permissionList, [
    //                             'section_id' => (int) $sectionId,
    //                             'roles_id' => $role->roles_id,
    //                             'permissions_ids' => (int)$pId,
    //                             'permission_types_id' => (int)$pTyeId,
    //                         ]);
    //                     }
    //                 }
    //             }
    //         }
    //         $role->sections()->attach($permissionList);         // attach permission list
    //     }

    //     if ($role)   return ApiHelper::JSON_RESPONSE(true, $role, 'ROLE_UPDATED');
    //     else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_UPDATE_ROLE');
    // }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function destroy(Request $request)
    // {
    //     $api_token = $request->api_token;
    //     $id = $request->deleteId;

    //     if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus)) {
    //         return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
    //     }

    //     $role = Role::find($id);
    //     $role->sections()->detach();
    //     $status = Role::destroy($id);
    //     if ($status) {
    //         return ApiHelper::JSON_RESPONSE(true, [], 'ROLE_DELETED');
    //     } else {
    //         return ApiHelper::JSON_RESPONSE(false, [], 'NOT_DELETED_ROLE');
    //     }
    // }


    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        

        $role_list = PlanFeature::with('planTofeature')->find($request->updateId);
        
        // $role_list->sections = ApiHelper::byRoleIdSectionsPermissionList($role_list->roles_id);
        return ApiHelper::JSON_RESPONSE(true,$role_list,'');

    }


 
}
