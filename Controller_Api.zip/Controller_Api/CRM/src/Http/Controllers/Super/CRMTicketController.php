<?php

namespace Modules\CRM\Http\Controllers\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use ApiHelper;

use Modules\CRM\Models\Super\CRMTickets;
use Modules\CRM\Models\CRMAgent;
use Modules\CRM\Models\Super\CRMTicketsTypes;
use Modules\CRM\Models\Super\CRMTicketsReplies;

use App\Models\User;
use App\Models\Country;
use Storage;

class CRMTicketController extends Controller
{

    public $page = 'ticket';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index(Request $request)
    {
           // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMTickets::with('crm_agent','crm_agent_group','ticket_type')->whereRelation('crm_agent', 'status',  1);

    
        if(!empty($data_query)){
            if (!empty($search))
                $data_query = $data_query->where("subject", "LIKE", "%{$search}%");

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('id', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
            $user_count = $data_query->count();
      

      
        $data_list = $data_query->skip($skip)->take($perPage)->get();

    }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

   

    
      public function changeStatus(Request $request)
    {

        $api_token = $request->api_token; 
        $id = $request->id;
        $sub_data = CRMTickets::where('id',$id)->first();
        $sub_data->status = $request->status;         
        $sub_data->save();
        
        return ApiHelper::JSON_RESPONSE(true,$sub_data,'SUCCESS_STATUS_UPDATE');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;
     //   $id=$request->id;
     if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

   //      $id=User::find($id);

             
            $tickets=CRMTickets::create([
                     'type_id'=>$request->type_id,
                     'subject'=>$request->subject,
                     'user_id'=>ApiHelper::get_adminid_from_token($api_token),
                     'agent_id'=>$request->agent_id,
                     'priority'=>$request->priority,
                 
               ]);

            $ticketsReply=CRMTicketsReplies::create([
              'message'=>$request->message,
              'ticket_id'=>$tickets->id,
              'user_id'=>ApiHelper::get_adminid_from_token($api_token),
            ]);
        $tickets=$ticketsReply;
           
        if($tickets) {
            return ApiHelper::JSON_RESPONSE(true,$tickets,'SUCCESS_TICKETS_ADD');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_TICKETS_ADD');
        }

    }
    public function create(Request $request)
    {
        $api_token = $request->api_token;
        
        $type_list=CRMTicketsTypes::all();
        $agent_list=CRMAgent::all();

      $res = [
            'type_list' => $type_list,
            'agent_list'=>$agent_list,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function details(Request $request)
    {
        $api_token = $request->api_token;
     
       $id=$request->id;


        
       $ticket_id= CRMTickets::find($id);  


       $data_list = CRMTicketsReplies::with('ticket_details','user')->where('ticket_id',$ticket_id->id)->get();

        $res = [
            'reply_list' => $data_list,
        ];

       return ApiHelper::JSON_RESPONSE(true,$res,'');

    }


    public function send_reply(Request $request)
    { 
        $api_token = $request->api_token;
        $id=$request->id;


        
        $ticket= CRMTickets::find($id);  

        $data = CRMTicketsReplies::create([
            'ticket_id' => $ticket->id,
            'user_id'=>ApiHelper::get_adminid_from_token($api_token),
            'message'=>$request->message,
        ]);

        if($data)
        return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_SEND_REPLY');
      else
        return ApiHelper::JSON_RESPONSE(false,[],'ERROR_SEND_REPLY');


    }


}

