<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Currency;
use App\Models\Country;

use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMQuotation;
use Modules\CRM\Models\CRMQuotationItem;
use Modules\Ecommerce\Models\Product;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMSettingPaymentTerms;
use Modules\CRM\Models\CRMSettingTax;
use Modules\CRM\Models\CRMSettingTaxGroup;

use App\Models\Super\SuperAppSetting;
use Modules\Ecommerce\Models\ProductsOptionsValues;

class CRMQuotationController extends Controller
{
    public $page = 'quotation';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';
    public $app_share_portal_link = 'app_share_portal_link';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage)?(int)$request->perPage: ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
      
        $data_query = CRMQuotation::with('crm_quotation_customer')->where('status',1)->OrWhere('status',2)->OrWhere('status',3)->OrWhere('status',4);
        $data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);

        $dateFormat= ApiHelper::dateFormat();



        if (!empty($search))
            $data_query = $data_query->where("quotation_no", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('quotation_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();


        

        // $data_list = $data_list->map(function ($data) {
          
        //     $data->date_format = ApiHelper::dateFormat();
        //     return $data;
        // });


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'date_format'=>$dateFormat
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');


    }

    public function create()
    {
        $lead = CRMLead::select('lead_id as value', 'contact_name as label')->get();
        $customer = CRMCustomer::select('customer_id as value', 'company_name as label')->get();

        // product with options
        $product_attr = Product::where('product_status', 1)->get();
        $product_key_att = [];

        if (!empty($product_attr)) {           

            foreach ($product_attr as $key => $product) {
                // relate with attach attributes
                $attributes = $product->productAttribute()->with('productOptions')->groupBy('options_id')->get();
                if (!empty($attributes)) {
                    $attributes->map(function ($option) use ($product) {
                        $option->option_name = $option->productOptions->products_options_name;
                        $option->option_value_list = $product->productAttribute()->with('productOptionsValue')->where('options_id', $option->options_id)->get();
                        return $option;
                    });
                }

                $product_key_att[$product->product_id] = $attributes;
            }
            
        }


        $product = Product::selectRaw("CONCAT (product_id, ':', product_sale_price) as value, product_sku as label")->where('product_status', 1)->get();

        // $currency = Currency::select('currencies_code','currencies_name')->get();
        $currency = ApiHelper::otherSupportCurrency();
        $paymentterms = CRMSettingPaymentTerms::select('terms_id as value','terms_name as label')->get();
        $country = Country::all();
        
        $crmtax = CRMSettingTax::all();
        $crmTaxGroup = CRMSettingTaxGroup::with('tax_info')->get();

        $tax_array =[];
        
        foreach($crmtax as $key=>$value)
        {
            array_push($tax_array,[
                'tax_id'=>$value->tax_id,
                'tax_name'=>$value->tax_name,
                'tax_percantage'=>$value->tax_percent,
                ]
            );
        }

        foreach ($crmTaxGroup as $key => $taxGroup) {
            
            $tax_percent = [];
            $tax_list = $taxGroup->tax_info;
            if(!empty($tax_list)){
                foreach ($tax_list as $key => $tax) {
                    array_push($tax_percent, $tax->tax_percent);
                }
            }

            array_push($tax_array,[
                'tax_id'=>$taxGroup->tax_group_id,
                'tax_name'=>$taxGroup->tax_group_name,
                'tax_percantage'=>$tax_percent,
                ]
            );
        }

        
        
        $res = [
            'lead' => $lead,
            'customer' => $customer,
            'product' => $product,
            'product_key_att'=>$product_key_att,
            'currency' => $currency,
            'tax'=>$tax_array,
            'country'=>$country,
            'paymentterms'=>$paymentterms, 
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        //validation check 
        $rules = [
            'currency' => 'required',
            'tax_type'=>'required',
            'tax_name' => 'required',
            'tax_percent' => 'required',
            'item_discount' => 'required',
            'quote_discount' => 'required',
            'total_item_cost' => 'required',
            'shipping_cost' => 'required',
            'total_tax' => 'required',
            'final_cost' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only([
            'currency',
            'tax_name',
            'tax_percent',
            'item_discount',
            'quote_discount',
            'shipping',
            'total_item_cost',
            'shipping_cost',
            'total_tax',
            'tax_type',
            'discount',
            'final_cost',
            'note',
        ]);
        $data['quotation_no'] = ApiHelper::generate_random_token('alpha_numeric', 10);

        // creating merging customer_id, address_id, contact

        try{

             \DB::beginTransaction();    // BEGIN DB TRANSACTION

                if($request->has("lead_id")){
                    $customerInfo = $this->leatToCustomer($request->lead_id);
                    $data = array_merge($data, $customerInfo); 
                }

                if($request->has('customer_id'))
                    $data = array_merge($data,$request->only(['customer_id','billing_contact_id','billing_address_id']));
                

                // return ApiHelper::JSON_RESPONSE(true, $data, 'QUOTATION_CREATED');

                $quotation = CRMQuotation::create($data);
                
                $lstquotationid = $quotation->quotation_id;

                // attach payment_term
                if($request->has('payment_term')){
                    if(!empty($request->payment_term) && sizeof($request->payment_term) > 0 ){
                        $payment_term_data =  [];
                        foreach ($request->payment_term as $key => $term) {
                            array_push($payment_term_data, [
                                'quotation_id'=>$lstquotationid,
                                'terms_id'=>$term,
                            ]);
                        }
                        $quotation->crm_quotation_to_payment_term()->attach($payment_term_data);
                    }
                }
                

                $contact = $request->Item;
                foreach ($contact as $key => $value) {
                    $CRMQuotationItem = CRMQuotationItem::create([
                        'quotation_id' => $lstquotationid,
                        'item_name' => $value['item_name'],
                        'item_id' => $value['item_id'],
                        'quantity' => $value['quantity'],
                        'unit_price' => $value['unit_price'],
                        'discount' => $value['discount'],
                        'item_cost' => $value['item_cost'],
                        'attributes' =>  implode(',', $value['item_attr_sel_list']),
                        // 'attributes' =>  $value['item_attr_sel_list'],
                        'updated_at' => date("Y-m-d"),
                    ]);
                }

           \DB::commit();      // COMMIT DB TRANSACTION


           $msag = 'Quotation : '.$quotation->quotation_no.' Created successfully !';
           $title = 'Quotation';
           ApiHelper::realtimeNoti([
                'user_id' => ApiHelper::get_adminid_from_token($api_token),
                'type' => 1,
                'msg' => $msag,
                'title' => $title
            ]);  // generate notifiction

            return ApiHelper::JSON_RESPONSE(true, $quotation, 'SUCCESS_QUOTATION_ADD');

        } catch (\Throwable $th) {
            \DB::rollback();    // ROLLBACK IF ANY ERROR OCCUR WHILE STORING DB
            return ApiHelper::JSON_RESPONSE(false, '', $th->getMessage());
        }

        // if ($quotation) {
        //     return ApiHelper::JSON_RESPONSE(true, $quotation, 'SUCCESS_QUOTATION_ADD');
        // } else {
        //     return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_QUOTATION_ADD');
        // }

    }


    public function leatToCustomer($lead_id){
        $arrayData = [];

        if (!empty($lead_id)) {
            $leadrecords = CRMLead::find($lead_id);
            $customerquotation = CRMCustomer::create([
                'company_name' => $leadrecords->contact_name,
              //  'email' => $leadrecords->contact_email,
                'lead_id' => $lead_id,
            ]);

            $customerquotationaddress = CRMCustomerAddress::create([
                'street_address' => $leadrecords->address,
                'city' => $leadrecords->city,
                'state' => $leadrecords->state,
                'zipcode' => $leadrecords->zipcode,
                'countries_id' => $leadrecords->countries_id,
                'phone' => $leadrecords->phone,
                'customer_id' => $customerquotation->customer_id,
            ]);

            $Leadcontact = CRMLeadContact::select('contact_name','contact_email')->where('lead_id',$lead_id)->get();
            
            $billing_contact_id = 0;

            if(!empty($Leadcontact)){
                foreach ($Leadcontact as $key => $contact) {
                    $contact = (array)$contact;
                    $contact['customer_id'] = $customerquotation->customer_id;
                    $data = CRMCustomerContact::create($contact);
                    $billing_contact_id = $data->contact_id;
                }
            }

            $arrayData['customer_id'] = $customerquotation->customer_id;
            $arrayData['billing_address_id'] = $customerquotationaddress->address_id;
            $arrayData['billing_contact_id'] = $billing_contact_id;
        }

        return $arrayData;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $joinArr = ['crm_quotation_item','crm_quotation_customer','crm_quotation_contact','crm_quotation_address','crm_quotation_to_payment_term'];

        $response = CRMQuotation::with($joinArr)->find($request->quotation_id);

        if (!empty($response)) {
            $contactdata=CRMCustomerContact::where('customer_id',$response->customer_id)->get();
            $addressdata=CRMCustomerAddress::where('customer_id',$response->customer_id)->get();
            $response->contactdata = $contactdata;
            $response->addressdata = $addressdata;


            // getting attributes info
            $response->crm_quotation_item->map(function($item){
                if(!empty($item->attributes))
                    $item->attributes_list = ProductsOptionsValues::with('product_options')->whereRaw('products_options_values_id IN('.$item->attributes.')')->get();
                else
                    $item->attributes_list = '';
                
                return $item;
            });

           

        }

        // gen share token
        $dbShareEncryptToken = ApiHelper::shareEncryptToken($request->api_token);   // db id encode
        $quotation_no_token = ApiHelper::encrypt_string($response->quotation_no);   // quation number
        $finalShareToken = ApiHelper::base64url_encode(ApiHelper::encrypt_string($dbShareEncryptToken."::".$quotation_no_token));
        
        // get
        $portalLink = SuperAppSetting::where('setting_key',$this->app_share_portal_link)->first();
        $response->shareUrl = !empty($portalLink) ? $portalLink->setting_value."/".$finalShareToken."/quotation" : "";

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    public function customeralldata(Request $request)
    {
        $customerid = $request->customer_id;

        $contactdata = CRMCustomerContact::where('customer_id', $customerid)->get();
        $addressdata = CRMCustomerAddress::where('customer_id', $customerid)->get();

        $res = [
            'contactdata' => $contactdata,
            'addressdata' => $addressdata,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            //'quotation_no' => 'required',
            // 'customer_id' => 'required',
            'billing_contact_id' => 'required',
            'billing_address_id' => 'required',
            'currency' => 'required',
            'tax_type'=>'required',
            'tax_name' => 'required',
            'tax_percent' => 'required',
            'item_discount' => 'required',
            'quote_discount' => 'required',
            'shipping' => 'required',
            'total_item_cost' => 'required',
            // 'shipping_cost' => 'required',
            'total_tax' => 'required',
            // 'discount' => 'required',
            'final_cost' => 'required',
           
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only([
            // 'customer_id',
            'billing_contact_id',
            'billing_address_id',
            'currency',
            'tax_name',
            'tax_type',
            'tax_percent',
            'item_discount',
            'quote_discount',
            'shipping',
            'total_item_cost',
            'shipping_cost',
            'total_tax',
            'discount',
            'final_cost',
            'note',
            'convert_invoice',
            'status'
        ]);
        $quotationdata = CRMQuotation::where('quotation_id', $request->quotation_id)
            ->update($data);

        $item = $request->Item;
        if (!empty($item)) {
            CRMQuotationItem::where('quotation_id', $request->quotation_id)->delete();
            foreach ($item as $key => $value) {
                $CRMQuotationItem = CRMQuotationItem::create([
                    'quotation_id' =>  $request->quotation_id,
                    'item_name' => $value['item_name'],
                    'quantity' => $value['quantity'],
                    'unit_price' => $value['unit_price'],
                    'discount' => $value['discount'],
                    'item_cost' => $value['item_cost'],
                    'updated_at' => date("Y-m-d"),
                ]);
            }
        }

         // deattach/ attach payment_term
        $quotation = CRMQuotation::find($request->quotation_id);

        if($request->has('payment_term')){
            if(!empty($request->payment_term) && sizeof($request->payment_term) > 0 ){
                $payment_term_data =  [];

                // detach al previous item
                $quotation->crm_quotation_to_payment_term()->detach();

                foreach ($request->payment_term as $key => $term) {
                    array_push($payment_term_data, [
                        'quotation_id'=>$request->quotation_id,
                        'terms_id'=>$term,
                    ]);
                }
                $quotation->crm_quotation_to_payment_term()->attach($payment_term_data);
            }
        }


        if ($quotationdata) {
            return ApiHelper::JSON_RESPONSE(true, $quotation, 'SUCCESS_QUOTATION_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_QUOTATION_UPDATE');
        }
    }

    public function ContactsInformation(Request $request){

        if($request->contact_type=="address")
        {
            $adddata=$request->only('customer_id','address_type','street_address','city','state','zipcode','countries_id',
            'phone',);
            $AddressData=CRMCustomerAddress::create($adddata);
            return ApiHelper::JSON_RESPONSE(true, $AddressData, 'CUSTOMER_ADDRESS_CREATED');
        }
        if($request->contact_type=="contact")
        {
            $contact_data=$request->only('customer_id','contact_name','contact_email');
            $ContactData=CRMCustomerContact::create($contact_data);
            return ApiHelper::JSON_RESPONSE(true, $ContactData, 'SUCCESS_CUSTOMER_CONTACT_ADD');
        }
    }



    public function changeStatus(Request $request){
        $quoteId = $request->quoteId;
        $statusId = $request->statusId;
        
        if(empty($statusId) || empty($quoteId) )
            return ApiHelper::JSON_RESPONSE(false, '', 'SOME_FIELD_MISSING');

        $quote = CRMQuotation::find($quoteId);
        $quote->status = $statusId;
        $quote->save();

        if ($quote)
            return ApiHelper::JSON_RESPONSE(true, $quote, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
        

    } 
}
