<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMLeadFollowUpHistory extends Model
{
    use HasFactory;
    protected $primaryKey = 'followup_history_id';
    protected $fillable = [
        'lead_id',

        'followup_note',
        'created_at',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_followup_history');
    }

    public $timestamps = false;
    
}
