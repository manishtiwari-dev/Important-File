<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMTicketsCustomer extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $connection='mysqlSuper';

    protected $table = "crm_ticket_custom_forms";
    protected $guarded = [
        'id',
        
    ];
  
    

     
}
