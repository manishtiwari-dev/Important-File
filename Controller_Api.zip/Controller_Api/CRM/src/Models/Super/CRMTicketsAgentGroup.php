<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMAgent;


class CRMTicketsAgentGroup extends Model
{
    use HasFactory;
   protected $connection='mysqlSuper';

    protected $table = "crm_ticket_agent_groups";
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
   
    

      public function crm_agent(){


        return $this->belongsTo(CRMAgent::class,'agent_id','agent_id');
    }
    
}
