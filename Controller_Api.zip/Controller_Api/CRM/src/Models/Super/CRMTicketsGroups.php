<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMTicketsGroups extends Model
{
    use HasFactory;
    protected $connection='mysqlSuper';

    protected $table = "crm_ticket_groups";
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
   
    

     
}
