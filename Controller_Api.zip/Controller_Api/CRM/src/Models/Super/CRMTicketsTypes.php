<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMTicketsTypes extends Model
{
    use HasFactory;
   protected $connection='mysqlSuper';

    protected $table = "crm_ticket_types";
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
   
    

     
}
