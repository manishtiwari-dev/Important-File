<?php
namespace Modules\CRM\Models\Super;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use Modules\CRM\Models\CRMAgent;



class CRMTickets extends Model
{
    use HasFactory;

    protected $connection='mysqlSuper';
    protected $table = "crm_tickets";
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
  

     public function crm_agent(){


        return $this->belongsTo(CRMAgent::class,'agent_id','agent_id');
    }
    
     
    public function crm_agent_group(){


        return $this->belongsTo(CRMTicketsAgentGroup::class,'agent_id','agent_id');
    }
     

      public function user(){

        return $this->belongsTo(User::class,'user_id');
    }



      public function ticket_type(){

        return $this->belongsTo(CRMTicketsTypes::class,'type_id','id');
    }
   
}
