<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\EnquiryProducts;



class Enquiry extends Model
{
    use HasFactory;

    protected $primaryKey = "enquiry_id";

    public $timestamps = false;

    protected $guarded=[
     
     'enquiry_id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_enquiry');
    }
    

    public function enquiry_product(){
        return $this->hasOne(EnquiryProducts::class, 'enquiry_id', 'enquiry_id');
    }

  

}
