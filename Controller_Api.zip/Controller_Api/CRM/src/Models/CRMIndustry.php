<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMIndustry extends Model
{
    use HasFactory;
    protected $primaryKey = 'industry_id';
    protected $fillable = [
        'industry_name',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_industry');
    }
    
}
