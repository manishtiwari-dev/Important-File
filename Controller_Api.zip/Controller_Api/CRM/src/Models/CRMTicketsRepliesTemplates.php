<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMTicketsRepliesTemplates extends Model
{
    use HasFactory;
    protected $primaryKey = 'id';
    protected $guarded = [
        'id',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_ticket_reply_templates');
    }
    

     
}
