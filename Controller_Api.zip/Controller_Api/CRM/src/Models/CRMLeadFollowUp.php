<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMLeadFollowUpHistory;

class CRMLeadFollowUp extends Model
{
    use HasFactory;
    protected $primaryKey = 'followup_id';
    protected $fillable = [
        'lead_id',
        'followup_status',
        'next_followup',
        'created_at',
    ];
    public function getTable()
    {
        return config('dbtable.crm_lead_followup');
    }

    public function crm_lead_followup_history()
    {
        return $this->hasMany(CRMLeadFollowUpHistory::class, 'followup_id', 'followup_id');
    }

    public $timestamps = false;
    
}
