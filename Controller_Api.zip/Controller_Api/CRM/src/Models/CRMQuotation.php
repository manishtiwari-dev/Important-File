<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMCustomerAddress;


class CRMQuotation extends Model
{
    use HasFactory;
    protected $primaryKey = 'quotation_id';
    protected $fillable = [
        'quotation_no',
        'customer_id',
        'billing_contact_id',
        'billing_address_id',
        'currency',
        'tax_type',
        'tax_name',
        'tax_percent',
        'item_discount',
        'quote_discount',
        'shipping',
        'total_item_cost',
        'shipping_cost',
        'total_tax',
        'discount',
        'final_cost',
        'note',
        'convert_invoice',
        'status',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_quotation');
    }

    public function crm_quotation_to_payment_term(){
        return $this->belongsToMany(CRMSettingPaymentTerms::class,config('dbtable.crm_quotation_to_payment_term'),'quotation_id','terms_id');
    }
    
    public function crm_quotation_item()
    {
        return $this->hasMany(CRMQuotationItem::class, 'quotation_id', 'quotation_id');
    }

    public function crm_quotation_customer()
    {
        return $this->belongsTo(CRMCustomer::class, 'customer_id', 'customer_id');
    }

    public function crm_quotation_contact()
    {
        return $this->belongsTo(CRMCustomerContact::class, 'billing_contact_id', 'contact_id');
    }

    public function crm_quotation_address()
    {
        return $this->belongsTo(CRMCustomerAddress::class, 'billing_address_id', 'address_id');
    }

}
