<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMSettingTax extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_id';
    protected $fillable = [
        'tax_name',
        'tax_percent',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_setting_tax');
    }
    public $timestamps = false;
}
