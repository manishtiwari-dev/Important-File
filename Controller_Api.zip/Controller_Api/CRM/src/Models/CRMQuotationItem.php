<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMQuotationItem extends Model
{
    use HasFactory;
    protected $primaryKey = 'quotation_item_id';
    protected $fillable = [
        'quotation_id',
        'item_name',
        'quantity',
        'unit_price',
        'discount',
        'item_cost',
        'status',
        'updated_at',
    ];
    public function getTable()
    {
        return config('dbtable.crm_quotation_item');
    }
    
    public $timestamps=false;
}
