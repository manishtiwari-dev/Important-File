<?php
namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\Product;



class EnquiryProducts extends Model
{
    use HasFactory;

    protected $primaryKey = "enquiry_products_id";

    public $timestamps = false;

    protected $guarded=[
     
     'enquiry_products_id',


    ];
     
    
    public function getTable()
    {
        return config('dbtable.web_enquiry_products');
    }
   

    public function products()
    {

       return $this->belongsTo(Product::class, 'products_id', 'product_id');
    }
     
   


}
