<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Industry;
use App\Models\Super\IndustryCategory;
use Modules\Ecommerce\Models\SeoMeta;

use ApiHelper;



class IndustryCategoryController extends Controller
{
  


	public function index(Request $request){
        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?(int)$request->perPage: ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        /*Fetching industry data*/ 
        $industry_section_query = IndustryCategory::where('industry_id',$request->industry_id);
        
        if(!empty($search))
            $industry_section_query = $industry_section_query->where("category_name","LIKE", "%{$search}%");

        /* order by sorting */
        if(!empty($sortBY) && !empty($ASCTYPE)){
            $industry_section_query = $industry_section_query->orderBy($sortBY,$ASCTYPE);
        }else{
            $industry_section_query = $industry_section_query->orderBy('industry_category_id','ASC');
        } 

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;

        $industry_count = $industry_section_query->count();

        $industry_list = $industry_section_query->skip($skip)->take($perPage)->get();

          
        // // display each image 
        // if(!empty($industry_list)){
        //     $industry_list = $industry_list->map(function($data){
        //         $data->image = ApiHelper::getFullImageUrl($data->banner_image, 'index-list');
        //         $data->web_image = ApiHelper::getFullImageUrl($data->web_feature_img, 'index-list1');

        //         return $data;
        //     });
        // }

     //   $industry_list = $industry_section_query->get();
             
        // display each image 
        if(!empty($industry_list)){
            $industry_list = $industry_list->map(function($data){
                $data->image = ApiHelper::getFullImageUrl($data->banner_img, 'index-list');
                $data->web_image = ApiHelper::getFullImageUrl($data->web_feature_img, 'index-list1');

                $data->landing_link = ApiHelper::landingDomainUrl();

                return $data;
            });
        }

        if($request->has('industry_id')){        
            //getting category Name
             $grpName=Industry::where('industry_id',$request->industry_id )->first();
             $cName = !empty($grpName) ? $grpName->industry_name : '';
        }

        
        $res = [
            'data'=>$industry_list,
            'current_page'=>$current_page,
            'total_records'=>$industry_count,
            'total_page'=>ceil((int)$industry_count/(int)$perPage),
            'per_page'=>$perPage,
            'industry_name'=>$cName,
        ];
        /*returning data to client side*/
        return ApiHelper::JSON_RESPONSE(true,$res,'');
    }


    public function store(Request $request)
    {
        $api_token = $request->api_token;
        $category_name = $request->category_name;
        $banner_img = $request->banner_img;
        $web_feature_img = $request->web_feature_img;
        
        
        $video_url = $request->video_url;
        $category_title = $request->category_title;
        $category_description = $request->category_description;
        $title = $request->meta_title;
        $meta_desc =  $request->meta_description;

        $sort_order = $request->sort_order;
       
        $validator = Validator::make($request->all(),[
            'category_name' => 'required',
            'sort_order'=>'required',
        ],[
            'category_name.required'=>'INDUSTRY_CATEGORY_NAME_REQUIRED',
            'sort_order.required'=>'SORT_ORDER_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());

        if($banner_img!= '')
        ApiHelper::image_upload_with_crop($api_token, $banner_img, 1, 'industry', '', false);

        if($web_feature_img != '')
        ApiHelper::image_upload_with_crop($api_token, $web_feature_img, 1, 'industry/feature', '', false);


        $data = IndustryCategory::create([
            'category_name' => $category_name,
            'demo_db'=>$request->demo_db,
            'video_url'=>$video_url,
            'category_title'=>$category_title,
            'category_description'=>$category_description,
            'banner_img'=>$banner_img,
            'web_feature_img'=>$web_feature_img,
            'category_slug' => \Str::slug($category_name, '-'),

            'industry_id'=>$request->industry_id,
            'demo_url'=>$request->demo_url,
            'sort_order' => $sort_order,
            'status'=>$request->status,
            'meta_title'=>$title,
            'meta_description'=> $meta_desc
           
        ]);


      

         
        //    SeoMeta::create([
        //           'page_type'=>1,
        //           'reference_id'=>$data->industry_category_id,
        //           'seometa_title'=>$title,
        //           'seometa_desc'=>$meta_desc, 
        //       ]);
         
      

         if($data)
            return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_INDUSTRY_CATEGORY_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_INDUSTRY_CATEGORY_ADD');
    }

    public function edit(Request $request){

        $industry_category_id = $request->industry_category_id;

        $data = IndustryCategory::where('industry_category_id',$industry_category_id)->first();

        $data->image = ApiHelper::getFullImageUrl($data->banner_img, 'index-list');
        $data->web_image = ApiHelper::getFullImageUrl($data->web_feature_img, 'index-list1');


        //$data->modules = $data->modules;
        return ApiHelper::JSON_RESPONSE(true,$data,'');
    }

    public function update(Request $request){
        $api_token = $request->api_token;
        $category_name = $request->category_name;
        $banner_img = $request->banner_img;
        $web_feature_img = $request->web_feature_img;
        $industry_category_id=$request->industry_category_id;
        $video_url = $request->video_url;
        $category_title = $request->category_title;
        $category_description = $request->category_description;
        $title = $request->meta_title;
        $meta_desc =  $request->meta_description;

        $sort_order = $request->sort_order;

       $validator = Validator::make($request->all(),[
            'category_name' => 'required',
            'sort_order'=>'required',
        ],[
            'category_name.required'=>'INDUSTRY_CATEGORY_NAME_REQUIRED',
            'sort_order.required'=>'SORT_ORDER_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());

        

        if($banner_img!= '')
        ApiHelper::image_upload_with_crop($api_token, $banner_img, 1, 'industry', '', false);

        if($web_feature_img != '')
        ApiHelper::image_upload_with_crop($api_token, $web_feature_img, 1, 'industry/feature', '', false);
            


        $data = IndustryCategory::where('industry_category_id',$industry_category_id)->update([
            'category_name' => $category_name,
            'demo_db'=>$request->demo_db,
            'video_url'=>$video_url,
            'category_title'=>$category_title,
            'category_description'=>$category_description,
            'banner_img'=>$banner_img,
            'web_feature_img'=>$web_feature_img,

            'category_slug' => \Str::slug($category_name, '-'),

            'industry_id'=>$request->industry_id,
            'demo_url'=>$request->demo_url,
            'sort_order' => $sort_order,
            'status'=>$request->status,
            'meta_title'=>$title,
            'meta_description'=> $meta_desc

        ]);

        return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_INDUSTRY_CATEGORY_UPDATE');
    }

    public function create(Request $request){
        $api_token = $request->api_token;
    
        $industry_list = Industry::all();

        
          if(!empty($industry_list)){
            $industry_list = $industry_list->map(function($data){
                $data->indName =$data->industry_id;
                return $data;
            });
        }


       return ApiHelper::JSON_RESPONSE(true,$industry_list,'');
    }

  

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token; 
        $industry_category_id = $request->industry_category_id;
        $sub_data = IndustryCategory::where('industry_category_id',$industry_category_id)->first();
        $sub_data->status = ($sub_data->status == 0 ) ? 1 : 0;         
        $sub_data->save();
        
        return ApiHelper::JSON_RESPONSE(true,$sub_data,'CATEGORY_STATUS');
    }
   
    
    
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $status = IndustryCategory::where('industry_category_id',$request->industry_category_id)->delete();
        if($status) {
            return ApiHelper::JSON_RESPONSE(true,[],'SUCCESS_INDUSTRY_CATEGORY_GROUP_DELETE');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_INDUSTRY_CATEGORY_DELETE');
        }
    }

}