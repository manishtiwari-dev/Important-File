<?php
   
namespace App\Http\Controllers\Api;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use DB;

   
class RegisterController extends BaseController
{
    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
            'c_password' => 'required|same:password',
        ]);
   
        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }
   
        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);
     
        $success['name'] =  $user->name;
    
      //  $success['api_token'] = $user->createToken('Token')->plainTextToken;
         
        $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                           'access_token' => $token,
                            'token_type' => 'Bearer',
            ]);
 

      //  return  $this->sendResponse(true,$success,'User register successfully.');

      //  return $this->sendResponse($success, 'User register successfully.');
    }
   
    /**
     * Login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        if(!Auth::attempt(['email' => $request->email, 'password' => $request->password])){ 
         //   $user = Auth::user(); 
       
            return response()->json([
                'message' => 'Invalid login details'
                           ], 401);
                       }
    
            $user = User::where('email', $request['email'])->firstOrFail();


            // if (count(DB::table('personal_access_tokens')->where('tokenable_id', $user->id)->get()) > 0) {
            //     DB::table('personal_access_tokens')->where('tokenable_id', $user->id)->delete();
            // }

           
    
            $token = $user->createToken('auth_token')->plainTextToken;
       
    
         return response()->json([
             'access_token' => $token,
            'token_type' => 'Bearer',
                ]);
       
    }

    public function me(Request $request)
        {
        return $request->user();
        }

}