import React, { useState, useRef, useMemo } from "react";
import JoditEditor from "jodit-react";


const ContentEditor = (props) => {
  //console.log(props);
  const editor = useRef(null);
  const [content, setContent] = useState(props.initialValue);
  const config = {
    readonly: false,
    height: 400 // all options from https://xdsoft.net/jodit/doc/
  };

  React.useEffect(() => setContent(props.initialValue), [props.initialValue]);

  const handleChange = (value) => {
    props.updateFun(
      props.setKey,
      value
    );
  };

  

  return (
    <>
      <JoditEditor
        ref={editor}
        value={content}
        config={config}
        onBlur={newContent => setContent(newContent)}
        onChange={handleChange}
      />
    </>

  );
};

export default ContentEditor;
