import React, { useState, useRef } from "react";
import JoditEditor from "jodit-react";


const config = {
  readonly: false,
  height: 200,
};


const ContentEditor = ({ initialValue, getValue }) => {
  const editor = useRef(null);


   const [content, setContent] = useState("");




  
  return (
    <>
      <JoditEditor
        ref={editor}
        value={content}
        config={config}
        wrapperClassName="demo-wrapper"
        editorClassName="demo-editor"
        tabIndex={1}
        name="tarea"
        onBlur={newContent => setContent(newContent)}
        onChange={(newContent) => getValue(newContent)}
    
      />
    </>

  );
};

export default ContentEditor;


