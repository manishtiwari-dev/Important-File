import React, { useState,useEffect } from "react";
import Notify from "component/Notify";
import POST from "axios/post";
import { Trans } from "lang";
import { useSelector } from "react-redux";


import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message"
import {
    AppSettingGroupIteamUrl,

  } from "config/index"

function RecordPerPage({filterItem, perPageItem}) {
    const { apiToken, language} = useSelector((state) => state.login);
    const [error, setError] = useState({
      status: false,
      msg: "",
      type: "",
    });
    const [formloadingStatus, SetformloadingStatus] = useState(false);
    const [contentloadingStatus, SetloadingStatus] = useState(false);

    const searchItem = (value) => {
        filterItem("perpage",value,"")
    }
    const [key, setKey] = useState("per_page_item");

    const [sectionListing, SetSectionListing] = useState([]);
    const [itemlist,SetItemlist]=useState(" ");

    const getAllData = () => {
        SetloadingStatus(true);
        const filterData2 = {
          api_token: apiToken,
        
        };
       
        POST(AppSettingGroupIteamUrl, filterData2)
          .then((response) => {
            const { status, data, message } = response.data;
            if (status) {
             SetSectionListing(data.item_list);
        
    
            } else Notify(false, Trans(message, language));
          })
          .catch((error) => {
            console.error("There was an error!", error);
          });
      };
      useEffect(() => {
        let abortController = new AbortController();
        getAllData();
        return () => abortController.abort(); //getAllData();
      }, []);
    

    return (
        <label htmlFor="perPage">
            {/* <select
                name="perPage"
                id="perPage"
                className="form-control"
              
                onChange={(e) => searchItem(e.target.value)}
            > */}
                    {sectionListing &&
                     sectionListing.map((item, idx) => {

                    let optionValuesAry = '';
                        if(item.setting_options != '' && item.setting_options != null && item.option_type == 'dropdown'){
                            let optionString = item.setting_options;
                            optionValuesAry = optionString.split(',');
                        } else{
                            optionValuesAry = '';
                        }
                        console.log(optionValuesAry);
           
                        return (
                            <>
                            {item.setting_key === "per_page_item"  && (
                              
                            <React.Fragment>
                             
                              <select
                                name="perPage"
                                id="perPage"
                              
                                className="form-control"
                              
                                defaultValue={item.setting_value}
                                onChange={(e) => searchItem(e.target.value)}
                              >
                           { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                         
                        
                              </select>
                            </React.Fragment>
                       )  }
                         </> 
                         );
                        
          
        
      
          
           
                           
                    
          }) }

                  
                        

           
        </label>
    )
}

export default RecordPerPage
