import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";

import Moment from "react-moment";
import Notify from "component/Notify";

import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

function SalesDashboardModel({ dashboardcontent }) {
  // console.log("transactionLog", JSON.parse(dashboardcontent));
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setTransaction(JSON.parse(dashboardcontent));
    return () => abortController.abort();
  }, [dashboardcontent]);

  console.log(transaction);

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
          <div className="d-flex">
            <h6>{Trans("DIRECTORY_PATH", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.directory_path}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("DOMAIN_URL", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.domain_url}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("DB_SUFFIX", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.db_suffix}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("EXPIRY_AT", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.expired_at}</p>
          </div>
       
      
        </div>
      </div>
    </div>
  );
}

export default SalesDashboardModel;
