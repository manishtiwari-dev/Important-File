import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  MenuListUrl,
  BannerUpdateSettingUrl,
  MenuGroupUrl,
  MenuChangeStatusUrl,
  MenuDestroyUrl,
  MenuSortOrderUrl
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";
import { Col, BadgeShow ,IconButton} from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import { MenuSetting } from 'config/WebsiteUrl';
import ModalAlert from "component/ModalAlert";



import {
  PageDepartment,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import Edit from "./Edit";
import WebsiteLink from "config/WebsiteLink";

function Menu() {
  const { menuGroupId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  const loadSettingData = () => {
    const filterData = {
      api_token: apiToken,
      language: language,
     
    };
    POST(MenuGroupUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetSectionListing(data.data_list);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    loadSettingData();
    findListBanner(menuGroupId);
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const [bannerList, SetBannerList] = useState([]);
  
  const [catName, SetCatName] = useState("");

  const findListBanner = (id,sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      group_id: id,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(MenuListUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("Banner list", data);
        if (status) {
          SetloadingStatus(false);
          SetBannerList(data.data_list);
          SetCatName(data.group_name);

        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const destroyItem = (id) => {
    const filterData = {
      api_token: apiToken,
      menu_id: id,
    };
    POST(MenuDestroyUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      menu_id: id,
    };

    POST(MenuChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(menuGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  const filterItem = () => {
    findListBanner(menuGroupId);
  };
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });
  
  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: destroyItem,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  // change Status function
  const ChangeStatusfun = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: changeStatus,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      menu_id: update_id,
      sort_order: sortOrder,
    };
    POST(MenuSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  

  return (
    <Content>
      <CheckPermission IsPageAccess="subscription.view">
        <>
          <PageHeader
            breadcumbs={[
              { title: Trans("DASHBOARD", language), link: "/", class: "" },
              {
                title: Trans("MENU_GROUP", language),
                link: WebsiteLink(MenuSetting),
                class: "",
              },
              {
                title:catName,
                link: "/",
                class: "active",
              },
            ]}
          />

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission IsPageAccess="role.view">
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      {Trans("MENU_LIST", language)}
                    </h6>
                    <div className="d-none d-md-flex">
                      <Button
                        variant="primary"
                        className="btn btn-primary"
                        onClick={handleModalShow}
                      >
                        {Trans("ADD_MENU", language)}
                      </Button>{" "}
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("MENU_NAME", language)}</th>
                                <th>{Trans("MENU_TYPE", language)}</th>
                                <th>{Trans("MENU_LINK", language)}</th>
                                <th>{Trans("SORT_ORDER", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {bannerList &&
                                bannerList.map((banner, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>{banner.menu_name}</td>
                                      <td>
                                        {banner.menu_type === 1
                                          ? "Category"
                                          : banner.menu_type === 2
                                          ? "Page"
                                          : "Custome Link"}
                                      </td>
                                      <td>{banner.menu_link}</td>
         
                                      <td >   
                        <input
                            type="number"
                            name=""
                            id=""
                            defaultValue={banner.sort_order}

                            style={{ width: "50px" , 'text-align':"center"}}                
                            onBlur={(e) => {
                              UpdateOrderStatus(
                                banner.menu_id,
                              e.target.value
                            );
                         }}
                         />
                  </td>
                                      <td>
                                        <BadgeShow
                                          type={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                          content={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                        />{" "}
                                      </td>
                                      <td className="text-center">

                                           
                                      <IconButton
                              color="primary"
                              onClick={() =>
                                editFunction(banner?.menu_id)
                              }
                            >
                              <FeatherIcon
                                icon="edit-2"
                                                               
                                fill="white"
                                onClick={() =>
                                  editFunction(banner?.menu_id)
                                }
                              />
                            </IconButton>{" "}
                            <IconButton
                               color="primary"
                               onClick={() =>
                                ChangeStatusfun(banner?.menu_id)
                              }
                            >
                              <FeatherIcon
                                icon="repeat"
                                fill="white"
                                onClick={() =>
                                  ChangeStatusfun(banner?.menu_id)
                                }
                              />
                            </IconButton>
                            {"  "}
                            <IconButton
                               color="primary"
                               onClick={() => deleteItem(banner?.menu_id)}
                            >
                              <FeatherIcon
                                 icon="x-square"
                                 color="white"
                                 onClick={() => deleteItem(banner?.menu_id)}
                              />
                            </IconButton>
                            {"  "}        
                                       

                                       
                                      </td>
                                    </tr>
                                  );
                                })}

                              {bannerList.length === 0 ? (
                                <tr>
                                  <td colSpan={6} className="text-center">
                                    {Trans(
                                      "NOT_FOUND_CHOOSE_BANNER_GROUP",
                                      language
                                    )}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
         
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal show={show} onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_MENU", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            loadSettingData={loadSettingData}
            handleModalClose={handleModalClose}
            filterItem={filterItem}
            menuGroupId={menuGroupId}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal show={editModalShow} onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_MENU", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
            menuGroupId={menuGroupId}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </Content>
  );
}

export default Menu;
