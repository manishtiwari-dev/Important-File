import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";

import Moment from "react-moment";
import Notify from "component/Notify";

import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";
import { BlogPagesVieweUrl, PagesCreateUrl } from "config/index";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect,
  TextArea,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
function ViewModal({ editid }) {
  const [viewlist, setviewlist] = useState("");
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  let id = editid;
  const UpdateOrderStatus = () => {
    const editData = {
      api_token: apiToken,
      language: language,
      post_id: id,
    };
    POST(BlogPagesVieweUrl, editData)
      .then((response) => {
        setTransaction(response.data.data);
        const { message } = response.data;
        // Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    UpdateOrderStatus();
  }, [id]);
  let newStr;

  console.log(transaction);
  const [langList, SetlangList] = useState([]);
  const [key, setKey] = useState("default_language");

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
    };
    POST(PagesCreateUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        console.log(data);
        if (status) {
          SetlangList(data.language);
          // setValueToField();
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
        console.error("There was an error!", error);
      });
    return () => abortController.abort();
  }, []);
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
          {/* {transaction &&
            transaction.map((e) => {
              return (
                <> */}
          <Row>
            <Col col={12}>
              <Tabs
                id="controlled-tab-example"
                onSelect={(k) => setKey(k)}
                className="mb-3"
              >
                {langList &&
                  langList.map((lang, index) => {
                    const { languages_code, languages_id, languages_name } =
                      lang;
                    return (
                      <Tab
                        eventKey={languages_code}
                        key={languages_id}
                        title={languages_name}
                      >
                        {/* <Row> */}
                        {transaction?.description_details &&
                          transaction?.description_details.map((nested) => {
                            return languages_id == nested.languages_id ? (
                              <>
                                <div className="d-flex">
                                  <p>{nested.post_title}</p>
                                </div>
                                <div className="d-flex">
                                  <div>
                                    {
                                      (newStr = nested.post_content.replace(
                                        /(<([^>]+)>)/gi,
                                        ""
                                      ))
                                    }

                                    <p>{newStr}</p>
                                  </div>
                                </div>
                              </>
                            ) : (
                              " "
                            );
                          })}

                        {/* </>
              );
            })} */}
                        {/* </Row> */}
                      </Tab>
                    );
                  })}
              </Tabs>
            </Col>

            <br />
          </Row>
        </div>
      </div>
    </div>
  );
}

export default ViewModal;
