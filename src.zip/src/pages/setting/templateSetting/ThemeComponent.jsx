import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import "./style.css";

import {
  TempComponentSettingUrl,
  TempComponentSettingChangeStatusUrl,
  TempComponentSettingSortOrderUrl,
} from "config";
import { useParams } from "react-router-dom";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import Table from "component/Table";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import {
  PageTemplateSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";

import WebsiteLink from "config/WebsiteLink";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Button } from "react-bootstrap";

const ThemeComponent = () => {
  const { themeId } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  const [themeDetail, SetThemeDetail] = useState([]);
  // const [contentloadingStatus, SetloadingStatus] = useState(true);

  const getData = () => {
    // SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      template_id: themeId,
    };

    POST(TempComponentSettingUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log(data.child_list);
        if (status) {
          // SetloadingStatus(false);
          SetdataList(data.child_list);
          SetThemeDetail(data.template_detail);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  const ChangeFunction = (update_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: update_id,
      type: type,
    };
    POST(TempComponentSettingChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        getData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const SortOrderUpdate = (e, edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      sort_order: e.target.value,
      type: type,
    };
    POST(TempComponentSettingSortOrderUrl, editData)
      .then((response) => {
        const { message, data } = response.data;

        // update side module and section
        // dispatch(updateModuleListState(data));
        Notify(true, Trans(message, language));
        ThemeComponent();
        // RefreshList();
      })
      .catch((error) => {
        console.log(error);
      });
  };
  console.log(dataList);
  useEffect(() => {
    let abortController = new AbortController();
    getData();
    return () => abortController.abort();
  }, []);
  return (
    <Content>
      <PageHeader
        breadcumbs={[
          { title: Trans("DASHBOARD", language), link: "/", class: "" },
          {
            title: Trans("THEME", language),
            link: WebsiteLink("/themes"),
            class: "",
          },
          {
            title: Trans("COMPONENT", language),
            link: "",
            class: "active",
          },
        ]}
      />
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission
            PageAccess={PageTemplateSetting}
            PageAction={PreView}
          >
            <div className="card" id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className="tx-uppercase tx-semibold mg-b-0">
                  {Trans(`${themeDetail?.template_name}`, language)}
                </h6>
                <span style={{ float: "right" }}>
                  <span>
                    <Anchor path={WebsiteLink("/themes")}>Go Back</Anchor>
                  </span>
                  {"  "}
                  <span>
                    <Button variant="primary" onClick={getData}>
                      <FeatherIcon icon="refresh-cw" className="wd-10 mg-r-5" />
                      {Trans("REFRESH", language)}
                    </Button>
                  </span>
                </span>
              </div>
              <div className="card-body">
                {/* {contentloadingStatus ? (
                  <Loading />
                ) : ( */}
                <div className="row">
                  <div className="col-md-12">
                    <div className="table-responsive">
                      <table
                        className="module_details mb-4"
                        cellSpacing="0"
                        rules="all"
                        border="1"
                        id=""
                        style={{ borderCollapse: "collapse" }}
                      >
                        <thead>
                          <tr>
                            <th>Section</th>
                           

                            <th className="text-center">Status </th>
                            <th className="text-center">Sort Order</th>
                          </tr>
                        </thead>
                      </table>
                      {dataList.length > 0 &&
                        dataList.map((data, IDX) => {
                          const {} = data;
                          return (
                            <>
                              {data.template_id == themeId ? (
                                <table
                                  className="module_details mb-4"
                                  cellSpacing="0"
                                  rules="all"
                                  border="1"
                                  id=""
                                  style={{ borderCollapse: "collapse" }}
                                >
                                  <thead>
                                    <tr>
                                      <th>
                                        {data?.component_details.component_name}
                                      </th>

                                      <th className="text-center">
                                        <div className="custom-control custom-switch">
                                          <input
                                            onClick={() =>
                                              ChangeFunction(
                                                data?.component_details
                                                  .component_id,
                                                "template"
                                              )
                                            }
                                            type="checkbox"
                                            class="custom-control-input"
                                            id={`${data?.component_details.component_id}`}
                                            checked={
                                              data?.component_details.status ===
                                              0
                                                ? ""
                                                : "checked"
                                            }
                                          />
                                          <label
                                            className="custom-control-label"
                                            For={`${data?.component_details.component_id}`}
                                          ></label>
                                        </div>
                                      </th>
                                      <th className="text-center">
                                        <input
                                          type="number"
                                          name=""
                                          id=""
                                          style={{ width: "50px" }}
                                          defaultValue={
                                            data?.component_details.sort_order
                                          }
                                          onBlur={(e) => {
                                            SortOrderUpdate(
                                              e,
                                              data?.component_details
                                                .component_id,

                                              "template"
                                            );
                                            // getData();
                                          }}
                                        />
                                      </th>
                                    </tr>
                                  </thead>

                                  {data.child.length > 0 &&
                                    data.child.map((cat, IDX) => {
                                      const {
                                        component_name,
                                        component_details,
                                        setting_id,
                                        statusCheck,
                                        sortOrder,
                                      } = cat;

                                      return (
                                        <tbody>
                                          <tr>
                                            <td className="">
                                              {
                                                cat?.component_details
                                                  .component_name
                                              }
                                            </td>

                                            <td className="text-center">
                                              <div className="custom-control custom-switch">
                                                <input
                                                  onClick={() =>
                                                    ChangeFunction(
                                                      cat.setting_id,
                                                      ""
                                                    )
                                                  }
                                                  type="checkbox"
                                                  class="custom-control-input"
                                                  id={`${cat.setting_id}`}
                                                  checked={
                                                    cat.statusCheck === 0
                                                      ? ""
                                                      : "checked"
                                                  }
                                                />
                                                <label
                                                  className="custom-control-label"
                                                  For={`${cat.setting_id}`}
                                                ></label>
                                              </div>
                                            </td>
                                            <td className="text-center">
                                              <input
                                                type="number"
                                                name=""
                                                id=""
                                                style={{ width: "50px" }}
                                                defaultValue={sortOrder}
                                                onBlur={(e) => {
                                                  SortOrderUpdate(
                                                    e,
                                                    cat.setting_id,

                                                    ""
                                                  );
                                                }}
                                              />
                                            </td>
                                          </tr>
                                        </tbody>
                                      );
                                    })}
                                </table>
                              ) : (
                                ""
                              )}
                            </>
                          );
                        })}
                    </div>
                  </div>
                </div>
              
              </div>
            </div>
           
          </CheckPermission>
        </div>
      </div>
    </Content>
  );
};

export default ThemeComponent;