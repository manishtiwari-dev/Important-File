import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import "./style.css";
import {
  TemplateStoreUrl,
  TemplateSettingUrl,
  TemplateUrl,
  TemplateSettingStoreUrl,
  TemplateSettingstore,
} from "config";
import { BadgeShow } from "component/UIElement/UIElement";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { Col, Row, Anchor, LoaderButton } from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import {
  PageTemplateSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import ModalImage from "react-modal-image-responsive";

function Theme() {
  const { apiToken, language } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [color, setColor] = useState("#FF0000");
  const [ForeGound, setForeGoundColor] = useState("#0000FF");
  const [Background, setBackgroundColor] = useState("#FFFF00");
  const [font, setfont] = useState("");
  const [fontsize, setfontsize] = useState("16");
  const [h1, seth1] = useState("24");
  const [h2, seth2] = useState("21");
  const [h3, seth3] = useState("18");
  const [selectData, SetselectData] = useState([]);

  const methods = useForm();
  const {
    register,
    control,
    formState: { errors },
    getValue,
    setValue,
    handleSubmit,
  } = methods;

  const [templateList, SettemplateList] = useState([]);

  const loadTemplateData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(TemplateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SettemplateList(data);
          loadTemplateSelectedData();
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const loadTemplateSelectedData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(TemplateSettingUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetselectData(data);
          setValue("theme_color", setColor(data["theme_color"]));
          setValue(
            "theme_bg_color",
            setBackgroundColor(data["theme_bg_color"])
          );
          setValue("theme_fg_color", setForeGoundColor(data["theme_fg_color"]));
          setValue("theme_font_size", setfontsize(data["theme_font_size"]));
          setValue("theme_font", setfont(data["theme_font"]));

          setValue("theme_h1", seth1(data["theme_h1"]));

          setValue("theme_h2", seth2(data["theme_h2"]));

          setValue("theme_h3", seth3(data["theme_h3"]));
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    document.title = "Template Setting | WorkerMan";

    let abortController = new AbortController();
    loadTemplateData();
    loadTemplateSelectedData();
    return () => abortController.abort();
  }, []);

  const selectedHtml = (key, value) => {
    console.log("selectData", selectData);
    for (const selectKey in selectData) {
      if (selectKey === key) {
        if (selectData[key] === value) return true;
      }
    }

    return false;
  };

  // handle choosen
  const changeTemplateTheme = (templateKey, templateValue) => {
    const filterData = {
      api_token: apiToken,
      template_key: templateKey,
      template_value: templateValue,
    };
    POST(TemplateSettingStoreUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        loadTemplateSelectedData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeTemplateThemestore = (
    theme_bg_color,
    theme_color,
    theme_fg_color,
    theme_font,
    theme_font_size,
    theme_h1,

    theme_h2,

    theme_h3
    // templateValue
  ) => {
    const filterData = {
      api_token: apiToken,
      theme_font_size: theme_font_size,
      theme_bg_color: theme_bg_color,
      theme_color: theme_color,
      theme_fg_color: theme_fg_color,
      theme_font: theme_font,
      theme_h1: theme_h1,

      theme_h2: theme_h2,

      theme_h3: theme_h3,

      // template_key: templateValue,
    };
    POST(TemplateSettingstore, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        loadTemplateSelectedData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(TemplateSettingstore, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          // props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        console.log(error);
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };
  return (
    <Content>
      <CheckPermission PageAccess={PageTemplateSetting} PageAction={PreView}>
        <React.Fragment>
          <PageHeader
            breadcumbs={[
              { title: Trans("DASHBOARD", language), link: "/", className: "" },
              { title: Trans("SETTING", language), link: "/", className: "" },
              {
                title: Trans("TEMPLATE", "language"),
                link: "/",
                className: "active",
              },
            ]}
          />

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission
                PageAccess={PageTemplateSetting}
                PageAction={PreView}
              >
                {/* template-select ends */}
                <div className="card">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      {Trans("TEMPLATE_LIST", language)}
                    </h6>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Row>
                        {templateList &&
                          templateList.map((template, idx) => {
                            const templateVal = selectData?.default_theme;
                            let active = "";
                            if (template.template_key === templateVal)
                              active = "active-theme";
                            return (
                              <Col col={4} key={idx} className="mb-3">
                                <div className={`card theme-card ${active}`}>
                                  {active === "" && (
                                    <button
                                      type="button"
                                      className="btn btn-light custom-btn"
                                      onClick={(e) => {
                                        e.preventDefault();
                                        changeTemplateTheme(
                                          "default_theme",
                                          template?.template_key
                                        );
                                      }}
                                    >
                                      <label className="custom-control custom-switch">
                                        <input
                                          type="checkbox"
                                          className="custom-control-input"
                                          id={template?.template_key}
                                          checked={
                                            active === "" ? "" : "checked"
                                          }
                                        />
                                        <label
                                          className="custom-control-label"
                                          For={template?.template_key}
                                        ></label>
                                      </label>
                                    </button>
                                  )}
                                  {active != "" ? (
                                    <button
                                      type="button"
                                      className="btn btn-light custom-btn"
                                    >
                                      <label className="custom-control custom-switch">
                                        <input
                                          // onClick={(e) => {
                                          //   changeTemplateTheme(
                                          //     "active-theme",
                                          //     template?.template_key
                                          //   );
                                          // }}
                                          type="checkbox"
                                          className="custom-control-input"
                                          id="customSwitch1"
                                          disabled
                                          checked="checked"
                                        />
                                        <label
                                          className="custom-control-label"
                                          For="customSwitch1"
                                        ></label>
                                      </label>
                                    </button>
                                  ) : (
                                    ""
                                  )}
                                  <div
                                    className="card-body"
                                    style={{ minHeight: "386px" }}
                                  >
                                    <p className="text-center">
                                      <b>{template.template_name}</b>
                                    </p>
                                    <div className="">
                                      <ModalImage
                                        small={template.image}
                                        large={template.image}
                                        alt={template.image}
                                        className="modalImage"
                                      />
                                    </div>
                                    <br />
                                    <div className="text-center">
                                      <Anchor
                                        path={WebsiteLink(
                                          `/themes/design/${template.template_id}`
                                        )}
                                        className="btn btn-dark custom-btn"
                                      >
                                        <b>
                                          {Trans("CUSTOMIZE_DESIGN", language)}
                                        </b>
                                      </Anchor>
                                      <Anchor
                                        path={WebsiteLink(
                                          `/themes/component/${template.template_id}`
                                        )}
                                        className="btn btn-info custom-btn"
                                      >
                                        <b>
                                          {Trans("MANAGE_SECTION", language)}
                                        </b>
                                      </Anchor>
                                    </div>

                                    <div className="text-center pd-10"></div>
                                  </div>
                                </div>
                              </Col>
                            );
                          })}
                      </Row>
                    </div>
                  )}
                </div>

                {/* template-select-starts */}
                <div className="card mt-2">
                  {/* CARD HEADER */}
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      {Trans("TEMPLATE_SETTING", language)}
                    </h6>
                  </div>
                  <div className="card-body">
                    <form action="#" onSubmit={handleSubmit} noValidate>
                      <div className="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("FONT", language)}</b>
                            </label>
                            <select
                              className="form-control"
                              name="theme_font"
                              onChange={(e) => setfont(e.target.value)}
                              value={font}
                            >
                              <option selected disabled>
                                {Trans("CHOOSE_FONT", language)}
                              </option>
                              <option value="Helvetica">Helvetica</option>
                              <option value="Arial">Arial</option>
                              <option value="Verdana">Verdana</option>
                              <option value="Tahoma">Tahoma</option>
                              <option value="Impact">Impact</option>
                              <option value="Trebuchet MS">Trebuchet MS</option>
                            </select>
                          </div>
                        </div>


                        <div class="col-md-6">
                          <div class="form-group">
                            <label htmlFor="">
                              <b> {Trans("FONT_SIZE", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="range"
                                id="vol"
                                name="vol"
                                min="0"
                                max="30"
                                value={fontsize}
                                onChange={(e) => setfontsize(e.target.value)}
                              />
                              <input
                                type="number"
                                value={fontsize}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                              />
                              <input
                                type="hidden"
                                value={fontsize}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                                name="theme_font_size"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("BUTTON_TEXT_COLOR", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="color"
                                value={color}
                                onChange={(e) => setColor(e.target.value)}
                                style={{
                                  height: "calc(1.5em + 0.9375rem + 2px)",
                                }}
                              />
                              <input
                                type="text"
                                value={color}
                                className="form-control"
                                name="theme_color"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("BUTTON_BACKGROUND_COLOR", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="color"
                                value={Background}
                                onChange={(e) =>
                                  setBackgroundColor(e.target.value)
                                }
                                style={{
                                  height: "calc(1.5em + 0.9375rem + 2px)",
                                }}
                              />
                              <input
                                type="text"
                                value={Background}
                                className="form-control"
                                name="theme_bg_color"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("FOREGROUND_COLOR", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="color"
                                value={ForeGound}
                                onChange={(e) =>
                                  setForeGoundColor(e.target.value)
                                }
                                style={{
                                  height: "calc(1.5em + 0.9375rem + 2px)",
                                }}
                              />
                              <input
                                type="text"
                                value={ForeGound}
                                className="form-control"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("H1", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="range"
                                id="vol"
                                name="vol"
                                min="0"
                                max="30"
                                value={h1}
                                // className="form-control"
                                onChange={(e) => seth1(e.target.value)}
                              />

                              <input
                                type="number"
                                value={h1}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                              />

                              <input
                                type="hidden"
                                value={h1}
                                style={{ width: "20%" }}
                                disabled
                                name="theme_h1"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("H2", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="range"
                                id="vol"
                                name="vol"
                                value={h2}
                                min="0"
                                max="30"
                                // className="form-control"
                                onChange={(e) => seth2(e.target.value)}
                              />
                              <input
                                type="number"
                                value={h2}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                              />

                              <input
                                type="hidden"
                                value={h2}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                                name="theme_h2"
                              />
                            </div>
                          </div>
                        </div>

                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="">
                              <b> {Trans("H3", language)}</b>
                            </label>
                            <div className="d-flex">
                              <input
                                type="range"
                                id="vol"
                                name="vol"
                                min="0"
                                max="30"
                                value={h3}
                                // className="form-control"
                                onChange={(e) => seth3(e.target.value)}
                              />
                              <input
                                type="number"
                                value={h3}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                              />

                              <input
                                type="hidden"
                                value={h3}
                                // className="form-control"
                                style={{ width: "20%" }}
                                disabled
                                name="theme_h3"
                              />
                            </div>
                          </div>
                        </div>

                      

                        <Col col={12} style={{ marginTop: "5%" }}>
                          <button
                            // formLoadStatus={formloadingStatus}

                            className="btn btn-primary btn-block"
                            onClick={(e) => {
                              e.preventDefault();
                              changeTemplateThemestore(
                                Background,
                                color,
                                ForeGound,
                                font,
                                fontsize,
                                h1,
                                h2,
                                h3
                                // selectData?.default_theme
                              );
                            }}
                          >
                            {Trans("SUBMIT", language)}
                          </button>
                        </Col>
                      </div>
                    </form>
                  </div>
                </div>
              </CheckPermission>
            </div>
          </div>
        </React.Fragment>
      </CheckPermission>
    </Content>
  );
}

export default Theme;
