import React, { useEffect, useState } from "react";
import { Row, Col ,TextArea,Radio} from "component/UIElement/UIElement";
import { useFormContext } from "react-hook-form";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import { tempUploadFileUrl } from "config/index";
import Notify from "component/Notify";



function SubcriberWebSetting({ fieldKey, HelperData, currKey }) {
  const { apiToken, userType,language } = useSelector((state) => state.login);

  const methods = useFormContext();

  const { register, control, setValue } = methods;

    // image show condition
const imageShowList = ["website_logo", "website_favicon", "preloader_image","newsletter_image"];

const imageKey = (key) => {
  return imageShowList.includes(key);
};

  // select condition
  const statusCond = [
    "PAYPAL_MODE",
    "STRIPE_MODE",
   
  ];

  const statusKey = (key) => {
    return statusCond.includes(key);
  };



                                         
                                

 const createSelectLabel = (data, selData = "") => {
  let labelData = [];
  let arrData = data.split(",");
  console.log("arrData", arrData);
  if (selData !== "") {
    for (let idx = 0; idx < selData.length; idx++) {
      const elVal = selData[idx]["value"];
      if (arrData.includes(elVal)) labelData.push(selData[idx]);
    }
  } else {
    for (let index = 0; index < arrData.length; index++) {
      labelData.push({
        label: arrData[index],
        value: arrData[index],
      });
    }
  }
  return labelData;
};

  const handleMultiSelectChange = (id, newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    setValue(id, listArr.join(","));
  };



  return (
    <React.Fragment>
      <Row>
        {fieldKey.map((item, idx) => {
     
     let optionValuesAry = '';
     if(item.setting_options != '' && item.setting_options != null && item.option_type == 'dropdown'){
       let optionString = item.setting_options;
       optionValuesAry = optionString.split(',');
     } else{
       optionValuesAry = '';
     }
     console.log(optionValuesAry);
    

         

                          
          return (
            <React.Fragment key={idx}>
             
              
      
        
                <React.Fragment>
                  {statusKey(item.method_key) ? (
                    <React.Fragment>
                      <Col col={6}>
                        <div className="form-group">
                          <label htmlFor="">
                          <b> {Trans(item.method_key, language)}: </b>
                          </label>

                          {/* switch case i nreact */}
                          {(() => {
                            switch (item.method_key) {
                              case "PAYPAL_MODE":
                                return (
                                  <React.Fragment>
                                    <select
                                       {...register(`${item.method_key}`)}
                                      placeholder={item.method_key}
                                      className="form-control"
                                      defaultValue={item.method_value}
                                    >
                                      <option value="">SELECT</option>
                                      { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                        
                                    </select>
                                  </React.Fragment>
                                );
                        
                               
                                case "STRIPE_MODE":
                                  return (
                                    <React.Fragment>
                                      <select
                                      {...register(`${item.method_key}`)}
                                        placeholder={item.method_key}
                                      className="form-control"
                                      defaultValue={item.method_value}
                                      >
                                        <option value="">SELECT</option>
                                        { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                                 
                                
                                      </select>
                                    </React.Fragment>
                                  );
                                  
                            
                                  
                              default:
                                return (
                                  <React.Fragment>
                                    <select
                                        {...register(`${item.method_key}`)}
                                      placeholder={item.method_key}
                                    className="form-control"
                                    defaultValue={item.method_value}
                                    >
                                      <option value="">SELECT</option>
                                      { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                               
                              
                                    </select>
                                  </React.Fragment>
                                );
                                // return (

                              
                                //   <React.Fragment>
                                   
                                //     <select
                                //       {...register(
                                //         `set_${currKey}.${idx}.setting_key`
                                //       )}
                                //       placeholder="Setting Value"
                                //       className="form-control"
                                //       id="selectNumber"
                                //       defaultValue={item.setting_value}
                                //     >
                                //  <option value="">SELECT</option>
                                //  { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                                               
                              
                                //     </select>
                                //   </React.Fragment>
                                // );
                              

                            }
                          })()}
                        </div>
                      </Col>
                    </React.Fragment>
                  ) : (
                    <Col col={6}>
                      <div className="form-group">
                  <label htmlFor="">
                    <b> {Trans(item.method_key, language)}: </b>
                  </label>
                <React.Fragment>
                 <input
                    {...register(`${item.method_key}`)}
                    placeholder={item.method_key}
                    className="form-control"
                    defaultValue={item.method_value}
                  />
                              </React.Fragment>
     
     
                          
                        
                      </div>
                    </Col>
                  )}
                </React.Fragment>
              
            </React.Fragment>
          );
        })}
      </Row>
    </React.Fragment>
  );
}

export default SubcriberWebSetting;

