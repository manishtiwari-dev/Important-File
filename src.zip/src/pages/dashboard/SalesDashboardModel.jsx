import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";

import Moment from "react-moment";
import Notify from "component/Notify";

import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

function SalesDashboardModel({ dashboardcontent }) {
  // console.log("transactionLog", JSON.parse(dashboardcontent));
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setTransaction(JSON.parse(dashboardcontent));
    return () => abortController.abort();
  }, [dashboardcontent]);

  console.log(transaction);

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
       
          <div className="d-flex">
            <h6>{Trans("ENQUIRY_NUMBER", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.enquiry_no}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("ENQUIRY_TYPE", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.enquiry_type}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("MESSAGE", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.message}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("PHONE", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.phone}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("CUSTOMER_NAME", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.customers_name}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("SUBJECT", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.subject}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SalesDashboardModel;
