import React from "react";

function PaymentPage() {
  return <></>;
}

export default PaymentPage;
