import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { Anchor } from "component/UIElement/UIElement";

import { Trans } from "lang/index";
import { ListingShowUrl, PagesCreateUrl ,productChangeStatusUrl} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import FeatherIcon from "feather-icons-react";
import Notify from "component/Notify";
import WebsiteLink from "config/WebsiteLink";
// import ProductInfo from "./component/Detail/ProductInfo";
// import ProductFeatured from "./component/Detail/ProductFeatured";
// import ProductFullInfo from "./component/Detail/ProductFullInfo";
// import { ProductEditDataContext } from "./ProductContext";
import { Alert, Tab, Tabs } from "react-bootstrap";
export default function Detail() {
  const findOptionName = (dataArray, findid) => {
    const attrname = dataArray.filter((data) => {
      return data.products_options_id === findid
        ? data.products_options_name
        : "";
    });
    return attrname.length > 0 ? attrname[0]["products_options_name"] : "";
  };

  const { proId } = useParams();


  let bod = new Array();
  let stringArray;
  let uniqueArray;
  const findOptionValueName = (dataArray, findid) => {
    let temp = new Array();
    var obj = {};
    dataArray.map((e) => {
      if (e.products_options_id == findid) {
        obj[e.products_options_values_id] = e.products_options_values_name;
      }
    });
    bod.push(obj);
  };

  console.log(bod);

  const { listing_id } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [DataList, SetDataList] = useState();
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);
  const [mainimg, setmainimg] = useState();
  // const [stat, setstatus] = useState();
  // const [attributes, setattributes] = useState([]);

  // function checkactive(e) {
  //   if (e == "active") {
  //     setstatus("green");
  //   } else if (e == "deactive") {
  //     setstatus("danger");
  //   } else {
  //     setstatus("warning");
  //   }
  // }
  const [EditData, setData] = useState();

  let stat;
  useEffect(() => {
    let abortController = new AbortController();
    const getData = () => {
      const editData = {
        api_token: apiToken,
        listing_id: proId,
      };
      POST(ListingShowUrl, editData)
        .then((response) => {
          const { status, data, message } = response.data;
          console.log(data);
          if (status) {
            SetloadingStatus(false);
            SetDataList(data);
          } else alert(message);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    };
    getData();

    return () => {
      // checkactive(DataList?.product_status);
      getData();
      abortController.abort();
    };
  }, [listing_id]);

  {
    DataList?.product_status == "active"
      ? (stat = "green")
      : DataList?.product_status == "deactive"
      ? (stat = "danger")
      : (stat = "warning");
  }
  let optionAry = new Array();
  let valueAry = new Array();



  {
    DataList?.productAttribute &&
      DataList?.productAttribute.map((attr, idx) => {
        {
          const index = optionAry.findIndex(
            (element) =>
              element === findOptionName(attr.option_list, attr.options_id)
          );
          if (index !== -1) {
            //array1.push(findOptionName(attr.option_list, attr.options_id));
          } else {
            let valueName = [];
            optionAry.push(findOptionName(attr.option_list, attr.options_id));
            attr?.option_value_list.map((attrval, idx) => {
              valueName.push(attrval.products_options_values_name);
            });
            valueAry.push(valueName);
          }
        }
      });
  }

  console.log(optionAry);
  console.log(valueAry);

  const ChangeFunction = (update_id, statusId) => {
    const editData = {
      api_token: apiToken,
      update_id: update_id,
      statusId: statusId,
    };
    POST(productChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        // filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const [showType, SetShowType] = useState("");
  const stSarr = ["Draft", "Active", "Inactive"];
  const stSarrC = ["warning", "success", "danger"];
  const StatusChange = (quoteId, statusId) => {
    ChangeFunction(quoteId, statusId);
  };
  const [langList, SetlangList] = useState([]);
  const [key, setKey] = useState("default_language");

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
    };
    POST(PagesCreateUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        console.log(data);
        if (status) {
          SetlangList(data.language);
          // setValueToField();
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
        console.error("There was an error!", error);
      });
    return () => abortController.abort();
  }, []);

  return (
    <Content>
   <PageHeader
        breadcumbs={[
          {
            title: Trans("DASHBOARD", language),
            link: WebsiteLink("/"),
            class: "",
          },
          {
            title: Trans("LISTING", language),
            link: WebsiteLink("/business-listing"),
            class: "",
          },
         
        ]}
        // heading={Trans("VIEW_STAFF", language)}
      />
    <div className="container-fluid mt-5 mb-5">
          <div className="row g-0">
            {DataList?.listing_image && (
              <div className="col-md-4 border-end">
                <div className="d-flex flex-column justify-content-center">
                  <div className="product_carousel">
                   
                    <img
                      src={mainimg ? mainimg : DataList?.listing_image}
                      id="main_product_image"
                      width="350"
                    />{" "}
                  </div>
                  <div className="thumbnail_images">
                    <ul id="thumbnail">
                      {DataList?.gallery_image.map((material, index = 1) => {
                        return (
                          // console.log(material);
                          <>
                            <li>
                              <img
                                onClick={() => setmainimg(material)}
                                src={material}
                                width="70"
                              />
                            </li>
                          </>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                {/* {DataList?.productdescription_with_lang && (
                  <>
                    {DataList?.productdescription_with_lang.map((oldlist) => {
                      return (
                        <div className="card mg-b-20 mg-lg-b-25">
                          <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                            <h6 className="tx-uppercase tx-semibold mg-b-0">{` PRODUCT DESCRIPTION (${oldlist.languages_name}) `}</h6>
                          </div>
                         
                          <div className="card-body pd-25">
                         
                            <div className="media d-block d-sm-flex">
                              <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      DataList?.productdescription[
                                        oldlist.languages_id - 1
                                      ]?.products_description,
                                  }}
                                ></div>
                              </div>
                            </div>
                          
                          </div>
                         
                        </div>
                      );
                    })}
                  </>
                )} */}
              </div>
            )}
            <div className="col-md-8">
              <div className="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">
                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                    {Trans("LISTING_INFORMATION", language)}
                    </h6>
                    <div className="product_btn">
                   
                    </div>
                  
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="d-flex justify-content-between">
                          <div>
                            <h5 className="mb-0">
                              {DataList?.productdescription[0]?.listing_name}
                            </h5>
                          </div>
                          <div>
                     
                        
                          
                          </div>
                        </div>
                        <div className="table  table-dashboard">
                        <Tabs
        id="controlled-tab-example"
      
        onSelect={(k) => setKey(k)}
        className="mb-3"
      >
        {langList &&
          langList.map((lang) => {
            const { languages_code, languages_id, languages_name } = lang;

       

            return (
              <Tab
                eventKey={languages_code}
                key={languages_id}
                title={languages_name}
              >
                   <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("LISTING_NAME", language)}</td>
                                    <td>
                                      {
                                        DataList?.productdescription[0]
                                          ?.listing_name
                                      }
                                    </td>
                                  </>
                                )}
                              </tr>
                              {/* <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("LISTING_DESCRIPTION", language)}</td>
                                    <td className="data">
                                      {
                                        DataList?.productdescription[0]
                                          ?.listing_description
                                      }
                                    </td>
                                  </>
                                )}
                              </tr> */}
                               {DataList?.selected_category && (
                                <>
                                  {DataList.selected_category.map((list) => {
                                    return (
                                      <tr>
                                        <td>
                                          {" "}
                                          {Trans("Category :", language)}
                                        </td>
                                        <td>{list.label}</td>
                                      </tr>
                                    );
                                  })}
                                </>
                              )} 
                              {/* {DataList?.product_model && (
                                <tr>
                                  <td> {Trans("Model No :", language)}</td>
                                  <td> {DataList?.product_model}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.product_sku && (
                                <tr>
                                  <td> {Trans("PRODUCT_SKU", language)}</td>
                                  <td> {DataList?.product_sku}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.product_condition && (
                                <tr>
                                  <td>
                                  
                                  {Trans("PRODUCT_CONDITION", language)}
                                  </td>
                                  <td>
                                 
                                    {DataList?.product_condition == "1"
                                      ? "New"
                                      : "Refurbished"}
                                  </td>
                                </tr>
                              )} */}

              
                               
                           

                              {/* {DataList?.product_discount_type && (
                                <tr>
                                  <td> {Trans("DISCOUNT_TYPE :", language)}</td>
                                  <td>{DataList?.product_discount_type}</td>
                                </tr>
                              )}
                              {DataList?.product_discount_amount && (
                                <tr>
                                  <td>
                                    {Trans("PRODUCT_DISCOUNT_AMOUNT", language)}
                                  </td>
                                  <td>{DataList?.product_discount_amount}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.products_type_field_value.map((e) => {
                                return (
                                  <tr>
                                    <td> {e.field_label}</td>
                                    <td>{e.field_value}</td>
                                  </tr>
                                );
                              })} */}
                            </tbody>
                          </table>
            
              </Tab>
            );
          })}
      </Tabs>
                          {/* <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("LISTING_NAME", language)}</td>
                                    <td>
                                      {
                                        DataList?.productdescription[0]
                                          ?.listing_name
                                      }
                                    </td>
                                  </>
                                )}
                              </tr>
                               {DataList?.selected_category && (
                                <>
                                  {DataList.selected_category.map((list) => {
                                    return (
                                      <tr>
                                        <td>
                                          {" "}
                                          {Trans("Category :", language)}
                                        </td>
                                        <td>{list.label}</td>
                                      </tr>
                                    );
                                  })}
                                </>
                              )} 
                              {/* {DataList?.product_model && (
                                <tr>
                                  <td> {Trans("Model No :", language)}</td>
                                  <td> {DataList?.product_model}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.product_sku && (
                                <tr>
                                  <td> {Trans("PRODUCT_SKU", language)}</td>
                                  <td> {DataList?.product_sku}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.product_condition && (
                                <tr>
                                  <td>
                                  
                                  {Trans("PRODUCT_CONDITION", language)}
                                  </td>
                                  <td>
                                 
                                    {DataList?.product_condition == "1"
                                      ? "New"
                                      : "Refurbished"}
                                  </td>
                                </tr>
                              )} */}

              
                               
                           

                              {/* {DataList?.product_discount_type && (
                                <tr>
                                  <td> {Trans("DISCOUNT_TYPE :", language)}</td>
                                  <td>{DataList?.product_discount_type}</td>
                                </tr>
                              )}
                              {DataList?.product_discount_amount && (
                                <tr>
                                  <td>
                                    {Trans("PRODUCT_DISCOUNT_AMOUNT", language)}
                                  </td>
                                  <td>{DataList?.product_discount_amount}</td>
                                </tr>
                              )} */}
                              {/* {DataList?.products_type_field_value.map((e) => {
                                return (
                                  <tr>
                                    <td> {e.field_label}</td>
                                    <td>{e.field_value}</td>
                                  </tr>
                                );
                              })} */}
                            {/* </tbody>
                          </table>  */}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

         
                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      PRODUCT FEATURE
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                <>
                                  {DataList?.product_feature.map((lit) => {
                                    return (
                                      <td>{`${lit.feature_title}  :  ${lit.feature_value}`}</td>
                                    );
                                  })}
                                </>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                    {Trans("PRODUCT_PRICE", language)}
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                <>
                                  {DataList?.product_price.map((lit) => {
                                    return (
                                      <td>{Trans("RATE_TYPE", language)}{" "}:{`${lit.rate_type}`}</td>
                                     
                                    );
                                  })}
                                </>
                              </tr>
                              <tr>
                                <>
                                  {DataList?.product_price.map((lit) => {
                                    return (
                                      <td>{Trans("BASE_RATE", language)}{" "}:{`${lit.base_rate}`}</td>
                                    );
                                  })}
                                </>
                              </tr>


                            
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
      </Content>
   

  );
}

