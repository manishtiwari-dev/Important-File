import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import {
    FormStoreUrl,
  tempUploadFileUrl,
  
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Anchor,
  StatusSelect,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";
import Feature from "./component/Create/Field";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";

const Create = () => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const methods = useForm({
    defaultValues: {
        form_field: [{ field_label: "", field_name: "" ,field_type:"", field_values:"",required:"" ,field_class:"",sort_order:""}],
     
    },
  });

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;
  const [field, SetFeature] = useState([]);

  const onSubmit = (formData) => {
    // console.log("formData", formData);
    SetformloadingStatus(true);
   

    const saveFormData = formData;
    saveFormData.api_token = apiToken;
     saveFormData.api_token = apiToken;
  
    console.log("saveFormData", saveFormData);
    // return "";

    POST(FormStoreUrl, saveFormData)
      .then((response) => {
        console.log("response", response);
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

 


  
  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
       <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <Row>
                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_NAME", language)}
                label={Trans("FORM_NAME", language)}
                placeholder={Trans("FORM_NAME", language)}
                className="form-control form-control-sm"
                {...register("form_name", {
                  required: Trans("FORM_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_name" />
              </span>
            </FormGroup>
          </Col>

          <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_SHORTCODE", language)}
                label={Trans("FORM_SHORTCODE", language)}
                placeholder={Trans("FORM_SHORTCODE", language)}
                className="form-control form-control-sm"
                {...register("form_shortcode", {
                  required: Trans("FORM_SHORTCODE_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_shortcode" />
              </span>
            </FormGroup>
          </Col>
       
          <Col col={6}>
          <FormGroup mb="20px">
          <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("FORM_TYPE", language)}
                >
                  {Trans("FORM_TYPE", language)}
                </Label>
              <select
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("form_type", {
                  required: Trans("FORM_TYPE_REQUIRED", language),
                })}
              >
               <option value="">SELECT_FORM_TYPE</option>
               <option value={1}>Enquiry</option>
               <option value={2}>Lead</option>
               <option value={3}>Quotation</option>
               <option value={4}>Ticket</option>
        </select>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id="Status"
                label={Trans("STATUS", language)}
                defaultValue={1}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
              />
            
            </FormGroup>
          </Col>
          <br/>
             <Feature field={field} />
                      <Col col={12} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("CREATE", language)}
                          className="btn btn-primary btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                </FormProvider>
    </>
  );
};

export default Create;
