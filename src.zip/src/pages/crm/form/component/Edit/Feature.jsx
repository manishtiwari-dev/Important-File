import React, { useState, useEffect,useRef } from "react";

import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";

function Feature({ editFeature, editLoad,props }) {
  const { language } = useSelector((state) => state.login);

  const a = useRef(null);

  const methods = useFormContext();

  const {
    register,
    control,
    formState: { errors },
  } = methods;

  const productFeature = useFieldArray({
    control,
    name: "form_field",
  });
  const [selectType, SetSelectType] = useState("submit");
  const [selectlabel, SetSelectLabel] = useState("field_label");


  // useEffect(() => {
  //   if (editFeature !== undefined) {
  //     let feature = [];
  //     for (let index = 0; index < editFeature.length; index++) {
  //       const elem = editFeature[index];
  //       feature.push({
  //           field_label: elem.field_label,
  //           field_name: elem.field_name,
  //           field_type: elem.field_type,
  //           field_values: elem.field_values,
  //           required: elem.required,

            
  //       });
  //     }
  //     productFeature.append(feature);
  //   }
  // }, [editLoad]);

  

  
  const myfun =()=>  {
 
    var a = document.getElementById("slug-source").value;

    var b = a.toLowerCase().replace(/ /g, '-')
        .replace(/[^\w-]+/g, '');

    document.getElementById("slug-target").value = b;

};




  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("FORM_FIELD", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-xs btn-info"
              onClick={() => {
                productFeature.prepend({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE_FIELD", language)}
            </button>
          </span>
        </Card.Header>

        {productFeature.fields && (
          <Card.Body>
         {productFeature.fields.map((item, index) => {
              return (
                <Row key={item.id}>
                  <Col  col={2}  className="px-1">
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_label`)}
                        className="form-control  form-control-sm"
                        id={`slug-source`}
                        placeholder={Trans("FIELD_LABEL", language)}
                        onKeyUp={() => {
                          myfun();
                        }} 
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_label`}
                        />
                      </span>
                    </FormGroup>
                  </Col>
                  
                  <Col  col={1}  className="px-1">
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_name`)}
                        className="form-control  form-control-sm"
                        id={`slug-target`}
                        placeholder={Trans("FIELD_NAME", language)}
                        readOnly={true}
                      />
                     
                    </FormGroup>
                  </Col>
         
                  <Col col={2} className="px-1">
                    <FormGroup>
                    <select
                id="FIELD_TYPE"
                label={Trans("FIELD_TYPE", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm px-1"
                {...register(`form_field.${index}.field_type`)}
                placeholder={Trans("FIELD_TYPE", language)}
              
                onChange={(event) => {
                  SetSelectType(event.target.value);
                }}
              >
               <option value="">SELECT_FIELD_TYPE</option>
               <option value="text">Text</option>
               <option value="checkbox" defaultValue="checkbox">Checkbox</option>
               <option value="dropdown" defaultValue="dropdown">Dropdown</option>
               <option value="radio">Radio</option>
               <option value="email">Email</option>
               <option value="textarea">Textarea</option>
               <option value="submit">Submit</option>
 
             </select>
                      
               </FormGroup>
                  </Col>

                  {selectType ==="dropdown" ?
                  <>
                   <Col col={2}  className="px-1">
                  <FormGroup>
                    <input
                      {...register(`form_field.${index}.field_values`)}
                      className="form-control form-control-sm px-1"
                      id={`proFeature.${index}.field_values`}
                      placeholder="Multiple use comma seperate"
                    />
                  
                  </FormGroup>
                </Col>
                <Col col={2} px={1}>
                  <FormGroup>
                    <input
                      {...register(`form_field.${index}.field_class`)}
                      className="form-control form-control-sm px-1"
                      id={`proFeature.${index}.field_values`}
                      placeholder={Trans("FIELD_CLASS", language)}
                    />
                   
                  </FormGroup>
                </Col>
                </>
                 :<>
                 
                  {selectType ==="checkbox"  ? <>
                  <Col col={2}  className="px-1">
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_values`)}
                        className="form-control form-control-sm px-1"
                        id={`proFeature.${index}.field_values`}
                        placeholder="Multiple use comma seperate"
                      />
                      
                    
                    </FormGroup>
                  </Col>
                  <Col col={2} className="px-1">
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_class`)}
                        className="form-control form-control-sm px-1"
                        id={`proFeature.${index}.field_values`}
                        placeholder={Trans("FIELD_CLASS", language)}
                      />
                     
                    </FormGroup>
                  </Col>
                  </>
              
                  :
                  <>
                   <Col col={2} className="px-1">
                    <FormGroup>
                      <input
                        {...register(`form_field.${index}.field_class`)}
                        className="form-control form-control-sm px-1"
                        id={`proFeature.${index}.field_values`}
                        placeholder={Trans("FIELD_CLASS", language)}
                      />
                     
                    </FormGroup>
                  </Col>
                  </>}
                 
                 </> }

                 <Col  col={2} className="px-1">
                    <FormGroup>
                      <input
                       type="number"
                        {...register(`form_field.${index}.sort_order`)}
                        className="form-control  form-control-sm"
                        id={`proFeature.${index}.sort_order`}
                        placeholder={Trans("SORT_ORDER", language)}
                      />
                    
                    </FormGroup>
                  </Col>
                
                 
                  <Col col={1} className="px-1">
                    <FormGroup>
                    <select
                id="REQUIRED"
                label={Trans("REQUIRED", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register(`form_field.${index}.required`)}
                placeholder={Trans("REQUIRED", language)}
              >
               <option value="">REQUIRED</option>
               <option value={1}>Yes</option>
               <option value={0}>No</option>
             </select>
                      
               </FormGroup>
                  </Col>
                
                  <Col col={1} className="px-1">
                    <span style={{ lineHeight: "42px" }}>
                      <FeatherIcon
                        icon="x-square"
                        color="red"
                        onClick={() => productFeature.remove(index)}
                        size={20}
                      />
                    </span>
                  </Col>
                </Row>
              );
            })}
          </Card.Body>
        )}

       
        
      </Card>
    </Col>
  );
}

export default Feature;
