import React, { useState } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import { useParams } from "react-router-dom";
import {
  FormUpdateUrl,
  tempUploadFileUrl,
  productCreateUrl,
  FormEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import Select from "react-select";
import Feature from "./component/Edit/Feature";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect ,
  Anchor,
  Label,
  GalleryImagePreviewWithUploadWithItem,
} from "component/UIElement/UIElement"
import Loading from "component/Preloader";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { useEffect } from "react";
import { ErrorMessage } from "@hookform/error-message";

const Edit = (props) => {
  const { proId } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const navigate = useNavigate();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const { editData } = props;

  const [editProAttribute, SetEditProAttribute] = useState();
  const [editLoad, SeteditLoad] = useState(false);

  const methods = useForm();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    getValues,
  } = methods;

  const onSubmit = (formData) => {
    // console.log("formData", formData);
    SetformloadingStatus(true);
  

    const saveFormData = formData;
    saveFormData.api_token = apiToken;
  

    POST(FormUpdateUrl, saveFormData)
      .then((response) => {
        // console.log("response", response);
        SetformloadingStatus(false);
        const { status, message, data } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });

          Notify(true, Trans(message, language));
        
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };
  
  const [editInfo, SeteditInfo] = useState("");
  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const editInfo = {
        api_token: apiToken,
        form_id: editData,
      };
      POST(FormEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          
          SeteditInfo(data);
          const fieldList = getValues();
          for (const key in fieldList) {
            console.log(key, data[key]);
            setValue(key, data[key]);
          }
          SeteditLoad(true);
        })
        
        .catch((error) => {
          console.log(error);
          SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => {
      // setValueToField();
      abortController.abort();
    };
  }, []);

  // useEffecr Re-render when all edit data set
  // useEffect(() => {}, [selectedSupplier]);

  

  // useEffect(() => {
  //   setValue("product_tags", productTags.join(","));
  // }, [productTags])

  // const createSelectLabel = () => {};

  const createSelectLabel = (data, selData = "") => {
    return data;

    let labelData = [];
    console.log("data", data);
    console.log("selData", selData);

    // if (data.length > 0) {
    //   labelData = selData.filter((item) => {
    //     let boolS = false;
    //     for (let index = 0; index < data.length; index++) {
    //       const valId = data[index]["value"];
    //       if ((item.value = valId)) {
    //         boolS = true;
    //         break;
    //       }
    //     }
    //     return boolS;
    //   });
    // }

    // console.log("labelData", labelData);
    return labelData;
  };
  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}
                        <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <input type="hidden" {...register("form_id")} />
                    <Row>


                          
                    
                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_NAME", language)}
                label={Trans("FORM_NAME", language)}
                placeholder={Trans("FORM_NAME", language)}
                className="form-control form-control-sm"
                {...register("form_name", {
                  required: Trans("FORM_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_name" />
              </span>
            </FormGroup>
          </Col>

          <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_SHORTCODE", language)}
                label={Trans("FORM_SHORTCODE", language)}
                placeholder={Trans("FORM_SHORTCODE", language)}
                className="form-control form-control-sm"
                {...register("form_shortcode", {
                  required: Trans("FORM_SHORTCODE_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_shortcode" />
              </span>
            </FormGroup>
          </Col>
       
          <Col col={6}>
          <FormGroup mb="20px">
          <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("FORM_TYPE", language)}
                >
                  {Trans("FORM_TYPE", language)}
                </Label>
              <select
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className=" form-control form-control-sm"
                {...register("form_type", {
                  required: Trans("FORM_TYPE_REQUIRED", language),
                })}
              >
               <option value="">SELECT_FORM_TYPE</option>
               <option value={1}>Enquiry</option>
               <option value={2}>Lead</option>
               <option value={3}>Quotation</option>
               <option value={4}>Ticket</option>
        </select>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id="Status"
                label={Trans("STATUS", language)}
                defaultValue={1}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
              />
            
            </FormGroup>
          </Col>
      
          <br/>
                     
                    

                 

                      <Feature
                        editFeature={editInfo?.form_field}
                        editLoad={editLoad}
                      />
                   
                    


                      <Col col={12} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("UPDATE", language)}
                          className="btn btn-primary btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                  </FormProvider>
        </>
      )}
    </>
  );
};

export default Edit;
