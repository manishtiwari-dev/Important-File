import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import { customerStoreUrl, leadCreateUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import MultipleContact from "./component/MultipleContact";
import MultipleAddress from "./component/MultipleAddress";

const Create = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const { source, country } = props;
  console.log(props.source);
  const methods = useForm({
    defaultValues: {
      // contactAdd: [{ contact_name: "", contact_email: "" }],
      mulAddress: [
        {
          address_type: "",
          street_address: "",
          city: "",
          state: "",
          zipcode: "",
          countries_id: "",
          phone: "",
        },
      ],
    },
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = methods;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(customerStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.handleModalClose();
          Notify(true, Trans(message, language));
          props.filterItem("refresh", "", "");
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        console.log(error);
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <FormProvider {...methods}>
        <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
          <Row>
          <Col col={12} >
          <fieldset className="form-fieldset">
                          <legend>
                            {Trans("PRIMARY_CONTACT_INFO", language)}
                          </legend>
                          <Row>
                     
                     <Col col={4}>
                       <FormGroup mb="20px">
                         <Label
                           display="block"
                           mb="5px"
                           htmlFor={Trans("LEAD_ID", language)}
                         >
                           {Trans("LEAD_ID", language)}
                         </Label>
                         <select
                           id={Trans("LEAD_ID", language)}
                           placeholder={Trans("LEAD_ID", language)}
                           className="form-control"
                           {...register("lead_id", {
                             required: Trans("LEAD_ID_REQUIRED", language),
                           })}
                         >
                           <option value="">{Trans("SELECT_LEAD", language)}</option>
                           {source &&
                             source.map((curr) => (
                               <option value={curr.lead_id} key={curr.lead_id}>
                                 {curr.contact_name}
                               </option>
                             ))}
                         </select>
         
                         <span className="required">
                           <ErrorMessage errors={errors} name="lead_id" />
                         </span>
                       </FormGroup>
                     </Col>
         
            

                <Col col={4}>
                       <FormGroup mb="20px">
                         <Input
                           id="NAME"
                           label={Trans("NAME", language)}
                           placeholder={Trans("NAME", language)}
                           className="form-control"
                           {...register("first_name", {
                            required: Trans("NAME_REQUIRED", language),
                          })}
                          
                         />

                   <span className="required">
                           <ErrorMessage errors={errors} name="first_name" />
                         </span>
                      
                       </FormGroup>
                     </Col>



                     <Col col={4}>
                    <FormGroup mb="20px">
                      <Input
                        id="EMAIL"
                        label={Trans("EMAIL", language)}
                        placeholder={Trans("EMAIL", language)}
                        className="form-control"
                        {...register("email", {
                          required: Trans("EMAIL_REQUIRED", language),
                        })}
                      />
                      <span className="required">
                        <ErrorMessage errors={errors} name="email" />
                      </span>
                    </FormGroup>
                  </Col>

                  <Col col={4}>
                    <FormGroup mb="20px">
                      <Input
                        id="CONTACT_PHONE"
                        label={Trans("CONTACT_PHONE", language)}
                        placeholder={Trans("CONTACT_PHONE", language)}
                        className="form-control"
                        {...register("contact", {
                        
                        })}
                      />
                    
                    </FormGroup>
                  </Col>

                

                     <Col col={4}>
                  <FormGroup>
                    <Label display="block" mb="5px" htmlFor="gender">
                      {Trans("GENDER", language)}{" "}
                      <span className="required">*</span>
                    </Label>
                    <select
                      id="gender"
                      className="form-control"
                      {...register("gender", {
                      
                      })}
                    >
                      <option value="">
                        {Trans("SELECT_GENDER", language)}
                      </option>
                      <option value={1}>{Trans("MALE", language)}</option>
                      <option value={2}>{Trans("FEMALE", language)}</option>
                      <option value={3}>
                        {Trans("TRANSGENDER", language)}
                      </option>
                    </select>
                  </FormGroup>
                </Col>
                <Col col={4}>
                  <FormGroup>
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("DATE_OF_BIRTH", language)}
                    >
                      {Trans("DATE_OF_BIRTH", language)}{" "}
                      <span className="required">*</span>
                    </Label>
                    <input
                      id={Trans("DATE_OF_BIRTH", language)}
                      type="date"
                      placeholder={Trans("DATE_OF_BIRTH", language)}
                      className="form-control"
                      {...register("date_of_birth", {
                      
                      })}
                    />
                  </FormGroup>
                </Col>


                <Col col={4}>
                       <FormGroup mb="20px">
                         <Input
                           id="WEBSITE"
                           label={Trans("WEBSITE", language)}
                           placeholder={Trans("WEBSITE_OPTIONAL", language)}
                           className="form-control"
                           {...register("website", {
                            
                           })}
                         />
                       
                       </FormGroup>
                     </Col>


                     <Col col={4}>
                       <FormGroup mb="20px">
                         <Input
                           id="COMPANY_NAME"
                           label={Trans("COMPANY_NAME", language)}
                           placeholder={Trans("COMPANY_NAME_OPTIONAL", language)}
                           className="form-control"
                           {...register("company_name", {
                            
                           })}
                         />
                      
                       </FormGroup>
                     </Col>

              
                         </Row>
                        </fieldset>

                  </Col>          

                  <Col col={12} >
          <fieldset className="form-fieldset">
                          <legend>
                            {Trans("ADDRESS_INFO", language)}
                          </legend>
                          <Row>
                     
                          <Col col={12}>
                         <MultipleAddress country={country} />
                         </Col>

                         </Row>
                        </fieldset>

                  </Col>


       
            {/* <Col col={12}>
              <MultipleContact />
            </Col> */}
            {/* <Col col={12}>
              <MultipleAddress country={country} />
            </Col> */}

            <Col col={4
            } className="mt-3">
              <LoaderButton
                formLoadStatus={formloadingStatus}
                btnName={Trans("SUBMIT", language)}
                className="btn btn-primary btn-block"
              />
            </Col>
          </Row>
        </form>
      </FormProvider>
    </>
  );
};

export default Create;
