import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import { leadUpdateUrl, leadEditUrl, leadCreateUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";
import MultipleContact from "./component/MultipleContact";
import SocialLink from "./component/SocialLink";

const Edit = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const [contactData,SetContactData] =useState([]);

  const [contactFill, SetContactFill] = useState([
    { contact_name: "", contact_email: "" },
  ]);

  const [socialLinkFill, SetSocialLinkFill] = useState([
    { social_type: "", social_link: "" },
  ]);

  const methods = useForm({
    defaultValues: {
      contact: contactFill,
      socialLink: socialLinkFill,
    },
  });

  console.log("methods", methods);

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const { editData, source, industry, status, agent, country } = props;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(leadUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  // useEffect(() => {
  //   let abortController = new AbortController();

  //   return () => abortController.abort();
  // }, []);

  // selcted item
  const [selectedSource, SetSelectedSource] = useState("");
  // const [selectedIndustry, SetSelectedIndustry] = useState("");
  // const [selectedStatus, SetSelectedStatus] = useState("");
  // const [selectedAgent, SetSelectedAgent] = useState("");
  // const [selectedCountry, SetSelectedCountry] = useState("");
  const [editInfo, SeteditInfo] = useState("");

  const [selectedData, SetSelectedData] = useState([]);

  useEffect(() => {
    let abortController = new AbortController();

    async function setValueToField() {
      const formData = {
        api_token: apiToken,
        lead_id: editData,
      };

      POST(leadEditUrl, formData)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          SeteditInfo(data);

          console.log(editInfo);
          SetSelectedData(data);
          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }
          
          SetSelectedSource(data?.source_id);
          SetContactFill(data?.contact);
          SetSocialLinkFill(data?.socialLink);
          setValue("followup_id", data?.crm_lead_followup?.followup_id);
          setValue("website", data?.crm_lead_contact.website);
          setValue("street_address", data?.crm_lead_contact?.street_address);

          console.log(data?.crm_lead_contact.website);
          setValue("followup_status", data?.crm_lead_followup?.followup_status);
          setValue("next_followup", data?.crm_lead_followup?.next_followup);

          if (data?.crm_lead_contact.length > 0) {
            const lang_with_pro = data?.crm_lead_contact;
            for (let index = 0; index < lang_with_pro.length; index++) {
              const Website = lang_with_pro[index].website;
              const Addr = lang_with_pro[index].street_address;
              const other = lang_with_pro[index].other_email;
              const city = lang_with_pro[index].city;
            
              const state = lang_with_pro[index].state;
              const country = lang_with_pro[index].country_code;
              const Zip = lang_with_pro[index].zipcode;

              
            
              setValue(
                "website",
                Website
              );

              setValue(
                "street_address",
                Addr
              );

              setValue(
                "other_email",
                other
              );

              setValue(
                "street_address",
                Addr
              );
              setValue(
                "city",
                city
              );


              setValue(
                "state",
                state
              );

              
              setValue(
                "zipcode",
                Zip
              );
              
              setValue(
                "country_code",
                country
              );
              
            }
          }










        })
        .catch((error) => {
          SetloadingStatus(false);
          Notify(false, Trans(error.message, language));
        });

    }
    setValueToField();
    return () => abortController.abort();
  }, [editData]);

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}

          <FormProvider {...methods}>
            <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
              <input type="hidden" {...register("lead_id")} />
              <div className="container">
                <Row>
                  <fieldset>
                    <legend>Primary Contact Info</legend>
                    <Row>
                      <Col col={6}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("SOURCE", language)}
                          >
                            {Trans("SOURCE", language)}
                          </Label>
                          <select
                            id={Trans("SOURCE", language)}
                            placeholder={Trans("SOURCE", language)}
                            className="form-control"
                            {...register("source_id", {
                              required: Trans("SOURCE_REQUIRED", language),
                            })}
                          >
                            <option value="">
                              {Trans("SELECT_SOURCE", language)}
                            </option>
                            {source &&
                              source.map((curr) => (
                                <option
                                  value={curr.source_id}
                                  key={curr.source_id}
                                >
                                  {curr.source_name}
                                </option>
                              ))}
                          </select>

                          <span className="required">
                            <ErrorMessage errors={errors} name="source_id" />
                          </span>
                        </FormGroup>
                      </Col>
                      <Col col={6}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("Industry/Type/Group", language)}
                          >
                            {Trans("Industry/Type/Group", language)}
                          </Label>
                          <select
                            id={Trans("Industry/Type/Group", language)}
                            placeholder={Trans("Industry/Type/Group", language)}
                            className="form-control"
                            {...register("industry_id", {
                              required: Trans("INDUSTRY_REQUIRED", language),
                            })}
                          >
                            <option value="">
                              {Trans("SELECT_INDUSTRY", language)}
                            </option>
                            {industry &&
                              industry.map((curr) => (
                                <option
                                  value={curr.industry_id}
                                  key={curr.industry_id}
                                >
                                  {curr.industry_name}
                                </option>
                              ))}
                          </select>

                          <span className="required">
                            <ErrorMessage errors={errors} name="industry_id" />
                          </span>
                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Input
                            id="CONTACT_NAME"
                            label={Trans("CONTACT_NAME", language)}
                            placeholder={Trans("CONTACT_NAME", language)}
                            className="form-control"
                            {...register("contact_name", {
                              required: Trans(
                                "CONTACT_NAME_REQUIRED",
                                language
                              ),
                            })}
                          />
                          <span className="required">
                            <ErrorMessage errors={errors} name="contact_name" />
                          </span>
                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Input
                            id="CONTACT_EMAIL"
                            label={Trans("CONTACT_EMAIL", language)}
                            placeholder={Trans("CONTACT_EMAIL", language)}
                            className="form-control"
                            {...register("contact_email", {
                              required: Trans(
                                "CONTACT_EMAIL_REQUIRED",
                                language
                              ),
                            })}
                          />
                          <span className="required">
                            <ErrorMessage
                              errors={errors}
                              name="contact_email"
                            />
                          </span>
                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Input
                            id="CONTACT_PHONE"
                            label={Trans("CONTACT_PHONE", language)}
                            placeholder={Trans("CONTACT_PHONE", language)}
                            className="form-control"
                            {...register("phone", {
                              required: Trans(
                                "CONTACT_PHONE_REQUIRED",
                                language
                              ),
                            })}
                          />
                          <span className="required">
                            <ErrorMessage errors={errors} name="phone" />
                          </span>
                        </FormGroup>
                      </Col>
                    </Row>
                  </fieldset>

                  <fieldset>
                    <legend>Additional Contact Info</legend>
                    <Row>
                      <Col col={12}>
                        <Row>
                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="WEBSITE"
                                label={Trans("WEBSITE", language)}
                                placeholder={Trans("WEBSITE", language)}
                                className="form-control"
                                {...register("website")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="SECONDARY_EMAIL"
                                label={Trans("SECONDARY_EMAIL", language)}
                                placeholder={Trans("SECONDARY_EMAIL", language)}
                                className="form-control"
                                {...register("other_email")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="ADDRESS"
                                label={Trans("STREET_ADDRESS", language)}
                                placeholder={Trans("STREET_ADDRESS", language)}
                                className="form-control"
                                {...register("street_address")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="CITY"
                                label={Trans("CITY", language)}
                                placeholder={Trans("CITY", language)}
                                className="form-control"
                                {...register("city")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="STATE"
                                label={Trans("STATE", language)}
                                placeholder={Trans("STATE", language)}
                                className="form-control"
                                {...register("state")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id="ZIP"
                                label={Trans("ZIP", language)}
                                placeholder={Trans("ZIP", language)}
                                className="form-control"
                                {...register("zipcode")}
                              />
                            </FormGroup>
                          </Col>

                          <Col col={5}>
                            <FormGroup mb="20px">
                              <Label
                                display="block"
                                mb="5px"
                                htmlFor={Trans("COUNTRY", language)}
                              >
                                {Trans("COUNTRY", language)}
                              </Label>
                              <select
                                id={Trans("COUNTRY", language)}
                                placeholder={Trans("COUNTRY", language)}
                                className="form-control"
                                {...register("country_code")}
                                defaultValue={editInfo.crm_lead_contact?.country_code}
                              >
                                {/* <option value="">
                                  {Trans("SELECT_COUNTRY", language)}
                                </option> */}
                                {country &&
                                  country.map((curr) => (
                                    <option
                                      value={curr.countries_iso_code_2}
                                      // key={curr.countries_iso_code_2}
                                    >
                                      {curr.countries_name}
                                    </option>
                                  ))}
                              </select>
                            </FormGroup>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </fieldset>



                  <fieldset>
                    <legend>Social Contact Info</legend>
                    <Row>
                      <Col col={12}>
                        <SocialLink />
                      </Col>
                    </Row>
                  </fieldset>

                  {/* <fieldset>
                    <legend>Follow up</legend>
                    <Row>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("AGENT", language)}
                          >
                            {Trans("AGENT", language)}
                          </Label>
                          <select
                            id={Trans("AGENT", language)}
                            placeholder={Trans("AGENT", language)}
                            className="form-control"
                            {...register("agent_id")}
                          >
                            <option value="">
                              {Trans("SELECT_AGENT", language)}
                            </option>
                            {agent &&
                              agent.map((curr) => (
                                <option
                                  value={curr.agent_id}
                                  key={curr.agent_id}
                                >
                                  {curr.agent_alias}
                                </option>
                              ))}
                          </select>

                        
                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("PRIORITY", language)}
                          >
                            {Trans("PRIORITY", language)}
                          </Label>
                          <select
                            id={Trans("PRIORITY", language)}
                            placeholder={Trans("PRIORITY", language)}
                            className="form-control"
                            {...register("priority")}
                          >
                            <option value="">
                              {Trans("SELECT_PRIORITY", language)}
                            </option>
                            <option value={1}>{Trans("LOW", language)}</option>
                            <option value={2}>
                              {Trans("MEDIUM", language)}
                            </option>
                            <option value={3}>{Trans("HIGH", language)}</option>
                          </select>

                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <input type="hidden" {...register("followup_id")} />
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("FOLLOW_UP_STATUS", language)}
                          >
                            {Trans("FOLLOW_UP_STATUS", language)}
                          </Label>
                          <select
                            id={Trans("FOLLOW_UP_STATUS", language)}
                            placeholder={Trans("FOLLOW_UP_STATUS", language)}
                            className="form-control"
                            {...register("followup_status")}
                          >
                            <option value="">
                              {Trans("SELECT_FOLLOW_UP_STATUS", language)}
                            </option>
                            {status &&
                              status.map((curr) => (
                                <option
                                  value={curr.status_id}
                                  key={curr.status_id}
                                >
                                  {curr.status_name}
                                </option>
                              ))}
                          </select>
                        
                        </FormGroup>
                      </Col>
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("FOLLOW_UP", language)}
                          >
                            {Trans("FOLLOW_UP", language)}
                          </Label>
                          <select
                            id={Trans("FOLLOW_UP", language)}
                            placeholder={Trans("FOLLOW_UP", language)}
                            className="form-control"
                            {...register("folllow_up")}
                          >
                            <option value="">
                              {Trans("SELECT_FOLLOW_UP", language)}
                            </option>
                            <option value={1}>{Trans("YES", language)}</option>
                            <option value={2}>{Trans("NO", language)}</option>
                  
                          </select>

                      
                        </FormGroup>
                      </Col>{" "}
                      <Col col={4}>
                        <FormGroup mb="20px">
                          <Input
                            id="FOLLOWUP_SCHEDULE"
                            label={Trans("FOLLOWUP_SCHEDULE", language)}
                            placeholder={Trans("FOLLOWUP_SCHEDULE", language)}
                            className="form-control"
                            {...register("next_followup")}
                            type="date"
                          />
                         
                        </FormGroup>
                      </Col>
                    </Row>
                  </fieldset> */}

                  <Col col={4}>
                    <LoaderButton
                      formLoadStatus={formloadingStatus}
                      btnName={Trans("UPDATE", language)}
                      className="btn btn-primary btn-block mt-3"
                    />
                  </Col>
                </Row>
              </div>
            </form>
          </FormProvider>
        </>
      )}
    </>
  );
};

export default Edit;
