import React, { useEffect, useState } from "react";
import { Col, Row, Anchor } from "component/UIElement/UIElement";
import Content from "layouts/content";
import { leadViewUrl, leadFollowUpStoreUrl, leadCreateUrl } from "config";
import { Routes, Route, useParams } from "react-router-dom";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import PageHeader from "component/PageHeader";
import WebsiteLink from "config/WebsiteLink";

import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { Trans } from "lang/index";
import { Alert, Card, Button } from "react-bootstrap";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";
import {
  LoaderButton,
  FormGroup,
  Input,
  Label,
} from "component/UIElement/UIElement";
export default function Leadview() {
  const { apiToken, language } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  let { userId } = useParams();
  const [editDataInfo, SetEditDataInfo] = useState([]);
  const methods = useForm();
  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  const [followups, setfollowups] = useState("");
  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      lead_id: userId,
    };

    POST(leadViewUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        SetEditDataInfo([data]);
      })
      .catch((error) => {
        SetloadingStatus(false);
        Notify(false, Trans(error.message, language));
      });
  };
  console.log(followups);
  useEffect(() => {
    let abortController = new AbortController();

    setValueToField();
    return () => abortController.abort();
  }, [userId]);

  console.log("methods", methods);

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  // Notify(true, Trans("hello", language));
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(leadFollowUpStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          window.location.reload();

          Notify(true, Trans(message, language));
          //   props.filterItem("refresh", "", "");
          //   props.handleModalClose();
          setValueToField();
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };
  const [status, SetStatus] = useState([]);

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
    };
    POST(leadCreateUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetStatus(data?.leadstatus);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
        console.error("There was an error!", error);
      });
    return () => abortController.abort();
  }, []);

  editDataInfo &&
    editDataInfo.map((data, index) => {
      let a;
      console.log(a);
      // setValue(
      //   "followup_status",
      //   data?.crm_lead_status[data?.crm_lead_followup.followup_status]
      //     .status_name
      // );
    });

  return (
    <Content>
      <PageHeader
        breadcumbs={[
          { title: Trans("DASHBOARD", language), link: "/", class: "" },
          {
            title: Trans("LEAD", language),
            link: "/lead",
            class: "",
          },
        ]}
      />
      <div>
        <div className="row">
          <div className="container-fluid">
            {editDataInfo &&
              editDataInfo.map((data, index) => {
                return (
                  <>
                    <div className="row">
                      <div className="col-lg-6">
                        <div className="boxes">
                          <div className="">
                            {editDataInfo &&
                              editDataInfo.map((data, index) => {
                                return (
                                  <>
                                    <div className="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
                                      <div className="d-sm-flex align-items-center justify-content-between">
                                        <div>
                                          <h4 className="mg-b-0">
                                            {Trans("DETAILS", language)}
                                          </h4>
                                        </div>
                                        <div className="search-form mg-t-20 mg-sm-t-0"></div>
                                      </div>

                                      <div className="box">
                                        <label className="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">
                                          {Trans(
                                            "PRIMARY_CONTACT_INFO",
                                            language
                                          )}
                                        </label>
                                        <ul className="list-unstyled profile-info-list">
                                          <>
                                            {data?.crm_lead_source
                                              .source_name ? (
                                              <li>
                                                <svg
                                                  xmlns="http://www.w3.org/2000/svg"
                                                  width="24"
                                                  height="24"
                                                  viewBox="0 0 24 24"
                                                  fill="none"
                                                  stroke="currentColor"
                                                  stroke-width="2"
                                                  stroke-linecap="round"
                                                  stroke-linejoin="round"
                                                  className="feather feather-globe"
                                                >
                                                  <circle
                                                    cx="12"
                                                    cy="12"
                                                    r="10"
                                                  ></circle>
                                                  <line
                                                    x1="2"
                                                    y1="12"
                                                    x2="22"
                                                    y2="12"
                                                  ></line>
                                                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                                                </svg>

                                                {
                                                  data?.crm_lead_source
                                                    .source_name
                                                }
                                              </li>
                                            ) : (
                                              ""
                                            )}

                                            {data?.crm_lead_source
                                              .industry_name ? (
                                              <li>
                                                <FeatherIcon
                                                  icon="truck"
                                                  fill="white"
                                                  size={20}
                                                />

                                                {
                                                  data?.crm_lead_source
                                                    .industry_name
                                                }
                                              </li>
                                            ) : (
                                              ""
                                            )}

                                            {data.phone ? (
                                              <li>
                                                <FeatherIcon
                                                  icon="phone"
                                                  fill="white"
                                                  size={20}
                                                />
                                               
                                                {data.phone}
                                              </li>
                                            ) : (
                                              ""
                                            )}
                                            {data.contact_email ? (
                                              <li>
                                                <FeatherIcon
                                                  icon="mail"
                                                  fill="white"
                                                  size={20}
                                                />
                                                {data.contact_email}
                                              </li>
                                            ) : (
                                              ""
                                            )}

                                            {data.contact_name ? (
                                              <li>
                                                <FeatherIcon
                                                  icon="user"
                                                  fill="white"
                                                  size={20}
                                                />
                                                {data.contact_name}
                                              </li>
                                            ) : (
                                              ""
                                            )}
                                          </>
                                        </ul>
                                      </div>
                                      <div className="box">
                                        <label className="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">
                                          {Trans(
                                            "ADDITIONAL_INFORMATION",
                                            language
                                          )}
                                        </label>
                                        <ul className="list-unstyled profile-info-list">
                                          {data?.crm_lead_contact.map(
                                            (nestedadditional) => {
                                              return (
                                                <>
                                                  {nestedadditional.street_address ? (
                                                    <li>
                                                      <FeatherIcon
                                                        icon="home"
                                                        fill="white"
                                                        size={20}
                                                      />
                                                    
                                                   {
                                                        nestedadditional.street_address
                                                      }{" "}
                                                     
                                                      {nestedadditional.zipcode}{" "}
                                                    {nestedadditional.state}{" "}
                                                      {nestedadditional.country_code}
                                                     
                                                    </li>
                                                  ) : (
                                                    ""
                                                  )}

                                                  {nestedadditional.website ? (
                                                    <li>
                                                      <FeatherIcon
                                                        icon="globe"
                                                        fill="white"
                                                        size={20}
                                                      />

                                                      {nestedadditional.website}
                                                    </li>
                                                  ) : (
                                                    ""
                                                  )}
                                                </>
                                              );
                                            }
                                          )}
                                        </ul>
                                      </div>

                                      <div className="box">
                                        <label className="tx-sans tx-10 tx-semibold tx-uppercase tx-color-01 tx-spacing-1 mg-b-15">
                                          {Trans("SOCIAL_LINKS", language)}
                                        </label>
                                        <ul className="list-unstyled profile-info-list">
                                          {data?.crm_lead_soclink.map(
                                            (nestedadditional) => {
                                              return (
                                                <>
                                                  {nestedadditional.social_type ? (
                                                    <li>
                                                     
                                     

                                                      {nestedadditional.social_type === 1
                                                       ? (
                                                       
                                                        <a
                                                        variant="primary"
                                                        href={`${nestedadditional.social_link}`}
                                                        target="_blank"
                                                        >
                                     {/* 
                                                  <FeatherIcon
                                                        icon="message-circle"
                                                     
                                                      /> */}

                                                       <svg
                                                            xmlns="http://www.w3.org/2000/svg"
                                                            width="24"
                                                            height="24"
                                                            viewBox="0 0 24 24"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            stroke-width="2"
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            className="feather feather-globe"
                                                          >
                                                            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
                                                          </svg>
                                                   
                                                         {nestedadditional.social_link}
                                                          
                                                        </a>
                                                     
                                                      ) 
                                                      
                                                : nestedadditional.social_type === 2
                                                        ? (
                                                       
                                                          <a
                                                          variant="primary"
                                                          href={`${nestedadditional.social_link}`}
                                                          target="_blank"
                                                          >
                                                  <FeatherIcon
                                                        icon="facebook"
                                                       
                                                      />

                                            
                                                         
                                                            {nestedadditional.social_link}
                                                            
                                                          </a>
                                                      ) : nestedadditional.social_type === 3

                                                       ? (
                                                      
                                                          <a
                                                          variant="primary"
                                                          href={`${nestedadditional.social_link}`}
                                                          target="_blank"
                                                          >

                                                <FeatherIcon
                                                        icon="instagram"
                                                       
                                                      />
{/* 
                                              {Trans("Instagram", language)}
                                                       {" "}
                                                          */}
                                                            {nestedadditional.social_link}
                                                            
                                                          </a>
                                                      ) :
                                                       (
                                                        // nestedadditional.social_type === 4
                                                       (

                                                         
                                                          <a
                                                          variant="primary"
                                                          href={`${nestedadditional.social_link}`}
                                                          target="_blank"
                                                          >
                                                 
                                                 <FeatherIcon
                                                        icon="linkedin"
                                                       
                                                      />

                                               

                                                            {nestedadditional.social_link}
                                                            
                                                          </a>
                                                        )
                                                      )}
                                                    </li>
                                                  ) : (
                                                    ""
                                                  )}
                                                </>
                                              );
                                            }
                                          )}
                                        </ul>
                                      </div>
                                    </div>
                                  </>
                                );
                              })}
                          </div>
                        </div>
                      </div>

                      {contentloadingStatus ? (
                        <Loading />
                      ) : (
                        <div className="col-lg-6">
                          <div
                            className=""
                            style={{
                              height: "45vh",
                              overflow: "scroll",
                              overflowX: "hidden",
                            }}
                          >
                            <div class="d-sm-flex align-items-center justify-content-between">
                              <div class="d-sm-flex align-items-center justify-content-between">
                                <div>
                                  <h4 class="mg-b-0 ml-2">{Trans("MY_TIMELINE", language)}</h4>
                                </div>
                              </div>
                            </div>

                            {data?.crm_lead_followup ? (
                              data.folllow_up >= 1 ? (
                                <div class="media d-block d-lg-flex">
                                  <div class="media-body">
                                    <div class="timeline-group tx-13">
                                      {editDataInfo &&
                                        editDataInfo.map((data, index) => {
                                          return data?.crm_lead_followup_history.map(
                                            (e) => {
                                              const {
                                                created_at,
                                                followup_note,
                                                followup_history_id,
                                                followup_id,
                                              } = e;
                                              var str = created_at;
                                              var array = str.split(" ");
                                              console.log(array);

                                              let d = created_at;
                                              return (
                                                <>
                                                  <div class="timeline-label"></div>
                                                  <div class="timeline-item">
                                                    <div class="timeline-time">
                                                      <b>{array[0]} </b>
                            
                                                      {array[1]}
                                                    </div>
                                                    <div class="timeline-body">
                                                      <h6 class="mg-b-0">
                                                        {/* Building a Simple User
                                                      Interface */}
                                                        {data?.crm_lead_status.map(
                                                          (e) => {
                                                            return e.status_id ==
                                                              followup_id
                                                              ? e.status_name
                                                              : "";
                                                          }
                                                        )}
                                                      </h6>

                                                      <p>{followup_note}</p>
                                                    </div>
                                                  </div>
                                                </>
                                              );
                                              // array.length = 0;
                                            }
                                          );
                                        })}
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                ""
                              )
                            ) : (
                              ""
                            )}
                          </div>

                          <div className="card mt-4" id="custom-user-list">
                            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                              <h6 className="tx-uppercase tx-semibold mg-b-0">
                                {Trans("UPDATE_FOLLOWUP", language)}
                              </h6>
                            </div>
                            <div class="card-body">
                              <div className="row">
                                <div className="col-lg-12">
                                  <div className="">
                                    <form
                                      action="#"
                                      onSubmit={handleSubmit(onSubmit)}
                                      noValidate
                                    >
                                      <input
                                        type="hidden"
                                        {...register("lead_id")}
                                        value={data.lead_id}
                                      />
                                      <Row>
                                        <Col col={6}>
                                          <FormGroup mb="20px">
                                            <Label
                                              display="block"
                                              mb="5px"
                                              htmlFor={Trans(
                                                "FOLLOW_UP_STATUS",
                                                language
                                              )}
                                            >
                                              {Trans(
                                                "FOLLOW_UP_STATUS",
                                                language
                                              )}
                                            </Label>
                                            <select
                                              className="form-control"
                                              {...register("followup_status")}
                                              defaultValue={
                                                data?.crm_lead_status.data
                                                  ?.crm_lead_followup
                                                  .followup_status.status_name
                                              }
                                            >
                                              <option
                                                selected={
                                                  data?.crm_lead_followup
                                                    ? "true"
                                                    : "false"
                                                }
                                              >
                                                Choose
                                              </option>
                                              {status &&
                                                status.map((curr) => (
                                                  <>
                                                    <option
                                                      value={curr.status_id}
                                                      // key={curr.status_id}
                                                      selected={
                                                        data?.crm_lead_followup
                                                          ? data
                                                              ?.crm_lead_status[
                                                              data
                                                                ?.crm_lead_followup
                                                                .followup_status -
                                                                1
                                                            ].status_name ==
                                                            curr.status_name
                                                            ? true
                                                            : false
                                                          : false
                                                      }
                                                    >
                                                      {curr.status_name}
                                                    </option>
                                                  </>
                                                ))}
                                            </select>

                                            <span className="required">
                                              <ErrorMessage
                                                errors={errors}
                                                name="followup_status"
                                              />
                                            </span>
                                          </FormGroup>
                                        </Col>
                                        <Col col={6}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id="NEXT_FOLLOW_UP"
                                              label={Trans(
                                                "NEXT_FOLLOW_UP",
                                                language
                                              )}
                                              placeholder={Trans(
                                                "NEXT_FOLLOW_UP",
                                                language
                                              )}
                                              className="form-control"
                                              {...register("next_followup")}
                                              type="date"
                                            />
                                            <span className="required">
                                              <ErrorMessage
                                                errors={errors}
                                                name="next_followup"
                                              />
                                            </span>
                                          </FormGroup>
                                        </Col>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <label for="FOLLOW_UP_NOTE">
                                              <b>
                                                {Trans(
                                                  "FOLLOW_UP_NOTE",
                                                  language
                                                )}
                                              </b>
                                            </label>

                                            <textarea
                                              id="FOLLOW_UP_NOTE"
                                              label={Trans(
                                                "FOLLOW_UP_NOTE",
                                                language
                                              )}
                                              placeholder={Trans(
                                                "FOLLOW_UP_NOTE",
                                                language
                                              )}
                                              className="form-control"
                                              {...register("followup_note", {
                                                required: Trans(
                                                  "FOLLOW_UP_NOTE",
                                                  language
                                                ),
                                              })}
                                              rows="4"
                                              cols="50"
                                            />

                                            <span className="required">
                                              <ErrorMessage
                                                errors={errors}
                                                name="followup_note"
                                              />
                                            </span>
                                          </FormGroup>
                                        </Col>
                                        <Col col={12}>
                                          <LoaderButton
                                            formLoadStatus={formloadingStatus}
                                            btnName={Trans("SUBMIT", language)}
                                            className="btn btn-primary"
                                          />
                                        </Col>
                                      </Row>
                                    </form>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </>
                );
              })}
          </div>
        </div>
      </div>
    </Content>
  );
}
