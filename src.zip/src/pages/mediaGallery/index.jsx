import React, { useCallback, useState } from "react";
import Previews from "./Dropzone";

function Media() {
  return (
    <>
      <Previews />
    </>
  );
}

export default Media;
