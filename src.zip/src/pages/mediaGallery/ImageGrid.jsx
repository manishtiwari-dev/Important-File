import React from "react";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import FeatherIcon from "feather-icons-react";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

function Imageshow({ imgdata }) {
  console.log("transactionLog", JSON.parse(imgdata));
  const [imagedata, setimagedata] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setimagedata(JSON.parse(imgdata));
    return () => abortController.abort();
  }, []);

  // console.log(transaction);
  function myFunction() {
    // Get the text field
    var copyText = document.getElementById("myInput").value;

    // // Copy the text inside the text field
    navigator.clipboard.writeText(copyText);
  }
  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
          <div className="text-center">
            <img
              // style={{ maxWidth: "100%", height: "100%" }}
              src={`${imagedata.media_image}`}
              // alt={imagedata.images_name}
              className="img-fluid"
            />
          </div>

          <table
            className="module_details mb-4 mt-3"
            cellSpacing="0"
            rules="all"
            border="1"
            id=""
            style={{ borderCollapse: "collapse", width: "100%" }}
          >
            <tr>
              <th className="text-center py-2">
                {Trans("IMAGE_NAME", language)}
              </th>
              <td className="text-center py-2">{imagedata.images_name}</td>
            </tr>
            <tr>
              <th className="text-center py-2">
                {Trans("AVAILABLE_SIZE", language)}
              </th>
              <td className="text-center py-2">{imagedata.images_size}</td>
            </tr>

            <tr>
              <th className="text-center py-2">
                {Trans("IMAGE_URL", language)}
              </th>

              <td className="text-center py-2" style={{ position: "relative" }}>
                <a
                  variant="primary"
                  href={`${imagedata?.media_image}`}
                  target="_blank"
                >
                  {imagedata.images_name}.{imagedata.images_ext}
                </a>
                {/* <Anchor path={WebsiteLink(`${imagedata.media_image}`)}>
                  {imagedata.images_name}
                
                </Anchor> */}

                <input
                  type="text"
                  id="myInput"
                  value={imagedata.media_image}
                  hidden
                />

                <FeatherIcon
                  icon="copy"
                  className="wd-107"
                  onClick={myFunction}
                />
              </td>
            </tr>

            <tr>
              <th className="text-center">
                {Trans("IMAGE_UPDATED", language)}{" "}
              </th>
              <td className="text-center">{imagedata.updated_at}</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Imageshow;
