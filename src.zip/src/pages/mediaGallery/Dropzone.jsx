import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import { Modal, Button } from "react-bootstrap";
import Imageshow from "./ImageGrid";
import { MediaUrlStore, MediaUrl, MediaUrlDelate } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import ModalAlert from "component/ModalAlert";
import SearchBox from "component/SearchBox";

import {
  LoaderButton,
  FormGroup,
  Row,
  IconButton,
  Col,
  Input,
  Label,
  Anchor,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";
import Pagination from "component/pagination/index";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";
const Create = () => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const methods = useForm();

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [perPageItem, SetPerPageItem] = useState(36);
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("pages_id");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [imagecontent, Setimagecontent] = useState();
  const [imageset, Setimages] = useState();
  const [showTransactionModal, SetshowTransactionModal] = useState(false);

  const handleShowTransactionModal = () => {
    SetshowTransactionModal(showTransactionModal ? false : true);
  };
  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
      language: language,
    };
    POST(MediaUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;

        if (status) {
          Setimages(data.data);
          console.log(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
        } else alert(message);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    getData(1, perPageItem, searchItem, sortByS, orderByS);
  }, []);
  const [multipleImageIds, SetMultipleImageIds] = useState([]);
  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };
  const RefreshList = () => {
    filterItem("refresh", "", "");
  };
  const onSubmit = (formData) => {
    // console.log("formData", formData);
    SetformloadingStatus(true);
    if (multipleImageIds.length == 0) {
      Notify(false, "CHOOSE ATLEAST ONE IMAGE");
      SetformloadingStatus(false);
      return "";
    }
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.gallery_ids = multipleImageIds;
    console.log("saveFormData", saveFormData);
    // return "";

    POST(MediaUrlStore, saveFormData)
      .then((response) => {
        console.log("response", response);
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          Notify(true, Trans(message, language));
          getData(1, perPageItem, searchItem, sortByS, orderByS);
          window.location.reload(false);
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const imageHandleComp = (type, operation, data) => {
    if (operation === "add") SetMultipleImageIds([...multipleImageIds, data]);
    else {
      const NewList = multipleImageIds.filter((image, key) => {
        return key !== data;
      });
      SetMultipleImageIds(NewList);
    }
    return true;
  };
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  const deletemedia = (deleteID) => {
    const infoData = {
      api_token: apiToken,
      images_id: deleteID,
    };
    POST(MediaUrlDelate, infoData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deletemedia,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  return (
    <Content>
      <PageHeader
        breadcumbs={[
          { title: Trans("DASHBOARD", language), link: "/", class: "" },

          { title: Trans("MEDIA", language), link: "", class: "active" },
        ]}
      />

      <div className="row row-xs-media">
        <div className="col-sm-12 col-lg-12">
          <div className="card">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className="tx-uppercase tx-semibold mg-b-0">
                {Trans("IMAGE_UPLOAD", language)}
              </h6>
            </div>
            <div className="card-body">
              <div className="row">
                {/* <div className="col-md-2">
                    <RecordPerPage
                      filterItem={filterItem}
                      perPageItem={perPageItem}
                    />
                  </div> */}
              </div>
              <>
                {error.status && (
                  <Alert
                    variant={error.type}
                    onClose={() =>
                      setError({ status: false, msg: "", type: "" })
                    }
                    dismissible
                  >
                    {error.msg}
                  </Alert>
                )}
                <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <div
                      className="row"
                      style={{ alignItems: "center", flexDirection: "column" }}
                    >
                      <Col col={6}>
                        <Label
                          display="block"
                          mb="5px"
                          htmlFor="images_id"
                          className="text-center d-block"
                        >
                          {Trans("UPLOAD_IMAGES_HERE", language)}
                        </Label>
                        <FormGroup mb="20px">
                          <GalleryImagePreviewWithUpload
                            label="images_id"
                            className="form-control"
                            imageHandleComp={imageHandleComp}
                            onDrop={imageHandleComp}
                          />
                        </FormGroup>
                      </Col>

                      <Col col={6} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("SUBMIT", language)}
                          className="btn btn-primary btn-block"
                        />
                      </Col>

                      <br />
                    </div>
                  </form>
                </FormProvider>
                <div className="row">
                  <div className="col-md-12">
                    <div className="mediasearch">
                      <SearchBox filterItem={filterItem} />
                    </div>
                  </div>
                </div>
                <div className="row d-flex">
                  {/* {thumbs} */}
                  {imageset &&
                    imageset.map((imagedata) => {
                      const {
                        created_at,
                        images_directory,
                        images_ext,
                        images_name,
                        images_id,
                        images_size,
                        images_status,
                        images_type,
                        updated_at,
                        media_image,
                      } = imagedata;
                      return (
                        <div class="col-6 col-sm-4 col-md-2 my-3 d-flex">
                          <div
                            class="card card-file"
                            onClick={() => {
                              Setimagecontent(JSON.stringify(imagedata));
                              handleShowTransactionModal();
                              // console.log("cont", enquiry);
                            }}
                          >
                            <div class="dropdown-file"></div>
                            <div class="card-file-thumb tx-danger">
                              <div className="media_img">
                                <img
                                  src={imagedata.media_image}
                                  // src={`https://e-nnovation.net/backend/public/storage/${imagedata.images_directory}/${imagedata.images_name}.${imagedata.images_ext}`}
                                  alt={imagedata.images_name}
                                  className="img-fluid"
                                />
                              </div>
                            </div>
                            <div class="card-body p-0">
                              <h6 className="mt-2">
                                <a href="#" class="link-02">
                                  {imagedata.images_name}.{images_ext}
                                </a>
                              </h6>
                              <span>
                                {" "}
                                {imagedata.images_size
                                  ? imagedata.images_size
                                  : " "}
                              </span>{" "}
                              <br></br>
                              <IconButton
                                color="primary"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  deleteItem(images_id);
                                }}
                              >
                                <FeatherIcon
                                  icon="x-square"
                                  color="white"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    deleteItem(images_id);
                                  }}
                                />
                              </IconButton>
                            </div>
                          </div>
                        </div>
                      );
                    })}

                  <Pagination
                    totalPage={Pagi}
                    currPage={currPage}
                    filterItem={filterItem}
                  />
                </div>
              </>
            </div>
          </div>
        </div>
      </div>
      <Modal
        show={showTransactionModal}
        onHide={handleShowTransactionModal}
        size="lg"
      >
        <Modal.Header>
          <Modal.Title>{Trans("IMAGE_DATA", language)}</Modal.Title>
          <Button variant="danger" onClick={handleShowTransactionModal}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Imageshow imgdata={imagecontent} />
        </Modal.Body>
      </Modal>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </Content>
  );
};

export default Create;
