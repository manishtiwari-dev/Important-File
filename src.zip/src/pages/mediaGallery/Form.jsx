import React from "react";
import { FormProvider, useForm } from "react-hook-form";
import Previews from "./Dropzone";

const Form = () => {
  const methods = useForm({
    mode: "onBlur",
  });
  const onSubmit = methods.handleSubmit((values) => {
    console.log("values", values);
  });

  return (
    <FormProvider {...methods}>
      <form onSubmit={onSubmit}>
        <div className="">
          <Previews
            accept="image/png, image/jpg, image/jpeg, image/gif"
            name="file alt text"
            label="File Upload"
          />
        </div>
      </form>
    </FormProvider>
  );
};

export default Form;
