import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  IconButton,
  Label,
} from "component/UIElement/UIElement";
import Moment from "react-moment";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";
import FeatherIcon from "feather-icons-react";
import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

// delete item
// const deleteFeatuerdProduct = (deleteId) => {
//   const editInfo = {
//     api_token: apiToken,
//     setting_id: deleteId,
//   };
//   POST(TemplateComponentSettingDelUrl, editInfo)
//     .then((response) => {
//       const { status, message } = response.data;
//       Notify(true, Trans(message, language));
//       getTemplateComponentList();
//     })
//     .catch((error) => {
//       Notify(true, Trans(error.message, language));
//     });
// };
function Headingcomponent({ dashboardcontent }) {
  // console.log("transactionLog", JSON.parse(dashboardcontent));
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setTransaction([JSON.parse(dashboardcontent)]);
    return () => abortController.abort();
  }, [dashboardcontent]);

  console.log(transaction);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  return transaction.map((e) => {
    return <h3>{e.products_options_name} Options</h3>;
  });
}

export default Headingcomponent;
