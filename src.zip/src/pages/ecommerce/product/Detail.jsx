import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { Anchor } from "component/UIElement/UIElement";

import { Trans } from "lang/index";
import { productShowUrl, staffUpdateUrl ,productChangeStatusUrl} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import FeatherIcon from "feather-icons-react";
import Notify from "component/Notify";
import WebsiteLink from "config/WebsiteLink";
import ProductInfo from "./component/Detail/ProductInfo";
import ProductFeatured from "./component/Detail/ProductFeatured";
import ProductFullInfo from "./component/Detail/ProductFullInfo";
import { ProductEditDataContext } from "./ProductContext";

export default function Detail() {
  const findOptionName = (dataArray, findid) => {
    const attrname = dataArray.filter((data) => {
      return data.products_options_id === findid
        ? data.products_options_name
        : "";
    });
    return attrname.length > 0 ? attrname[0]["products_options_name"] : "";
  };

  const { proId } = useParams();


  let bod = new Array();
  let stringArray;
  let uniqueArray;
  const findOptionValueName = (dataArray, findid) => {
    let temp = new Array();
    var obj = {};
    dataArray.map((e) => {
      if (e.products_options_id == findid) {
        obj[e.products_options_values_id] = e.products_options_values_name;
      }
    });
    bod.push(obj);
  };

  console.log(bod);

  const { product_id } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [DataList, SetDataList] = useState();
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);
  const [mainimg, setmainimg] = useState();
  // const [stat, setstatus] = useState();
  // const [attributes, setattributes] = useState([]);

  // function checkactive(e) {
  //   if (e == "active") {
  //     setstatus("green");
  //   } else if (e == "deactive") {
  //     setstatus("danger");
  //   } else {
  //     setstatus("warning");
  //   }
  // }
  const [EditData, setData] = useState();

  let stat;
  useEffect(() => {
  //  document.title= (`${DataList?.productdescription[0]?.products_name}`)
   // document.title ="product_id | WorkerMan";

    let abortController = new AbortController();
    const getData = () => {
      const editData = {
        api_token: apiToken,
        product_id: proId,
      };
      POST(productShowUrl, editData)
        .then((response) => {
          const { status, data, message } = response.data;
          console.log(data);
          if (status) {
            SetloadingStatus(false);
            SetDataList(data);
          } else alert(message);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    };
    getData();

    return () => {
      // checkactive(DataList?.product_status);
      getData();
      abortController.abort();
    };
  }, [product_id]);

  {
    DataList?.product_status == "active"
      ? (stat = "green")
      : DataList?.product_status == "deactive"
      ? (stat = "danger")
      : (stat = "warning");
  }
  let optionAry = new Array();
  let valueAry = new Array();



  {
    DataList?.productAttribute &&
      DataList?.productAttribute.map((attr, idx) => {
        {
          const index = optionAry.findIndex(
            (element) =>
              element === findOptionName(attr.option_list, attr.options_id)
          );
          if (index !== -1) {
            //array1.push(findOptionName(attr.option_list, attr.options_id));
          } else {
            let valueName = [];
            optionAry.push(findOptionName(attr.option_list, attr.options_id));
            attr?.option_value_list.map((attrval, idx) => {
              valueName.push(attrval.products_options_values_name);
            });
            valueAry.push(valueName);
          }
        }
      });
  }

  console.log(optionAry);
  console.log(valueAry);

  const ChangeFunction = (update_id, statusId) => {
    const editData = {
      api_token: apiToken,
      update_id: update_id,
      statusId: statusId,
    };
    POST(productChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        // filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const [showType, SetShowType] = useState("");
  const stSarr = ["Draft", "Active", "Inactive"];
  const stSarrC = ["warning", "success", "danger"];
  const StatusChange = (quoteId, statusId) => {
    ChangeFunction(quoteId, statusId);
  };

  
  useEffect(() => {
     // document.title =" Product List | WorkerMan";
    
    document.title= (`${DataList?.productdescription[0]?.products_name}`)

    let abortController = new AbortController();
 
    return () => abortController.abort();
  }, []);

  return (
    <Content>
   <PageHeader
        breadcumbs={[
          {
            title: Trans("DASHBOARD", language),
            link: WebsiteLink("/"),
            class: "",
          },
          {
            title: Trans("PRODUCT", language),
            link: WebsiteLink("/products"),
            class: "",
          },
          { title: Trans("DETAIL", language), link: "", class: "active" },
        ]}
        // heading={Trans("VIEW_STAFF", language)}
      />
    <div className="container-fluid mt-5 mb-5">
          <div className="row g-0">
            {DataList?.product_image && (
              <div className="col-md-4 border-end">
                <div className="d-flex flex-column justify-content-center">
                  <div className="product_carousel">
                   
                    <img
                      src={mainimg ? mainimg : DataList?.product_image}
                      id="main_product_image"
                      width="350"
                    />{" "}
                  </div>
                  <div className="thumbnail_images">
                    <ul id="thumbnail">
                      {DataList?.gallery_image.map((material, index = 1) => {
                        return (
                          // console.log(material);
                          <>
                            <li>
                              <img
                                onClick={() => setmainimg(material)}
                                src={material}
                                width="70"
                              />
                            </li>
                          </>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                {DataList?.productdescription_with_lang && (
                  <>
                    {DataList?.productdescription_with_lang.map((oldlist) => {
                      return (
                        <div className="card mg-b-20 mg-lg-b-25">
                          <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                            <h6 className="tx-uppercase tx-semibold mg-b-0">{` PRODUCT DESCRIPTION (${oldlist.languages_name}) `}</h6>
                          </div>
                         
                          <div className="card-body pd-25">
                         
                            <div className="media d-block d-sm-flex">
                              <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      DataList?.productdescription[
                                        oldlist.languages_id - 1
                                      ]?.products_description,
                                  }}
                                ></div>
                              </div>
                            </div>
                          
                          </div>
                         
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            )}
            <div className="col-md-8">
              <div className="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">
                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      PRODUCT INFORMATION
                    </h6>
                    <div className="product_btn">
                    <Anchor
              path={WebsiteLink("/products/create")}
              className="btn btn-primary btn-sm"
            >
              {Trans("ADD_MORE_PRODUCT", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink(
                `/products/edit/${DataList?.product_id}`
              )}
              className="btn btn-info btn-sm"
            >
              {Trans("EDIT_PRODUCT", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink("/products")}
              className="btn btn-warning btn-sm"
            >
              {Trans("GO_BACK", language)}
            </Anchor>
                    </div>
                  
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="d-flex justify-content-between">
                          <div>
                            <h5 className="mb-0">
                              {DataList?.productdescription[0]?.products_name}
                            </h5>
                          </div>
                          <div>
                     
                              <>
                         <select
                            value={DataList?.product_status}
                            onChange={(e) => {
                              StatusChange(DataList?.product_id, e.target.value);
                            }}
                            className={`badge badge-${stSarrC[DataList?.product_status]}`}
                          >
                            <option value={0}>
                              {Trans("Draft", language)}
                            </option>
                            <option value={1}>
                              {Trans("Active", language)}
                            </option>
                            <option value={2}>
                              {Trans("Inactive", language)}
                            </option>
                          </select>
                               
                              </>
                          
                          </div>
                        </div>
                        <div className="table  table-dashboard">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("PRODUCT_NAME", language)}</td>
                                    <td>
                                      {
                                        DataList?.productdescription[0]
                                          ?.products_name
                                      }
                                    </td>
                                  </>
                                )}
                              </tr>
                              {DataList?.selected_category && (
                                <>
                                  {DataList.selected_category.map((list) => {
                                    return (
                                      <tr>
                                        <td>
                                          {" "}
                                          {Trans("Category :", language)}
                                        </td>
                                        <td>{list.label}</td>
                                      </tr>
                                    );
                                  })}
                                </>
                              )}
                              {DataList?.product_model && (
                                <tr>
                                  <td> {Trans("Model No :", language)}</td>
                                  <td> {DataList?.product_model}</td>
                                </tr>
                              )}
                              {DataList?.product_sku && (
                                <tr>
                                  <td> {Trans("PRODUCT_SKU", language)}</td>
                                  <td> {DataList?.product_sku}</td>
                                </tr>
                              )}
                              {DataList?.product_condition && (
                                <tr>
                                  <td>
                                  
                                  {Trans("PRODUCT_CONDITION", language)}
                                  </td>
                                  <td>
                                 
                                    {DataList?.product_condition == "1"
                                      ? "New"
                                      : "Refurbished"}
                                  </td>
                                </tr>
                              )}

              
                                <tr>
                                  <td> {Trans("Profit Margin :", language)}</td>
                                  <td>{DataList?.product_profit_margin}</td>
                                </tr>
                           

                              {DataList?.product_discount_type && (
                                <tr>
                                  <td> {Trans("DISCOUNT_TYPE :", language)}</td>
                                  <td>{DataList?.product_discount_type}</td>
                                </tr>
                              )}
                              {DataList?.product_discount_amount && (
                                <tr>
                                  <td>
                                    {Trans("PRODUCT_DISCOUNT_AMOUNT", language)}
                                  </td>
                                  <td>{DataList?.product_discount_amount}</td>
                                </tr>
                              )}
                              {DataList?.products_type_field_value.map((e) => {
                                return (
                                  <tr>
                                    <td> {e.field_label}</td>
                                    <td>{e.field_value}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    {DataList?.product_stock_manage && (
                      <h6 className="tx-uppercase tx-semibold mg-b-0">
                        {Trans("PRICE_AND_STOCK", language)}
                        
                      </h6>
                    )}
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellspacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                          
                                <tr>
                                  <td> {Trans("Price:", language)}</td>
                                  <td> {DataList?.product_sale_price}</td>
                                </tr>
                           
                               <tr>
                                <td>{Trans("Product_Stock:", language)}</td>
                                <td> {DataList?.product_stock_qty}</td>
                              </tr>
                            
                              {DataList?.product_stock_price && (
                                <tr>
                                  <td> {Trans("Stock Price :", language)}</td>
                                  <td>{DataList?.product_stock_price}</td>
                                </tr>
                              )}
                              {DataList?.product_sale_price && (
                                <tr>
                                  <td> {Trans(" Sale Price :", language)}</td>
                                  <td>{DataList?.product_sale_price}</td>
                                </tr>
                              )}
                              {DataList?.product_discount_amount && (
                                <tr>
                                  <td>
                                    {" "}
                                    {Trans("Discount Amount :", language)}
                                  </td>
                                  <td>{DataList?.product_discount_amount}</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      {Trans(" PRODUCT ATTRIBUTE INFO", language)}
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              {optionAry && (
                                <>
                                  {optionAry.map((e, ind) => {
                                    const linkContent = valueAry[ind];
                                    return (
                                      <>
                                        <tr>
                                          <td>{e}</td>
                                          <td>
                                            <ul className="pd-l-10 mg-0 mt-2 tx-13">
                                              {linkContent.map((e) => {
                                                return <li>{e}</li>;
                                              })}
                                            </ul>
                                          </td>
                                        </tr>
                                      </>
                                    );
                                  })}
                                  {/* {valueAry.map((student) => {
                                      return <td> {student}</td>;
                                    })} */}
                                </>
                                // </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className="tx-uppercase tx-semibold mg-b-0">
                      PRODUCT FEATURE
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                <>
                                  {DataList?.product_feature.map((lit) => {
                                    return (
                                      <td>{`${lit.feature_title}  :  ${lit.feature_value}`}</td>
                                    );
                                  })}
                                </>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
      </Content>
   
  );
}
