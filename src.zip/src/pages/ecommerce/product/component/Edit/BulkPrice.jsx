import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";

function BulkPrice({ editPrice }) {
  const { language } = useSelector((state) => state.login);

  const methods = useFormContext();

  const {
    register,
    control,
    formState: { errors },
  } = methods;

  const bulkPrice = useFieldArray({
    control,
    name: "bulkPrice",
  });

  useEffect(() => {
    console.log("call price");
    if (editPrice !== undefined) {
      let feature = [];
      for (let index = 0; index < editPrice.length; index++) {
        const elem = editPrice[index];
        feature.push({
          product_qty: elem.product_qty,
          product_price: elem.product_price,
        });
      }
      bulkPrice.replace(feature);
    }
  }, []);

  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("WHOLESALE_PRICE", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-xs btn-dark"
              onClick={() => {
                bulkPrice.prepend({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE", language)}
            </button>
          </span>
        </Card.Header>
        {bulkPrice.fields && (
          <Card.Body>
            {bulkPrice.fields.map((item, index) => {
              return (
                <Row key={index}>
                  <Col col={4}>
                    <FormGroup>
                      <input
                        {...register(`bulkPrice.${index}.product_qty`,
                        
                        )}
                        className="form-control"
                        id={`bulkPrice.${index}.product_qty`}
                        placeholder={Trans("PRODUCT_QTY", language)}
                      />
                    
                    </FormGroup>
                  </Col>
                  <Col col={7}>
                    <FormGroup>
                      <input
                        {...register(`bulkPrice.${index}.product_price`, 
                        
                        )}
                        className="form-control"
                        id={`bulkPrice.${index}.product_price`}
                        placeholder={Trans("PRODUCT_PRICE", language)}
                      />
                   
                    </FormGroup>
                  </Col>
                  <Col col={1}>
                    <span style={{ lineHeight: "42px" }}>
                      <FeatherIcon
                        icon="x-square"
                        color="red"
                        onClick={() => bulkPrice.remove(index)}
                        size={20}
                      />
                    </span>
                  </Col>
                </Row>
              );
            })}
          </Card.Body>
        )}
      </Card>
    </Col>
  );
}

export default BulkPrice;
