import React from "react";
import { Col } from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";

function Table({ dataList, updateStatusFunction, perPage,
  curPage }) {
  const { language } = useSelector((state) => state.login);
  const statusColor = ["danger", "success", "warning", "danger"];

  const StatusChange = (quoteId, statusId) => {
    updateStatusFunction(quoteId, statusId);
  };
  let rowId = (curPage>1)? (curPage-1)* perPage : 0;

  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
             
                <th>{Trans("CUSTOMER_DETAILS", language)}</th>
              
                <th>{Trans("STATUS", language)}</th>
                <th>{Trans("ACTION", language)}</th>
              </tr>
            </thead>
            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, idx) => {
                  const {
                    newsletter_id,
                    customer_name,
                    customer_email,
                    company_name,
                    status,
                  } = cat;
                  rowId++;
                  return (
                    <React.Fragment key={newsletter_id}>
                      <tr>
                        <td>{rowId}</td>
                       
                   
                        <td>
                        <p>{customer_name}</p>{" "}
                          <p>{customer_email}</p>{" "}
                         
                      
                             
                             
                        </td>
                        <td>
                          {/* <span
                            className={`badge badge-${statusColor[status]}`}
                          >
                            {status === 1
                              ? "Subscribed"
                              : status === 2
                              ? "UnSubscribed"
                              : "Blocked"}
                          </span> */}

<select
                             className={`badge badge-${statusColor[status]}`}
                            defaultValue={status}
                            onChange={(e) => {
                              StatusChange(newsletter_id, e.target.value);
                            }}
                          >
                            <option value={1}>
                              {Trans("Subscribed", language)}
                            </option>
                            <option value={2}>
                              {Trans("UnSubscribed", language)}
                            </option>
                            <option value={3}>
                              {Trans("Blocked", language)}
                            </option>
                          </select>
                        </td>

                        <td>
                          {/* <select
                             className={`badge badge-${statusColor[status]}`}
                            defaultValue={status}
                            onChange={(e) => {
                              StatusChange(newsletter_id, e.target.value);
                            }}
                          >
                            <option value={1}>
                              {Trans("Subscribed", language)}
                            </option>
                            <option value={2}>
                              {Trans("UnSubscribed", language)}
                            </option>
                            <option value={3}>
                              {Trans("Blocked", language)}
                            </option>
                          </select> */}
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Col>
    </>
  );
}

export default Table;
