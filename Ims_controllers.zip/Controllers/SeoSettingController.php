<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Project;
use App\DataTables\SeoTaskDataTable;
use App\Models\Currency;
use App\Helper\Reply;
use App\Models\SeoTask;
use App\Models\SeoTitle;
use App\Models\Website;
use Froiden\Envato\Traits\AppBoot;

class SeoSettingController extends AccountBaseController
{
    private $addSeoPermission;
    private $viewSeoPermission;
    private $editSeoPermission;
    private $deleteSeoPermission;
    
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle ='app.menu.settings';
        $this->activeSettingMenu = 'seo_setting';
        // $this->addSeoPermission = user()->permission('add_seo');
        // $this->viewSeoPermission = user()->permission('view_seo');
        // $this->editSeoPermission = user()->permission('edit_seo');
        // $this->deleteSeoPermission = user()->permission('delete_seo');
        
    }
    public function isActive($option)
    {
        return $option === $this->active;
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
    public function index()
    {
        abort_403(user()->permission('view_seo') == 'none');
        $this->seotask = SeoTask::OrderBy('task_priority','asc')->get();
        $this->web_setting = Website::get();
        $seotitle = SeoTitle::OrderBy('sort_order','asc')->where('parent_id', 0)->get();

        if(!empty($seotitle)){
            $seotitle = $seotitle->map(function($result){
                $result->child = SeoTitle::OrderBy('sort_order','asc')->where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $this->seotitle = $seotitle;
        

         $tab = request('tab');

        switch ($tab) {
        case 'task':
            $this->view = 'seo-setting.seotask';
                break;
        case 'title':
            $this->view = 'seo-setting.seotitle';
                break;
                default:
            $this->view = 'seo-setting.seowebsite';
                break;
        }

        ($tab == '') ? $this->activeTab = 'website' : $this->activeTab = $tab;

        if (request()->ajax()) {
            $html = view($this->view, $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle, 'activeTab' => $this->activeTab]);
        }

        return view('seo-setting.index', $this->data);

    }

   

}
