<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Helper\Reply;
use App\Http\Requests\Settings\UpdateOrganisationSettings;
use App\Models\CompanySetting;
use App\Models\Setting;
use App\Traits\CurrencyExchange;
use Carbon\Carbon;
use App\Models\Country;
use App\Models\User;
use App\Models\CompanyDocument;
use Illuminate\Support\Facades\File;

use App\Helper\Files;
use App\Http\Requests\EmployeeDocs\CreateRequest;
use App\Http\Requests\EmployeeDocs\UpdateRequest;
use Illuminate\Http\Request;

class SettingsController extends AccountBaseController
{
    use CurrencyExchange;

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.accountSettings';
        $this->activeSettingMenu = 'company_settings';
        $this->middleware(function ($request, $next) {
            abort_403(!(user()->permission('manage_company_setting') == 'all'));
            return $next($request);
        });
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   

        $this->timezones = \DateTimeZone::listIdentifiers(\DateTimeZone::ALL);
        //$this->currencies = Currency::all();
        $this->countries = Country::get();
        $this->dateObject = Carbon::now();
        $this->company=CompanySetting::all();
        $this->setting=Setting::all();

        // $company_array = array();

        // foreach ($this->company as $companylist){
        //     $company_array[$companylist->key_index] = $companylist->key_value;
        // }
        // $this->company_array =$company_array;


        $this->view = 'company-settings.ajax.companyinfo';

        $tab = request('tab');

        switch ($tab) {
        case 'companyinfo':
            $this->view = 'company-settings.ajax.companyinfo';
                break;
        case 'dininfo':
            $this->view = 'company-settings.ajax.dininfo';
                break;
        case 'contactinfo':
            $this->view = 'company-settings.ajax.contactinfo';
            break;
        case 'social':
            $this->view = 'company-settings.ajax.social';
                break;
        case 'document':
            $this->view = 'company-settings.ajax.document';
                break;
        default:
            $this->view = 'company-settings.ajax.companyinfo';
                break;
        }

        ($tab == '') ? $this->activeTab = 'companyinfo' : $this->activeTab = $tab;

        if (request()->ajax()) {
            $html = view($this->view, $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->cachedFile = File::exists(base_path('bootstrap/cache/config.php'));
        return view('company-settings.index', $this->data);
    }



    public function update(UpdateOrganisationSettings $request, $id)
    {
        config(['filesystems.default' => 'local']);
        $setting = Setting::first();
        if ($request->company_method == 'compnyinfo' ) {
        $setting->company_name = $request->company_full_name;
        $setting->company_brand=$request->company_brand_name;
        $setting->company_email = $request->company_email;
        $setting->company_website=$request->company_website;
        $setting->incorporation_date=$request->company_incorporation ? Carbon::createFromFormat($this->global->date_format, $request->company_incorporation)->format('Y-m-d') : null;
        $setting->company_cin=$request->company_cin;
        $setting->company_regno=$request->company_regno;
        $setting->company_pan=$request->company_pan;
        $setting->company_tan=$request->company_tan;
        $setting->company_gst=$request->company_gst;
        $setting->company_iec=$request->company_iec;
        }
        if ($request->contact_method == 'contactinfo' ) {
        $setting->company_phone=$request->contact_phone_1;
        $setting->company_landline=$request->contact_phone_2;
        $setting->address=$request->contact_street_address;
        $setting->city=$request->contact_city;
        $setting->state=$request->contact_state;
        $setting->zipcode=$request->contact_zipcode;
        $setting->country_id=$request->contact_countryId;
        }
        $setting->save();
        

        session()->forget('global_setting');

        return Reply::redirect(route('company-settings.index'), __('messages.updateSuccess'));
    }




     // phpcs:ignore
    //  public function company_setting_update(UpdateCompanySettings $request)
    //  {
    //     $data=$request->all();
    //     foreach($data as $key=>$value){

    //         if(strrchr($key,"company")){
    //             $keygroup1=1;
    //         }
    //         else if(strrchr($key,"din")){
    //             $keygroup1=2;
    //         }
    //         else{
    //             $keygroup1=4;
    //         }

    //         $result = substr($key, 0, 7);
    //         if($result=='contact'){
    //             $keygroup1=3;
    //         }

    //         if(strrchr($key,"company")){
   
    //             CompanySetting::updateOrCreate(['key_index'=>$key],
    //             [
    //                 'key_group'=>$keygroup1,
    //                 'key_index'=>$key,
    //                 'key_value'=>$value,
    //             ]);


    //         } 
    //         else if(strrchr($key,"din")){

    //                 CompanySetting::updateOrCreate(['key_index'=>$key],
    //             [
    //                 'key_group'=>$keygroup1,
    //                 'key_index'=>$key,
    //                 'key_value'=>$value,
    //             ]);

    //         }
    //         else if(strrchr($key,"contact")){

    //             CompanySetting::updateOrCreate(['key_index'=>$key],
    //         [
    //             'key_group'=>$keygroup1,
    //             'key_index'=>$key,
    //             'key_value'=>$value,
    //         ]);

    //         }
    //         else{
    //             CompanySetting::updateOrCreate(['key_index'=>$key],
    //             [
    //                 'key_group'=>$keygroup1,
    //                 'key_index'=>$key,
    //                 'key_value'=>$value,
    //             ]);

    //         }

           
    //     }

        
        
    //     session()->forget('global_setting');

    //     return Reply::success(__('messages.settingsUpdated'));
    //  }



     
     
     

}