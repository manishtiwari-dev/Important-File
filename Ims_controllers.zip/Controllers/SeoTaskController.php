<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\DataTables\SeoTaskDataTable;
use Illuminate\Http\Request;
use App\Http\Requests\TaskSetting\StoreTask;
use App\Http\Requests\TaskSetting\UpdateTask;
use Carbon\Carbon;
use App\Models\SeoTask;
use App\Models\SeoTitle;
use App\Models\Currency;


class SeoTaskController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.seotask';
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
   
    public function create(){

        return view('seo-setting.create-task-modal');

    }
    public function store(StoreTask $request){
       
        $task = new SeoTask();
        $task->task_priority = $request->task_priority;
        $task->seo_task_title = $request->seo_task_title;
        $task->no_of_submission = $request->no_of_submission;
        $task->task_frequency = $request->task_frequency;
        $task->status = $request->status;
        $task->save();
        $seo_task = SeoTask::get();
        return Reply::successWithData(__('messages.storetask'), ['data' => $seo_task]);

 
    }

    public function edit($id){
    
        $this->task = SeoTask::findOrFail($id);
        $this->taskData = SeoTask::all();

        return view('seo-setting.edit-task-modal', $this->data);
    }

    public function update(UpdateTask $request, $id){

        $task = SeoTask::findOrFail($id);
        $task->task_priority = $request->task_priority;      
        $task->seo_task_title = $request->seo_task_title;
        $task->no_of_submission = $request->no_of_submission;
        $task->task_frequency = $request->task_frequency;
        $task->status = $request->status;
        $task->save();
       
        return Reply::success(__('messages.updatetask'));
        
    }
    public function destroy($id){
        $task = SeoTask::findOrFail($id);
        SeoTask::destroy($id);
        return Reply::success(__('messages.deletetask'));
    }
    
}
