<?php

namespace App\Http\Controllers;
use App\Helper\Reply;
use App\Http\Requests\ExpenseBiller\StoreExpenseBiller;
use App\Http\Requests\ExpenseBiller\UpdateExpenseBiller;
use App\Models\BaseModel;
use App\Models\ExpenseBiller;


class ExpenseBillerController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.expenses';
        $this->middleware(function ($request, $next) {
            abort_403(!in_array('expenses', $this->user->modules));
            return $next($request);
        });
    }

    public function create()
    {
        $this->biller =ExpenseBiller::all();
        $this->taxable_bill=['0'=>"No",'1'=>'Yes'];
        return view('expenses.biller.create', $this->data);
    }
    
    public function store(StoreExpenseBiller $request)
    {
        $biller = new ExpenseBiller();
        $biller->biller_name = $request->biller_name;
        $biller->biller_address = $request->biller_address;
        $biller->taxable_bill = $request->taxable_bill;
        $biller->save();

        $billersname=ExpenseBiller::all();
       // dd($billersname);
        $options = BaseModel::options($billersname,null,'biller_name');

        return Reply::successWithData(__('messages.BillerAdded'), ['data' => $options]);
    }

    public function update(UpdateExpenseBiller $request, $id)
    {
        $biller = ExpenseBiller::find($id);
        $biller->biller_name= strip_tags($request->biller_name);
        $biller->save();

        $billersname = ExpenseBiller::all();
        $options = BaseModel::options($billersname, null, 'biller_name');

        return Reply::successWithData(__('messages.updatedSuccessfully'), ['data' => $options]);
    }
  
    public function destroy($id)
    {
        ExpenseBiller::destroy($id);

        $biller = ExpenseBiller::all();
        $options = BaseModel::options($biller, null, 'biller_name');

        return Reply::successWithData(__('messages.deleteSuccess'), ['data' => $options]);
    }
/*
    public static function getCategoryByCurrentRole()
    {
        $categories = ExpensesCategory::with(['roles', 'roles.role']);

        if(!in_array('admin', user_roles()) && !in_array('client', user_roles())){

            $userRoleID = \DB::select('select user_roles.role_id from role_user as user_roles where user_roles.user_id = '.user()->id.' ORDER BY user_roles.role_id DESC limit 1');

            $categories = $categories->join('expenses_category_roles', 'expenses_category_roles.expenses_category_id', 'expenses_category.id')
                ->join('roles', 'expenses_category_roles.role_id', 'roles.id')
                ->select('expenses_category.*')
                ->where('expenses_category_roles.role_id', $userRoleID[0]->role_id);
        }

        $categories = $categories->get();

        return $categories;
    }

    */
}
