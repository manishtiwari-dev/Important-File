<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\DataTables\WorkReportDataTable;
use App\Helper\Reply;
use Carbon\Carbon;
use App\Models\Website;
use App\Models\SeoResult;
use App\Models\SeoWebsiteResult;
use App\Http\Requests\Admin\WorkReport\StoreRequest;
use DB;

use App\Http\Requests\Admin\WorkReport\UpdateRequest;

class SeoMonthlyResultController extends AccountBaseController 
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.menu.seo_result');
        
    }

    public function index()
    {
        $this->web_setting = Website::get();
        $web_data = SeoResult::OrderBy('sort_order','asc')->where('parent_id', 0)->get();

        if(!empty($web_data)){
            $web_data = $web_data->map(function($result){
                $result->child = SeoResult::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $this->web_data = $web_data;

        $this->web_result = SeoWebsiteResult::all();
        

        return view('seo-monthly-result.index',$this->data);
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        

    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(Request $request)
    {
       
        $web_id=$request->seo_websites;
        $title=$request->title_id;
        foreach($web_id as $key=>$value){
            $title_id=$title[$key];
            //dd($title_id);
            SeoWebsiteResult::updateOrCreate([
                'id'=>$title_id,
            ],[
                'result_value'=>$value,
                'result_title_id'=>$title_id,
                'website_id'=>$request->website_name,
                'month' =>  $request->month,
                'year'  =>  $request->year,
            ]);
        }

        return Reply::successWithData(__('messages.updateSuccess'), ['redirectUrl' => route('seo-result.index')]);


        
    
    }
   

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
        
    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

       
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        


    }

      /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
      

    }


    public function getWebsiteResult(Request $request)
    {

            
    }

  

}
