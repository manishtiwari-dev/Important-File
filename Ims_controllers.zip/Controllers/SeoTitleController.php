<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use Illuminate\Http\Request;
use App\Http\Requests\ResultSetting\StoreResult;
use App\Http\Requests\ResultSetting\UpdateResult;
use App\Models\SeoTitle;



class SeoTitleController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.seotitle';
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
   
    public function create(){
    
        $this->seotitle = SeoTitle::where('parent_id',0)->get();
        return view('seo-setting.create-title-modal',$this->data);

    }

    public function store(StoreResult $request){
  
        $title = new SeoTitle();
        $title->title_name = $request->title_name;
        $title->parent_id = $request->parent_id;
        $title->sort_order = $request->sort_order;
        $title->status = $request->status;
        $title->save();

        $seo_result = SeoTitle::get();
        return Reply::successWithData(__('messages.storeresult'), ['data' => $seo_result]);

        
    }

    public function edit($id){

	$this->title = SeoTitle::findOrFail($id);        
 	$this->seotitle = SeoTitle::where('parent_id',0)->get();     
        return view('seo-setting.edit-title-modal', $this->data); 
       
    }

    public function update(UpdateResult $request, $id){

        $title = SeoTitle::findOrFail($id);
        $title->title_name = $request->title_name;
        $title->parent_id = $request->parent_id;
        $title->sort_order = $request->sort_order;
        $title->status = $request->status;
        $title->save();

        return Reply::success(__('messages.updateresult'));
    }

    public function show($id){
	$this->pageTitle = __('modules.result-setting.resultdetail');

    }
    public function destroy($id){
        $title = SeoTitle::findOrFail($id);
        SeoTitle::destroy($id);
        return Reply::success(__('messages.deleteresult'));
    }
    
}
