<?php

namespace App\Http\Controllers;

class ForgotPasswordController extends Controller
{
    //
}
