<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\Models\BaseModel;
use App\Models\SalaryGroup;
use App\Models\SalaryStructure;
use App\Models\SalaryComponent;
use App\Http\Requests\SalaryGroup\StoreSalaryType;
use Illuminate\Http\Request;

class SalarySettingController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.SalarySettings';
        $this->activeSettingMenu = 'salary_settings';

        // $this->middleware(function ($request, $next) {
        //     abort_403(!(user()->permission('manage_salary_setting') == 'all'));
        //     return $next($request);
        // });
    }



        public function index()
        {
            $this->salaryGroup = SalaryGroup::all();
          

            return view('salary-settings.index', $this->data);
        }



        public function create()
        {

            $this->salaryGroup = SalaryGroup::all();
            $this->salaryComponent = SalaryComponent::all();

          
            return view('salary-settings.create-salary-setting-type-modal',$this->data);
        }


        public function store(StoreSalaryType $request)
        {
           $salaryGroup = new SalaryGroup();
           $salaryGroup->description = $request->description;
           $salaryGroup->group_name = $request->group_name;
           $salaryGroup->save();


        $SalaryStructure=SalaryComponent::all();

      

        foreach($SalaryStructure as $Key=>$Val)
        {
           
            $id = $Val->id;
           

        if(isset($request->{"formula-".$id}))

        {
           $formula=$request->{"formula-".$id};
             
            
           SalaryStructure::create(
                ['component_id' => $id, 
                 'group_id' => $salaryGroup->id,
                
                'formula' => $formula],
               
            );
        }
    }
   

   
            

           $options='';
    
            return Reply::successWithData(__('messages.salaryGroupAdded'), ['data' => $options, 'page_reload' => $request->page_reload]);
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
        public function edit($id)
        {  
            
      
            
           $this->salaryComponent = SalaryComponent::all();


            $this->salaryGroup = SalaryGroup::with('salary_structure')->findOrFail($id);

            $this->salaryStru = SalaryStructure::where('group_id', $this->salaryGroup->id)->first();
         //   dd( $this->salaryStru);
       
            return view('salary-settings.edit-salary-setting-type-modal', $this->data);
        }
    
        public function update(Request $request, $id)
        {
    
           $salaryGroup = SalaryGroup::findOrFail($id);
             
           $salaryGroup->description = $request->description;
           $salaryGroup->group_name = $request->group_name;
           $salaryGroup->save();

            
           $SalaryStructure=SalaryComponent::all();

      

                    foreach($SalaryStructure as $Key=>$Val)
                    {
                    
                        $id = $Val->id;
                    

                    if(isset($request->{"formula-".$id}))

                    {
                    $formula=$request->{"formula-".$id};
                        
                        
                    SalaryStructure::updateOrCreate(
                            ['component_id' => $id, 
                            'group_id' => $salaryGroup->id],
                            
                            ['formula' => $formula],
                        
                        );
                    }
       }
   



    
            return Reply::success(__('messages.salaryGroupUpdated'));
        }
    
        /**
         * Remove the specified resource from storage.
         *
         * @param  int  $id
         * @return \Illuminate\Http\Response
         */
      

    public function destroy($id)
    {
       

        $DETAIL = SalaryGroup::with('salary_structure')->where('id', $id)->first();
        if (!empty($DETAIL))

        $DETAIL->salary_structure()->delete();   // relation data delete

        $DETAIL = SalaryGroup::where('id', $id)->delete();



      //   SalaryGroup::destroy($id);
        return Reply::success(__('messages.salaryGroupDeleted'));


    }


}
