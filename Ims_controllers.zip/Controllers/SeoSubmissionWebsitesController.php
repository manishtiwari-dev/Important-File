<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Helper\Reply;
use App\DataTables\SeoSubmissionWebsitesDatatable;
use App\Http\Requests\Admin\SubmissionWebsite\StoreRequest;
use App\Models\SeoTask;
use App\Models\SeoSubmissionWebsites;
use App\Models\Website;

use App\Http\Requests\Admin\SubmissionWebsite\UpdateRequest;

class SeoSubmissionWebsitesController extends AccountBaseController 
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.menu.seo-submission');
        
    }

    public function index(SeoSubmissionWebsitesDatatable $dataTable)
    {
        $this->seotasklist=SeoTask::get();
        $this->seosubmissionwebsites=SeoSubmissionWebsites::get();
        $this->websitelist=Website::get();
        return $dataTable->render('seo-submission-websites.index',$this->data);
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->seotask=SeoTask::get();
        $this->pageTitle =  __('app.menu.submission_url');

        if (request()->ajax()) {
            $html = view('seo-submission-websites.ajax.create', $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'seo-submission-websites.ajax.create';
        return view('seo-submission-websites.ajax.create', $this->data);

    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(StoreRequest $request)
    {
       
        $Seowebsites = new SeoSubmissionWebsites();
        $Seowebsites->seo_task_id = $request->seotask;
        $Seowebsites->website_url = $request->website_url;
        $Seowebsites->website_username = $request->username;
        $Seowebsites->website_password = $request->password;
       $Seowebsites->save();

    return Reply::successWithData(__('messages.websiteAdded'), ['redirectUrl' => route('submission-url.index')]);
    
    }
   

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
        $this->seosubmissionwebsites = SeoSubmissionWebsites::withoutGlobalScope('active')->findOrFail($id);
        $this->seotask=SeoTask::get();
        $this->pageTitle =  __('app.menu.submission_url_edit');
        if (request()->ajax()) {
            $html = view('seo-submission-websites.ajax.edit', $this->data)->render();

            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'seo-submission-websites.ajax.edit';


        return view('seo-submission-websites.create', $this->data);
    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

        $Seowebsites = SeoSubmissionWebsites::withoutGlobalScope('active')->findOrFail($id);
        $Seowebsites->seo_task_id = $request->seotask;
        $Seowebsites->website_url = $request->website_url;
        $Seowebsites->website_username = $request->username;
        $Seowebsites->website_password = $request->password;
        $Seowebsites->status=$request->status;
        $Seowebsites->update();

        return Reply::successWithData(__('messages.updateSuccess'), []);


        // return Reply::successWithData(__('messages.updateSuccess'), 
        // ['redirectUrl' => route('submission-url.index')]);


       
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        


    }

      /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
      
        SeoSubmissionWebsites::findOrFail($id);
    
        SeoSubmissionWebsites::where('id', $id)->delete();
        return Reply::success(__('messages.websiteDeleted'), ['redirectUrl' => route('submission-url.index')]);

    }


    public function getSubmissionUrl(Request $request)
    {

        if($request->seo_task_id =='0' && $request->website_id != '0')  $search_ary = array('website_id'=>$request->website_id);
        else if($request->website_id =='0' && $request->seo_task_id !='0')  $search_ary = array('seo_task_id'=>$request->seo_task_id);
        else if ($request->seo_task_id !='0' && $request->website_id != '0')  $search_ary = array('website_id'=>$request->website_id,'seo_task_id'=>$request->seo_task_id);

        
        $seotasklist=SeoTask::get();
       $seosubmissionwebsites=SeoSubmissionWebsites::select('id','website_id','seo_task_id','website_url','website_username','website_password','date_added','status')
       ->where($search_ary)->get();

        $data['seotasklist']=$seotasklist;
        $data['seosubmissionwebsites']=$seosubmissionwebsites;

        return response()->json($data);
    }


  

}
