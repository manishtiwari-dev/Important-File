<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DataTables\WorkReportDataTable;
use App\Helper\Reply;
use Carbon\Carbon;
use App\Models\Website;
use App\Models\SeoTitle;
use App\Models\SeoWebsiteResult;
use App\Http\Requests\Admin\WorkReport\StoreRequest;
use DB;

use App\Http\Requests\Admin\WorkReport\UpdateRequest;
use function print_r;

class SeoWebsiteResultController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.menu.seo_result');
    }

    public function index()
    {
        $this->addPermission = user()->permission('manage_seo_result');
        abort_403(!in_array($this->addPermission, ['all']));
        $this->web_setting = Website::get();
        $seotitle= SeoTitle::OrderBy('sort_order', 'asc')->where('parent_id', 0)->get();
        $now = Carbon::now();

        $this->year = $now->format('Y');

        $this->month = $now->format('m');

        if (!empty($seotitle)) {
            $seotitle = $seotitle->map(function ($result) {
                $result->child = SeoTitle::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $this->seotitle = $seotitle;


        return view('seo-website-result.index', $this->data);
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }



    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(Request $request)

    {
       
        $result_value=$request->result_value;
        $title_id=$request->title_id;
         
        $count_items = count($result_value);
        for($i=0; $i <= $count_items; $i++){
       
            if(!empty($result_value[$i])){
            SeoWebsiteResult::updateOrCreate([
            'result_title_id'=>$title_id[$i]
            ],
            [
                'result_value'=>$result_value[$i],
                'website_id'=>$request->website_id,
                'month' =>  $request->month,
                'year'  =>  $request->year,
            ]);
        }

      

        }

        return Reply::successWithData(__('messages.updateSuccess'), ['redirectUrl' => route('seo-result.index')]);


        
    
    
    }


    /**
     * @param Request $request
     * @return array
     */

    public function edit($id)
    {
    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }

    /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
    }


    public function getMonthlyResult(Request $request)
    {

        // GET SEO RESULT
        $seo_result = array();
        $seo_result = DB::table('seo_website_result')
            ->select('id','result_title_id', 'result_value')
            ->where([
                "website_id" => $request->website_id,
                "month" => $request->month,
                "year" => $request->year
            ])
            ->get();
           

        $result_array = array();
        if (!empty($seo_result)) {
            foreach ($seo_result as $result) {
                $result_array[$result->result_title_id] = $result->result_value;
            }
        }



        // GET PARENT TITLE
        $seo_title = SeoTitle::select('id', 'title_name', 'parent_id', 'status', 'created_at')
            ->OrderBy('sort_order', 'asc')
            ->where('parent_id', 0)
            ->get();

        // GET CHILD TITLE
        if (!empty($seo_title)) {
            $seo_title = $seo_title->map(function ($title) {

                $title->child = SeoTitle::where('parent_id', $title->id)->get();

                return $title;
            });
        }

        $data['seo_title'] = $seo_title;
        $data['seo_result'] = $result_array;


        return response()->json($data);
    }
}
