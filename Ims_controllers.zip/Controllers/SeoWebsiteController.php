<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests\WebsiteSetting\UpdateWebsite;
use App\Http\Requests\WebsiteSetting\StoreWebsite;
use App\Models\Currency;
use App\Models\Website;
use App\Models\Country;



class SeoWebsiteController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.website';
        $this->activeSettingMenu = 'Website_settings';
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
   public function create(){

        $this->addPermission = user()->permission('add_seo');
        abort_403(!in_array($this->addPermission, ['all']));
        $this->country = Country::get();
        return view('seo-setting.create-website-modal',$this->data);

    }
    public function store(StoreWebsite $request){

        $this->addPermission = user()->permission('add_seo');
        abort_403(!in_array($this->addPermission, ['all']));
        $web_setting = new Website();
        $web_setting->website_name = $request->website_name;
        $web_setting->website_url = $request->website_url;
        $web_setting->countries_id = $request->countries_id;    
        $web_setting->status = $request->status;

        // $web_setting->start_date  = $request->start_date ? Carbon::createFromFormat($this->global->date_format, $request->start_date)->format('Y-m-d') : null;
        $web_setting->start_date  = date('Y-m-d', strtotime($request->start_date)); 
        //  ? Carbon::createFromFormat($this->global->date_format, $request->start_date)->format('Y-m-d') : null;

        $web_setting->save();

        $website_setting = Website::get();
        $country = Country::get();
        
        return Reply::successWithData(__('messages.storewebsite'), ['data' => $website_setting ,'country'=>$country]);

        
    }

    public function edit($id){
        $this->addPermission = user()->permission('edit_seo');
        abort_403(!in_array($this->addPermission, ['all','added']));
        $this->web_setting = Website::findOrFail($id);
        $this->country = Country::get();

        return view('seo-setting.edit-website-modal', $this->data);
    }

   

    public function update(UpdateWebsite $request, $id){
        $web_setting = Website::findOrFail($id);
        $web_setting->website_name = $request->website_name;
        $web_setting->website_url = $request->website_url;
        $web_setting->countries_id = $request->countries_id;
        $web_setting->status = $request->status;
        $web_setting->start_date  = date('Y-m-d', strtotime($request->start_date)); 


        $web_setting->save();

       
        

        return Reply::success(__('messages.updatewebsite'));
        
    }
    public function destroy($id){
        $this->addPermission = user()->permission('delete_seo');
        abort_403(!in_array($this->addPermission, ['all','added']));
        $web_setting = Website::findOrFail($id);
        Website::destroy($id);
        return Reply::success(__('messages.deletewebsite'));
    }
    




    

}
