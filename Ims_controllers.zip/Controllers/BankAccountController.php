<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\Models\PaymentMethod;
use App\Models\BankAccount;
use App\Http\Requests\BankAccount\bankAccountType;
use Illuminate\Http\Request;
use App\Models\BaseModel;

class BankAccountController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.bank';
        $this->activeSettingMenu = 'bank-account';
        $this->middleware(function ($request, $next) {
            abort_403(!(user()->permission('manage_payment_setting') == 'all'));
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {  

         $this->bankdetails = BankAccount::all();
        return view('bank-account.index', $this->data);


    }



    public function create()
    {   
        $this->bankdetails = BankAccount::all();
        return view('bank-account.create-bank',$this->data);
    }

    /**
     * @param UpdateGatewayCredentials $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(bankAccountType $request)
    {  
       
        $bankdetails = new BankAccount();
        $bankdetails->bank_name = $request->bank_name;
        $bankdetails->account_no = $request->account_no;
        $bankdetails->ifsc_code = $request->ifsc_code;
        $bankdetails->account_type = $request->account_type;
        $bankdetails->branch_address = $request->branch_address;
        
        $bankdetails->save();
       
       $bankdetails = BankAccount::get();
      
        return Reply::successWithData(__('messages.accountType'), [ 'page_reload' => $request->page_reload]);

    }



     public function edit($id)
    {   

        $this->bankdetails = BankAccount::find($id);
        return view('bank-account.edit-bank', $this->data);
    }

      public function update(Request $request, $id)
    {
      

          
        $bankdetails = BankAccount::findOrFail($id);
        
        $bankdetails->bank_name = $request->bank_name;
        $bankdetails->account_no = $request->account_no;
        $bankdetails->ifsc_code = $request->ifsc_code;
        $bankdetails->account_type = $request->account_type;
        $bankdetails->branch_address = $request->branch_address;
        
        
        $bankdetails->save();
        
        
        $bankdetails = BankAccount::get();
        return Reply::successWithData(__('messages.updateAccount'),[ 'page_reload' => $request->page_reload]);
        
    }

      public function destroy($id)
    {
        BankAccount::destroy($id);
        return Reply::success(__('messages.accountDelete'));
    }


}
