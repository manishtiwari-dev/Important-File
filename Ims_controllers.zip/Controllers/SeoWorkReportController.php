<?php

namespace App\Http\Controllers;

namespace App\Http\Controllers;
use Artisan;
use Illuminate\Http\Request;
use App\Helper\Reply;
use App\Models\WorkReport;
use App\Models\SeoSubmissionWebsites;
use App\Models\SeoTask;
use App\Models\Website;
use App\Models\User;
use App\Helper\Files;
use Illuminate\Support\Facades\Bus;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\HeadingRowImport;
use Maatwebsite\Excel\Imports\HeadingRowFormatter;
use App\Jobs\ImportWorkReportJob;
use App\Imports\WorkReportImport;
use App\Http\Requests\Admin\Employee\ImportProcessRequest;
use App\Http\Requests\Admin\Employee\ImportRequest;
use DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;



class SeoWorkReportController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.workreport');
        
    }

    public function index()
    {
        $this->addPermission = user()->permission('manage_seo_work_report');
        abort_403(!in_array($this->addPermission, ['all']));
        $seo_task=Website::get();
        $this->seo_task = $seo_task;
       
       
        return view('seo-work-report.index',$this->data);
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      
    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(StoreRequest $request)
    {
       
    
    }
    public function applyQuickAction(Request $request)
    {
        
    }

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
      


    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        


    }

      /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
       

    }

    public function workReportUrl(Request $request)
    {
        // dd($request->all());
       
 
        $this->user=User::get();
        $this->seo_task=SeoTask::get();  
        $this->seo_posting_website=SeoSubmissionWebsites::get();  
        $startdate = $request->startDate;
        $enddate = $request->endDate;
        $website_id = $request->website_id;

       $work_report=WorkReport::with('Users','SeoSetting','SubmissionWebsite')->select('id','website_id','created_at','submission_websites_id','user_id','landing_url','seo_task_id','updated_at')
       ->whereBetween('created_at',[$startdate,$enddate]) 
       ->where('website_id',$website_id)->get();

        return response()->json($work_report);
    }

    

    public function importData()
    {
        $this->pageTitle = __('app.importExcel') . ' ' . __('app.workreport');

        $this->user_list = User::all();
        $this->seo_task_list = SeoTask::all();
        $this->website_list = Website::all();


        if (request()->ajax()) {
            $html = view('seo-work-report.ajax.import', $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'seo-work-report.ajax.import';

        return view('seo-work-report.create', $this->data);
    }

    public function importStore(ImportRequest $request)
    {
        $this->website_id=$request->website_id;
        $this->user_id=$request->user_id;
        $this->seo_task_id=$request->seo_task_id;
        $this->file = Files::upload($request->import_file, 'import-files', false, false, false);
        $excelData = Excel::toArray(new WorkReportImport, public_path('user-uploads/import-files/' . $this->file))[0];
        $this->hasHeading = $request->has('heading');
        $this->heading = array();
        $this->user_list = array();
        $this->seo_task_list = array();
        $this->website_list = array();

        $this->columns = WorkReportImport::$field;
        $this->importMatchedColumns = array();
        $this->matchedColumns = array();

        if ($this->hasHeading) {
            $this->heading = (new HeadingRowImport)->toArray(public_path('user-uploads/import-files/' . $this->file))[0][0];

            // Excel Format None for get Heading Row Without Format and after change back to config
            HeadingRowFormatter::default('none');
            $this->fileHeading = (new HeadingRowImport)->toArray(public_path('user-uploads/import-files/' . $this->file))[0][0];
            HeadingRowFormatter::default(config('excel.imports.heading_row.formatter'));

            array_shift($excelData);
            $this->matchedColumns = collect($this->columns)->whereIn('id', $this->heading)->pluck('id');
            $importMatchedColumns = array();

            foreach ($this->matchedColumns as $matchedColumn) {
                $importMatchedColumns[$matchedColumn] = 1;
            }

            $this->importMatchedColumns = $importMatchedColumns;
        }

        $this->importSample = array_slice($excelData, 0, 5);

        $view = view('seo-work-report.ajax.import_process', $this->data)->render();

        return Reply::successWithData(__('messages.importUploadSuccess'), ['view' => $view]);
    }

    public function importProcess(ImportProcessRequest $request)
    {
        
        // clear previous import
        Artisan::call('queue:clear database --queue=import_work_report');
        Artisan::call('queue:flush');
        // Get index of an array not null value with key
        $columns = array_filter($request->columns, function ($value) {
            return $value !== null;
        });

        $excelData = Excel::toArray(new WorkReportImport, public_path('user-uploads/import-files/' . $request->file))[0];

        if ($request->has_heading) {
            array_shift($excelData);
        }

        $jobs = [];
        
        $columns[3] = 'user_id';
        $excelData[0][3] = 'user_id';
        $columns[4] = 'website_id';
        $excelData[0][4] = 'website_id';
        $columns[5] = 'seo_task_id';
        $excelData[0][5] = 'seo_task_id';

        // dd($excelData);
    
        foreach ($excelData as $key=>$row) {
            if($key != 0){
                $row[3] = $request->user_id;
                $row[4] = $request->website_id;
                $row[5] = $request->seo_task_id;
            }
           
            $jobs[] = (new ImportWorkReportJob($row, $columns));
        }
        // dd('');
        

        $batch = Bus::batch($jobs)->onConnection('database')->onQueue('import_work_report')->name('import_work_report')->dispatch();

        Files::deleteFile($request->file, 'import-files');

        return Reply::successWithData(__('messages.importProcessStart'), ['batch' => $batch]);
    }
}
