<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\SeoTask;
use App\Models\WorkReport;
use App\Helper\Reply;
use App\Models\Website;
use App\Models\SeoSubmissionWebsites;
use Carbon\Carbon;
use Auth;



class SeoDailyWorkController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.workreport';
        
    }

    public function index()
    {
        $this->addPermission = user()->permission('manage_seo_daily_work');
        abort_403(!in_array($this->addPermission, ['all']));
        $this->seo_task_listing = SeoTask::all();
        $this->website_listing = Website::all();
      
    

        return view('seo-daily-report.index',$this->data);
        
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        

    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(Request $request)
    {
        
      
   
    }

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
        $website_listing = Website::findOrFail($id);
        $this->website_listing = $website_listing;
    
        $user_id =Auth::user()->id;
        $today_date=Carbon::today()->toDateString();
       
       
            
        $seo_task_listing = SeoTask::all();
    
        $seo_task_listing->map(function($seo) use ($website_listing,$today_date) {

            $seo->website_submission = SeoSubmissionWebsites::where('website_id','=',$website_listing->website_id)->where('seo_task_id', $seo->id)->get();            
            $seo->work_report = WorkReport::where('website_id','=',$website_listing->website_id)->where('seo_task_id', $seo->id)->where('created_at','LIKE','%'.$today_date.'%')->get();
            return $seo;
            
        });
      
        

        $this->seo_task_listing = $seo_task_listing;
        
     
                
       return view('seo-daily-report.ajax.edit',$this->data);

    }
    

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function work_report_update(Request $request, $id)
    {
    //   dd($request->all());

     
        $website_url=$request->website_url;
        $landing_url=$request->landing_url;       
        $submission_url=$request->submission_url;
        $update_id = $request->update_id;
   
        
   
        $count_items = count($website_url);
        for($i = 0; $i<$count_items; $i++){
            if($landing_url[$i] != ''){
            
            if(empty($update_id[$i])){
             
                
            $work_report = WorkReport::create([

                            'user_id' => Auth::user()->id,            
                            'website_id'=> $request->website_id,
                            'seo_task_id' => $request->seo_task_id,
                            'submission_websites_id'=> $submission_url[$i],               
                            'website_url'=>$website_url[$i],
                            'landing_url'=> $landing_url[$i]
                                
                                    
                        ]);


            }else{

            
            $work_report = WorkReport::where('id',$update_id[$i])->update([
                             
                'submission_websites_id'=> $submission_url[$i],               
                'website_url'=>$website_url[$i],
                'landing_url'=> $landing_url[$i]
                    
                        
            ]);
        
    
            }
            }else{

                return Reply::errorWithData(__('messages.storeError'), ['redirectUrl' => route('seo-website.index')]);

            }
                        // dd($web_url_sumbit);
               
    }

                return Reply::successWithData(__('messages.updateSuccess'), ['redirectUrl' => route('seo-website.index')]);

}



        

       
 

   
    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id){}




    

   


}
