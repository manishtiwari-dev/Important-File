<?php

namespace App\DataTables;

use App\DataTables\BaseDataTable;
use App\Models\WorkReport;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;

class WorkReportDataTable extends BaseDataTable
{

  

   

    public function __construct()
    {
        parent::__construct();
    
    }

    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
        ->eloquent($query)
        ->addColumn('action', function ($row) {
            $action = '<div class="task_view">

            <div class="dropdown">
                <a class="task_view_more d-flex align-items-center justify-content-center dropdown-toggle" type="link"
                    id="dropdownMenuLink-' . $row->id . '" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="icon-options-vertical icons"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink-' . $row->id . '" tabindex="0">';


            $action .= '<a href="'.route('work-report.edit',$row->id).'" class="openRightModal dropdown-item"><i class="fa fa-edit mr-2 "></i>' . __('app.edit') . '</a>';
            
            $action .= '<a class="dropdown-item delete-table-row" href="javascript:;" data-user-id="' . $row->id . '">
                                <i class="fa fa-trash mr-2"></i>
                                ' . trans('app.delete') . '
                            </a>';
            $action .= '</div>
            </div>
        </div>';

            return $action;
        })
        ->editColumn('id', function ($row) {
            if (!is_null($row->id)) {
                return $row->id;
            }
            else {
                return '--';
            }
        })
            ->editColumn('website_id', function ($row) {
                if (!is_null($row->website_id)) {
                    return $row->website_id;
                }
                else {
                    return '--';
                }
            })
            ->editColumn('user_id', function ($row) {
               if (!is_null($row->user_id)) {
                    return $row->user_id;
                }
                else {
                    return '--';
                }
            })
            ->editColumn('seo_task_id', function ($row) {
               if (!is_null($row->seo_task_id)) {
                    return $row->seo_task_id;
                }
                else {
                    return '--';
                }
            })
            ->editColumn('website_url', function ($row) {
                if (!is_null($row->website_url)) {
                     return $row->website_url;
                 }
                 else {
                     return '--';
                 }
             })
             ->editColumn('submission_websites_id', function ($row) {
                if (!is_null($row->submission_websites_id)) {
                     return $row->submission_websites_id;
                 }
                 else {
                     return '--';
                 }
             })
             ->editColumn('landing_url', function ($row) {
                if (!is_null($row->landing_url)) {
                     return $row->landing_url;
                 }
                 else {
                     return '--';
                 }
             })
         
            //  ->editColumn(
            //     'status',
            //     function ($row) {
            //         if ($row->status == 'active') {
            //             return ' <i class="fa fa-circle mr-1 text-light-green f-10"></i>' . __('app.active');
            //         }
            //         else {
            //             return '<i class="fa fa-circle mr-1 text-red f-10"></i>' . __('app.inactive');
            //         }
            //     }
            // )
            ->rawColumns(['website_id', 'user_id','id','action', 'seo_task_id','website_url', 'submission_websites_id','landing_url'])
             ->removeColumn('currency_symbol')
             ->removeColumn('currency_code');
 
            
    }

    public function ajax()
    {
        return $this->dataTable($this->query())
            ->make(true);
    }

    /**
     * @return \Illuminate\Database\Query\Builder
     */
    public function query()
    {
        $request = $this->request();
        $model = WorkReport::select('seo_work_report.id','seo_work_report.website_id', 'seo_work_report.user_id', 'seo_work_report.seo_task_id','seo_work_report.website_url','seo_work_report.submission_websites_id','seo_work_report.landing_url');
                

        if ($request->startDate !== null && $request->startDate != 'null' && $request->startDate != '') {
            $startDate = Carbon::createFromFormat($this->global->date_format, $request->startDate)->toDateString();
            $model = $model->where(DB::raw('DATE(seo_work_report.`created_at`)'), '>=', $startDate);
        }

        if ($request->endDate !== null && $request->endDate != 'null' && $request->endDate != '') {
            $endDate = Carbon::createFromFormat($this->global->date_format, $request->endDate)->toDateString();
            $model = $model->where(DB::raw('DATE(seo_work_report.`created_at`)'), '<=', $endDate);
        }

        if ($request->status != 'all' && !is_null($request->status)) {
            $model = $model->where('seo_work_report.status', '=', $request->status);
        }

        return $model;
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('work_report-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->orderBy(1)
            ->destroy(true)
            ->responsive(true)
            ->serverSide(true)
            /* ->stateSave(true) */
            ->processing(true)
            ->language(__('app.datatable'))
            ->parameters([
                'initComplete' => 'function () {
                    window.LaravelDataTables["work_report-table"].buttons().container()
                    .appendTo( "#table-actions")
                }',
                'fnDrawCallback' => 'function( oSettings ) {
                    $("body").tooltip({
                        selector: \'[data-toggle="tooltip"]\'
                    })
                }',
            ]);
            // ->buttons(Button::make(['extend' => 'excel', 'text' => '<i class="fa fa-file-export"></i> ' . trans('app.exportExcel')]));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
           
            // '#' => ['data' => 'DT_RowIndex', 'orderable' => false, 'searchable' => false, 'visible' => false],
            __('app.id') => ['data' => 'id', 'name' => 'id', 'title' => __('app.id')],
            
            __('modules.workreport.user_id')  => ['data' => 'user_id', 'name' => 'user_id', 'title' => __('modules.workreport.user_id')],
            __('modules.workreport.seo_task_id') => ['data' => 'seo_task_id', 'name' => 'seo_task_id', 'title' => __('modules.workreport.seo_task_id')],
            __('modules.workreport.website_url')  => ['data' => 'website_url', 'name' => 'website_url', 'title' => __('modules.workreport.website_url')],
            __('modules.workreport.submission_websites_id') => ['data' => 'submission_websites_id', 'name' => 'submission_websites_id', 'title' => __('modules.workreport.submission_websites_id')],
            __('modules.workreport.landing_url')  => ['data' => 'landing_url', 'name' => 'landing_url', 'title' => __('modules.workreport.landing_url')],
            // __('app.status') => ['data' => 'status', 'name' => 'status', 'title' => __('app.status')],
            Column::computed('action', __('app.action'))
            
                ->exportable(false)
                ->printable(false)
                ->orderable(false)
                ->searchable(false)
                ->addClass('text-right pr-20')
        ];
    }
/**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'employees_' . date('YmdHis');
    }



    public function pdf()
    {
        set_time_limit(0);

        if ('snappy' == config('datatables-buttons.pdf_generator', 'snappy')) {
            return $this->snappyPdf();
        }

        $pdf = app('dompdf.wrapper');
        $pdf->loadView('datatables::print', ['data' => $this->getDataForPrint()]);

        return $pdf->download($this->getFilename() . '.pdf');
    }

}
