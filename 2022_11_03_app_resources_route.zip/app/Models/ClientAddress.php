<?php

namespace App\Models;

use App\Observers\ClientAddressObserver;
use App\Traits\CustomFieldsTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\ClientAddress
 *
 * @property int $id
 * @property int $user_id
 * @property string|null $address_type
 * @property string|null $street_address
 * @property string|null $city
 * @property string|null $state
 * @property string|null $zipcode
 * @property string|null $country_id
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $added_by
 * @property int|null $last_updated_by
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress query()
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereAddedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereAddressType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereStreetAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereCity($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereLastUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress wherePostalCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereCountryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereState($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|ClientAddress whereUserId($value)
 * @mixin \Eloquent
 */
class ClientAddress extends BaseModel
{
    use CustomFieldsTrait;

    protected static function boot()
    {
        parent::boot();
        static::observe(ClientAddressObserver::class);
    }

    protected $fillable = ['user_id','address_type','street_address','city','state','zipcode','country_id','added_by','last_updated_by'];

    protected $table = 'client_address';

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id')->withoutGlobalScopes(['active']);
    }
    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id','id');
     }

}
