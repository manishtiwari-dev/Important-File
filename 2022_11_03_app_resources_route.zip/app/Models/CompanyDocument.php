<?php

namespace App\Models;

use App\Traits\IconTrait;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Holiday
 *
 * @package App\Models
 * @property int $id
 * @property int $user_id
 * @property string $name
 * @property string $filename
 * @property string $hashname
 * @property string|null $size
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $added_by
 * @property int|null $last_updated_by
 * @property-read mixed $doc_url
 * @property-read mixed $icon
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument query()
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereAddedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereFilename($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereHashname($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereLastUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereSize($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CompanyDocument whereUserId($value)
 * @mixin \Eloquent
 */
class CompanyDocument extends BaseModel
{
    use IconTrait;

    // Don't forget to fill this array
    protected $fillable = [];

    protected $guarded = ['id'];
    protected $table = 'company_docs';
    protected $appends = ['doc_url', 'icon'];


    

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getDocUrlAttribute()
    {
        return asset_url_local_s3('employee-docs/'.$this->user_id.'/'.$this->hashname);
    }

}
