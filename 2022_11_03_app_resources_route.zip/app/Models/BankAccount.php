<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\Observers\BankObserver;
use Illuminate\Database\Eloquent\Factories\HasFactory;

/**
 * App\Models\BankAccount
 *
 * @property int $id
 * @property string $bank_name
 * @property string $ifsc_code
 * @property int $account_no
 * @property string $branch_address
 * @property string|null $account_type
 * @property int|null $added_by
 * @property int|null $updated_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read mixed $icon
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount query()
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereAddedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereMethodDescription($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereUpdatedBy($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereBankName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereIfscCode($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereBranchAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereAccountType($value)
 * @method static \Illuminate\Database\Eloquent\Builder|BankAccount whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class BankAccount extends BaseModel
{
    protected $table = 'company_bank';
    protected $dates = ['created_at'];
    



}
