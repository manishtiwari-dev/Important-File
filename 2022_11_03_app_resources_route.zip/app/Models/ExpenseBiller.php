<?php

namespace App\Models;

use App\Observers\ExpenseBillerObserver;
use App\Traits\CustomFieldsTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\ExpenseBiller
 *
 * @property int $id
 * @property string $biller_name
 * @property string|null $biller_address
 * @property int $taxable_bill
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property int|null $added_by
 * @property int|null $updated_by
 
 * @method static Builder|ExpenseBiller newModelQuery()
 * @method static Builder|ExpenseBiller newQuery()
 * @method static Builder|ExpenseBiller query()
 * @method static Builder|ExpenseBiller whereAddedBy($value)
 * @method static Builder|ExpenseBiller whereId($value)
 * @method static Builder|ExpenseBiller whereLastUpdatedBy($value)
 * @method static Builder|ExpenseBiller whereUpdatedAt($value)
 * @method static Builder|ExpenseBiller whereUserId($value)
 * @mixin \Eloquent
 */
class ExpenseBiller extends BaseModel
{
    use CustomFieldsTrait;

    protected $table = 'expenses_biller';


    protected static function boot()
    {
        parent::boot();
        static::observe(ExpenseBillerObserver::class);
    }


}
