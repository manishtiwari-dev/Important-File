<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\EmployeeSalary
 *
 * @property int $id
 * @property int $user_id
 * @property int $salary
 *  @property \Illuminate\Support\Carbon $increment_date
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read mixed $icon
 * @property-read \App\Models\Skill $skill
 * @property-read \App\Models\User $user
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary query()
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereSalary($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereIncrementDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|EmployeeSalary whereUserId($value)
 * @mixin \Eloquent
 */
class EmployeeSalary extends BaseModel
{
    protected $table = 'employee_salary_increment';

  


}
