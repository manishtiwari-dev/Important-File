<?php

namespace App\Traits;

use App\Models\Contract;
use App\Models\ContractSign;
use App\Models\DashboardWidget;
use App\Models\Lead;
use App\Models\LeadSource;
use App\Models\LeadStatus;
use App\Models\Payment;
use App\Models\ProjectTimeLog;
use App\Models\Role;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

/**
 *
 */
trait SeoTask
{
    use CurrencyExchange;

    /**
     *
     * @return void
     */
    public function SeoTask()
    {
       
       

       echo"asdfghjkl";
    }

    

}
