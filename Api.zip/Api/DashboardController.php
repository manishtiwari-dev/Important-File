<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\AppSetting;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\AppSettingsGroup;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Country;
use App\Models\Order;
use App\Models\User;

use App\Events\GlobalEventBetweenSuperAdminAndAdmin;
use App\Events\PrEventInternal;


class DashboardController extends Controller
{


    public function index(Request $request){

        // dispatch global event
        // GlobalEventBetweenSuperAdminAndAdmin::dispatch('working');

        // dispatch private event
        // PrEventInternal::dispatch('pribvate-working');

        // Validate user page access
        $api_token = $request->api_token;
        $userType = $request->userType;

        $res = [];

        if($userType == 'subscriber')
            $res = $this->admin_dashboard();
        else
            $res = $this->super_dashboard();

        return ApiHelper::JSON_RESPONSE(true,$res,'');
    }

    /* admin dashboard */
    public function admin_dashboard()
    {
        $response = [];

        $response['total_orders'] = Order::count();
        $response['total_users'] = User::count();
        $response['total_quatations'] = User::count();
        $response['total_order_profit'] = User::count();
        $response['total_orders_list'] = Order::selectRaw(' *, 
            CASE
                WHEN order_status = 1 THEN "Pending"
                WHEN order_status = 2 THEN "InProcess"
                WHEN order_status = 3 THEN "Dispatch"
                ELSE "Deliverd"
            END AS order_status,
            CASE
                WHEN payment_status = 1 THEN "Pending"
                WHEN payment_status = 2 THEN "Paid"
                ELSE "Failed"
            END AS payment_status
            ')->orderBy('order_id', 'DESC')->take(5)->get();

          
             $months = range(1,12);

             $month_name=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July',
             'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        
         
           $chartdata = [];
            
            $options = [
                'charts'=>[ 'id'=>"basic-bar" ],
                "xaxis"=>[ "categories"=>$month_name ]
            ];

          
           foreach ($months as $key => $month) {

          
           
            $orderCount = Order::whereRaw('MONTH(created_at) = '.$month)->count();
            
            array_push($chartdata, $orderCount);
          }   




        $series = [ "name"=>"ORDER", "data"=>$chartdata ];

        $response['chartItem10Year'] = [ 'options'=>$options, 'series'=>[$series] ];

        return $response;
    }

    /* super admin dashboard */
    public function super_dashboard()
    {
        $response = [];


        return $response;
    }

    
}
