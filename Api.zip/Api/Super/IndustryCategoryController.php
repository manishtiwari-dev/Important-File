<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Industry;
use App\Models\Super\IndustryCategory;

use ApiHelper;



class IndustryCategoryController extends Controller
{
  

	public function index(Request $request){
        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?$request->perPage:10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        /*Fetching industry data*/ 
        $industry_section_query = IndustryCategory::where('industry_id',$request->industry_id);
        
        if(!empty($search))
            $industry_section_query = $industry_section_query->where("industry_category_name","LIKE", "%{$search}%");

        /* order by sorting */
        if(!empty($sortBY) && !empty($ASCTYPE)){
            $industry_section_query = $industry_section_query->orderBy($sortBY,$ASCTYPE);
        }else{
            $industry_section_query = $industry_section_query->orderBy('industry_category_id','ASC');
        } 

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;

        $industry_count = $industry_section_query->count();

        $industry_list = $industry_section_query->skip($skip)->take($perPage)->get();

        $industry_list = $industry_section_query->get();
        //    if (!empty($industry_list)) { 
            
        //     $industry_list->map(function($data){
        //         /* Checking if subscriber name is not empty*/
              
        //         if(!empty($data->industry_details)){
        //             $data->subscriber_industry = $data->industry_details->industry_name;
        //         }
               

              
               
                
        //         /* Checking subscription status*/
        //         return $data;
        //     });
        // }

        
        $res = [
            'data'=>$industry_list,
            'current_page'=>$current_page,
            'total_records'=>$industry_count,
            'total_page'=>ceil((int)$industry_count/(int)$perPage),
            'per_page'=>$perPage,
        ];
        /*returning data to client side*/
        return ApiHelper::JSON_RESPONSE(true,$res,'');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;
        $industry_category_name = $request->industry_category_name;
        $banner_url = $request->banner_url;
        $video_url = $request->video_url;
        $industry_category_title = $request->industry_category_title;
        $industry_category_desc = $request->industry_category_desc;

        $sort_order = $request->sort_order;
       
        $validator = Validator::make($request->all(),[
            'industry_category_name' => 'required',
            'sort_order'=>'required',
        ],[
            'industry_category_name.required'=>'INDUSTRY_CATEGORY_NAME_REQUIRED',
            'sort_order.required'=>'SORT_ORDER_REQUIRED',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());

        $data = IndustryCategory::create([
            'industry_category_name' => $industry_category_name,
            'demo_db'=>$request->demo_db,
            'banner_url'=>$banner_url,
            'video_url'=>$video_url,
            'industry_category_title'=>$industry_category_title,
            'industry_category_desc'=>$industry_category_desc,
            'banner_url'=>$banner_url,

            'industry_category_slug' => \Str::slug($industry_category_name, '-'),

            'industry_id'=>$request->industry_id,
            'demo_url'=>$request->demo_url,
            'sort_order' => $sort_order,
            'status'=>$request->status,
           
        ]);

        // $industry_data = Industry::where('industry_id',$data['industry_id'])->first();
        // //$module = [];
        // foreach ($module_id as $key => $value) {
        //     $module_data= IndustryModule::create([
        //         'industry_id' => $industry_data->industry_id,
        //         'module_id' => $value,
        //         'sort_order' => $sort_order,
        //     ]);
        // }
             
        //  foreach($function_id as $key =>$value){

        //    $industry_data=WebFunctionsIndustry::create([

        //      'function_id'=>$value,
        //      'industry_id'=>$industry_data->industry_id,


        //    ]);
           

        //  }
         

         if($data)
            return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_INDUSTRY_CATEGORY_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_INDUSTRY_CATEGORY_ADD');
    }

    public function edit(Request $request){

        $industry_category_id = $request->industry_category_id;

        $data = IndustryCategory::where('industry_category_id',$industry_category_id)->first();
        //$data->modules = $data->modules;
        return ApiHelper::JSON_RESPONSE(true,$data,'');
    }

    public function update(Request $request){
        $api_token = $request->api_token;
        $industry_category_id=$request->industry_category_id;
        $industry_category_name = $request->industry_category_name;
        $banner_url = $request->banner_url;
        $video_url = $request->video_url;
        $industry_category_title = $request->industry_category_title;
        $industry_category_desc = $request->industry_category_desc;

       
        $validator = Validator::make($request->all(),[
            'industry_category_name' => 'required',
            'sort_order'=>'required',
        ],[
            'industry_category_name.required'=>'INDUSTRY_CATEGORY_NAME_REQUIRED',
            'sort_order.required'=>'SORT_ORDER_REQUIRED',
        ]);
        
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());
        


        $data = IndustryCategory::where('industry_category_id',$industry_category_id)->update([
            'industry_category_name' => $industry_category_name,
            'demo_db'=>$request->demo_db,
            'industry_id'=>$request->industry_id,
            'demo_url'=>$request->demo_url,
            'status'=>$request->status,
            'sort_order' => $request->sort_order,
            'banner_url'=>$banner_url,
            'video_url'=>$video_url,
            'industry_category_title'=>$industry_category_title,
            'industry_category_desc'=>$industry_category_desc,
            'banner_url'=>$banner_url,
            'industry_category_slug' => Str::slug($industry_category_name, '-'),

        ]);
        
    

        return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_INDUSTRY_CATEGORY_UPDATE');
    }

    public function create(Request $request){
        $api_token = $request->api_token;
       

        $industry_list = Industry::all();



       return ApiHelper::JSON_RESPONSE(true,$industry_list,'');
    }

  

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token; 
        $industry_category_id = $request->industry_category_id;
        $sub_data = IndustryCategory::where('industry_category_id',$industry_category_id)->first();
        $sub_data->status = ($sub_data->status == 0 ) ? 1 : 0;         
        $sub_data->save();
        
        return ApiHelper::JSON_RESPONSE(true,$sub_data,'CATEGORY_STATUS');
    }
   
    
    
    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $status = IndustryCategory::where('industry_category_id',$request->industry_category_id)->delete();
        if($status) {
            return ApiHelper::JSON_RESPONSE(true,[],'SUCCESS_INDUSTRY_CATEGORY_GROUP_DELETE');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_INDUSTRY_CATEGORY_DELETE');
        }
    }

}