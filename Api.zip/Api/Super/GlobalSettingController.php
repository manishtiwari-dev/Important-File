<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\Language;
use App\Models\Translation;
use App\Models\TranslationKey;
use App\Models\Super\AppSettingsGroup;
use App\Models\Super\SuperAppSetting;


class GlobalSettingController extends Controller
{



    public function index(Request $request){

        /*fetching data from api*/
        $languages_code = $request->language;
        $lang_key = $request->lang_key;

        /*fetching translation data*/
        $language_data = Language::where('languages_code',$languages_code)->first();
        if(!empty($language_data->languages_id)){
            $data = Translation::where('languages_id', $language_data->languages_id)->where('lang_key', $lang_key)->first();
        }else{
            $data = Translation::where('languages_id', '1')->where('lang_key', $lang_key)->first();
        }
        /*checking if translation data is not empty*/

        if(!empty($data)){
            /*fetching language data*/
            $data->lang = $data->language->lang_value;
        }



        $sett_arr = [];

        $set_group = AppSettingsGroup::with('settings')->where('access_privilege', 2)->where('status', 1)->get();

        if(!empty($set_group)){
            foreach ($set_group as $key => $group) {
                
                if(!empty($group->settings)){
                    foreach ($group->settings as $key => $settings) {
                        
                        $set_value = SuperAppSetting::where('setting_key', $settings->setting_key)->first();
                        
                        if($settings->option_type == 'image')
                            $set_val = !empty($set_value) ? ApiHelper::getSuperFullImageUrl($set_value->setting_value, '') : '';
                        else
                            $set_val = !empty($set_value) ? $set_value->setting_value : '';

                        $sett_arr[$settings->setting_key] = $set_val;

                    }
                }

            }
        }

        

        $general = [
            'language_data'=>$data,
            'setting_data'=>$sett_arr,
        ];

        /*returning something to client side*/
        return ApiHelper::JSON_RESPONSE(true,$general,'');

    }
    
    
}
