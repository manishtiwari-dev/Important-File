<?php

namespace Modules\Postal\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Acl\Repositories\AclRepository;

class PostalShipmentController extends Controller
{

    public function __construct(AclRepository $aclRepository)
    {
        $this->aclRepo = $aclRepository;
        // check on permissions
        $this->middleware('user_role:1|0|3|4')->only('index', 'shipmentsReport', 'create');
        $this->middleware('user_role:4')->only('ShipmentApis');

        $this->postalBaseurl = 'https://test.ws.ufficiopostale.com/';
    }

    public function postalshippment()
    {
        breadcrumb([
            [
                'name' => __('cargo::view.dashboard'),
                'path' => fr_route('admin.dashboard'),
            ],
            [
                'name' => __('postal::view.create_new_postal'),
            ],
        ]);

        $adminTheme = env('ADMIN_THEME', 'adminLte');

        $url = $this->postalBaseurl . 'pricing/';

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 62b5694a7c027865406f1b42',
        ];

        $client = new Client([
            'headers' => $headers,
        ]);

        $response = $client->request('GET', $url);

        $obj = json_decode($response->getBody());

        $datakey = $obj->data;

        // foreach($datakey as $key => $value){
        //     print_r($value->tipologia);
        // }

        // print_r($obj->data);

        return view('postal::' . $adminTheme . '.pages.postal', compact('datakey'))->render();
    }

    public function getPostalDetails(Request $request)
    {

        $adminTheme = env('ADMIN_THEME', 'adminLte');

        $cap = $request->post_code;
        // dd($request->all());
        // die;

        // dd($cap);

        $url = 'https://test.ws.ufficiopostale.com/comuni/' . $cap;

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 62b5694a7c027865406f1b42',
        ];

        $client = new Client([
            'headers' => $headers,
        ]);

        $response = $client->request('GET', $url);

        $obj = json_decode($response->getBody());

        if (!empty($obj)) {
            return ($obj);
        } else {
            return array();
        }

    }

    public function getpost(Request $request)
    {
        
        if (isset($request->image)) {
            $image = $request->image;
            foreach ($image as $key) {
                $file = $key['previewUrl'];
            }
        } else {
            $file = $request->testo;
        }

        $sender = [
            "mittente" => [
                'titolo' => 'mr',
                'nome' => $request->nome,
                'cognome' => $request->cognome,
                'dug' => $request->dug_mittente,
                'indirizzo' => $request->indirizzo_mittente,
                'civico' => $request->civico,
                'comune' => $request->comune,
                'cap' => $request->cap,
                'provincia' => $request->provincia,
                'nazione' => 'Italia',
                'email' => $request->email,

            ],
            "destinatari" => [
                [
                    'nome' => $request->destinatario_nome,
                    'cognome' => $request->destinatario_cognome,
                    'co' => 'fgdfg',
                    'dug' => $request->destinatario_dug_mittente,
                    'indirizzo' => $request->destinatario_indirizzo_mittente,
                    'civico' => $request->destinatario_civico,
                    'comune' => $request->destinatario_comune,
                    'cap' => $request->destinatario_cap,
                    'provincia' => $request->destinatario_provincia,
                    'nazione' => 'Italia',
                ],

            ],
            "documento" => [

                $file,

            ],
            "opzioni" => [
                "fronteretro" => false,
                "colori" => false,
                "autoconfirm" => false,
            ],
        ];

        $data = [
            "fields" => $sender,
            "mailType" => $request->ricevuta_invio_poste ?? 'raccomandata',
        ];

        // dd($data);
        // die;

        if ($data['mailType'] == 'raccomandata') {
            $api_endpoint = 'raccomandate/';
        } else if ($data['mailType'] == 'posta4') {
            $api_endpoint = 'prioritarie/';
        } else if ($data['mailType'] == 'telegramma') {
            $api_endpoint = 'telegrammi/';
        } else if ($data['mailType'] == 'posta1') {
            $api_endpoint = 'ordinarie/';
        }

        $postJsonData = json_encode($data['fields']);
        $adminTheme = env('ADMIN_THEME', 'adminLte');

        $request->session()->put('service_provider', $data['mailType']);
        $request->session()->put('endpoind', $api_endpoint);

        $request->session()->put('return_receipt', $request->return_receipt);

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 62b5694a7c027865406f1b42',
        ];

        $client = new Client([
            'headers' => $headers,
        ]);

        $r = $client->request('POST', 'https://test.ws.ufficiopostale.com/' . $api_endpoint, [
            'body' => $postJsonData,
        ]);

        try {
            $data = json_decode($r->getBody()->getContents());

            $response = $data->data;

            $request->session()->put('getpostData', $response);

            return view('postal::' . $adminTheme . '.pages.data_sammary', compact('response'))->render();
        } catch (Client $ex) {
            echo $ex;
        }

    }

    public function checkout(Request $request)
    {
        breadcrumb([
            [
                'name' => __('cargo::view.dashboard'),
                'path' => fr_route('admin.dashboard'),
            ],
            [
                'name' => __('postal::view.create_new_postal'),
                'path' => fr_route('shipments.postal'),
            ],
            [
                'name' => __('postal::view.postal_summary'),
                'path' => fr_route('getpost'),
            ],
            [
                'name' => __('postal::view.checkout'),
            ],
        ]);

        $checkoutlist = $request->session()->get('getpostData');
        // print_r($checkoutdata);
        foreach ($checkoutlist as $checkout) {
            $check_data = $checkout->id;
            $request->session()->put('check_id', $check_data);
        }

        if ($request->session()->has('return_receipt')) {
            $payment = $request->session()->get('return_receipt');
        } else {
            $payment = 0;
        }

        $service_provider = $request->session()->get('endpoind');
        // $checkout_id= $request->session()->get('check_id');

        $url = $this->postalBaseurl . $service_provider . $check_data;

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer 62b5694a7c027865406f1b42',
            'ricevuta' => '1',
        ];
        $client = new Client([
            'headers' => $headers,
        ]);

        $response = $client->request('GET', $url);

        // $response = $client->request->setQueryData([
        // 'ricevuta' => '1'
        // ]);

        // $obj = json_decode($response->getBody());

        // $datakey=$obj->data;

        // print_r($datakey);
        // die;

        try {
            $data = json_decode($response->getBody()->getContents());

            $checkoutdata = collect($data)->toArray();

            $request->session()->put('postalData', $checkoutdata);

            $adminTheme = env('ADMIN_THEME', 'adminLte');
            return view('postal::' . $adminTheme . '.pages.checkout', compact('checkoutdata', 'payment'))->render();

        } catch (Client $ex) {
            echo $ex;
        }

    }

    // public function return_receipt(Request $request)
    // {
    //     $service_provider = $request->session()->get('endpoind');
    //     $checkout_id= $request->session()->get('check_id');

    //    $url = $this->postalBaseurl.$service_provider.$checkout_id;

    //     $headers = [
    //         'Content-Type' => 'application/json',
    //         'Authorization' => 'Bearer 62b5694a7c027865406f1b42',
    //         'ricevuta' => '1'
    //     ];
    //     $client = new Client([
    //         'headers' => $headers
    //     ]);

    //     $response = $client->request('GET',$url);

    //     // $response = $client->request->setQueryData([
    //     // 'ricevuta' => '1'
    //     // ]);

    //     $obj = json_decode($response->getBody());

    //     $datakey=$obj->data;

    //     print_r($datakey);
    //     die;
    // }

}
