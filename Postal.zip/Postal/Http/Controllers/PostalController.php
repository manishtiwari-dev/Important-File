<?php

namespace Modules\Postal\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Postal\Http\DataTables\PostalDataTable;
use Modules\Currency\Entities\Currency;
use Modules\Postal\Entities\Postal;

class PostalController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(PostalDataTable $dataTable , $status = 'all' , $type = null)
    {
        breadcrumb([
            [
                'name' => __('postal::view.dashboard'),
                'path' => fr_route('admin.dashboard')
            ],
            [
                'name' => __('postal::view.postal')
            ]
        ]);

        // $actions = new ShipmentActionHelper();
        // if($status == 'all'){ 
        //     $actions = $actions->get('all');
        // }else{ 
        //     $actions = $actions->get($status, $type);
        // }

        $data_with = [];
        $share_data = array_merge(get_class_vars(PostalDataTable::class), $data_with);

        $adminTheme = env('ADMIN_THEME', 'adminLte');
        return $dataTable->render('postal::'.$adminTheme.'.pages.postal.index', $share_data);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('postal::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        // dd($id);
        breadcrumb([
            [
                'name' => __('postal::view.users'),
                'path' => fr_route('postal.index')
            ],
            [
                'name' => __('view.profile_details')
            ],
        ]);

        $postal = Postal::findOrFail($id);

        $sender_data=json_decode($postal->sender_data);
        $destination_data=json_decode($postal->destination_data);
        $billing_Details=json_decode($postal->billing_Details);
            
        foreach($destination_data as $key => $data){
            $datalist=$data;    
         }   
     
        $adminTheme = env('ADMIN_THEME', 'adminLte');return view('postal::'.$adminTheme.'.pages.postal.show')->with(['model' => $postal,'senderData'=>$sender_data, 'destinationData' => $datalist, 'billingDetails' => $billing_Details]);
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('postal::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
