<?php

namespace Modules\Postal\Http\Controllers;

use Illuminate\Http\Request;
use App\Order;
use Modules\Cargo\Entities\BusinessSetting;
use Modules\Currency\Entities\Currency;
use App\Seller;
use App\CustomerPackage;
use App\SellerPackage;
use Stripe\Stripe;
use Modules\Postal\Http\Requests\PostalRequest; 
use Modules\Postal\Entities\Postal; 
use Modules\Cargo\Entities\Transaction;
use Modules\Cargo\Entities\Client;
use Illuminate\Support\Facades\Auth;
use Session;

class StripePaymentController
{

    public function paymentProcess(Request $request) {
        
       $billing_Details=$request->all();
      
         $request->session()->put('billing_Details',$billing_Details);
        
        $adminTheme = env('ADMIN_THEME', 'adminLte');
        return view('postal::'.$adminTheme.'.pages.payments.paymentprocess');
        // $this->stripe();
    }


    public function paymentMethod(Request $request) {

        $billing_Details = $request->session()->get('billing_Details');

        $checkoutdata = $request->session()->get('postalData');
        $data = $checkoutdata['data'];
        $file=$data->documento[0];
        
        $request->session()->put('total_Amount',$data->pricing->totale->importo_totale);
        $service_provider = $request->session()->get('service_provider');

        $array = [
           'postal_unique_id'=>$data->id,
            'sender_data' => json_encode($data->mittente),
            'destination_data'=>json_encode($data->destinatari),
            'service_provider'=>$service_provider,
            'total_Amount'=>$data->pricing->totale->importo_totale_netto,
            'tax_amount'=>$data->pricing->totale->importo_totale_iva,
            'final_amount'=>$data->pricing->totale->importo_totale,
            'document' =>$file,
            'receipt_pdf' =>$data->documento_validato->pdf,
            'billing_Details'=>json_encode($billing_Details),

        ];

        if($request->check_method_page == 1){
            
            $this->stripe($array);

            $adminTheme = env('ADMIN_THEME', 'adminLte');
            return view('postal::'.$adminTheme.'.pages.payments.stripe');
        }else{

            $client_id = Client::where('user_id',auth()->user()->id)->pluck('id')->first();
            $transactions = Transaction::where('client_id', $client_id )->orderBy('created_at','desc')->sum('value');
            
            if($transactions > $data->pricing->totale->importo_totale){

                Transaction::create([
                    'value' => '-'.$data->pricing->totale->importo_totale, 
                    'transaction_owner' => 3,
                    'type' => 3,
                    'created_by' =>Auth::id(),

                ]);
                
                $postalId = Postal::create([
                    'postal_unique_id'=>$array['postal_unique_id'],
                    'sender_data'=>$array['sender_data'], 
                    'destination_data'=>$array['destination_data'],
                    'billing_Details'=>$array['billing_Details'],
                    'service_provider'=>$array['service_provider'],
                    'total_Amount'=>$array['total_Amount'],
                    'tax_amount'=>$array['tax_amount'],
                    'final_amount'=>$array['final_amount'],
                    'payment_method'=>'card',
                    'payment_status'=>'pending',
                    'document' =>$array['document'],
                    'receipt_pdf' =>$array['receipt_pdf'],
                    'created_by'=>Auth::id(),
                    ]);

                    
                Postal::where('id',$postalId->id)->update(['payment_status' => 'success']);
            

            }else{
                 return redirect()->back();
            }

            $receiptlist=Postal::where('id',$postalId->id)->get('receipt_pdf');
            foreach($receiptlist as $receipt){
                $receipt=$receipt->receipt_pdf;
            }

            if($request->session()->has('return_receipt')){
                $payment=$request->session()->get('return_receipt');
                }else{
                    $payment=0;
                }
                
            $adminTheme = env('ADMIN_THEME', 'adminLte');
            return view('postal::'.$adminTheme.'.pages.payments.postal-thanks-pay',compact('payment','receipt'));


        }
        
    }


    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */


    public function stripe($array)
    {

 $postalId = Postal::create([
                'postal_unique_id'=>$array['postal_unique_id'],
                'sender_data'=>$array['sender_data'], 
                'destination_data'=>$array['destination_data'],
                'billing_Details'=>$array['billing_Details'],
                'service_provider'=>$array['service_provider'],
                'total_Amount'=>$array['total_Amount'],
                'tax_amount'=>$array['tax_amount'],
                'final_amount'=>$array['final_amount'],
                'payment_method'=>'card',
                'payment_status'=>'pending',
                'document' =>$array['document'],
                'receipt_pdf' =>$array['receipt_pdf'],
                'created_by'=>Auth::id(),
                ]);
        

        $postal_data = $postalId->id;
        Session::put('postal_id',$postal_data);

        
    }

    public function create_checkout_session(Request $request) {

        if($request->session()->has('return_receipt')){
        $returnReceipt = $request->session()->get('return_receipt');
        }else{
            $returnReceipt=0;
        }
        
        if($request->session()->has('postalData')){
            $checkoutdata = $request->session()->get('postalData');
            
            $amount = $checkoutdata['data']->pricing->totale->importo_totale; 
            $mainAmount=$amount+$returnReceipt;
            $amount = round($mainAmount * 100);
        } else{
            $amount = 1000;
        }
        // $amount = 0;
        //if($request->session()->has('payment_type')){
            //if($request->session()->get('payment_type') == 'cart_payment'){
                // $shipment = Shipment::findOrFail(Session::get('order_id'));
                //$checkoutdata = $request->session()->get('postalData');
                //$amount = $checkoutdata[0]->pricing->totale->importo_totale; 
            // }
            // elseif ($request->session()->get('payment_type') == 'wallet_payment') {
            //     $amount = round($request->session()->get('payment_data')['amount'] * 100);
            // }
            // elseif ($request->session()->get('payment_type') == 'customer_package_payment') {
            //     $customer_package = CustomerPackage::findOrFail(Session::get('payment_data')['customer_package_id']);
            //     $amount = round($customer_package->amount * 100);
            // }
            // elseif ($request->session()->get('payment_type') == 'seller_package_payment') {
            //     $seller_package = SellerPackage::findOrFail(Session::get('payment_data')['seller_package_id']);
            //     $amount = round($seller_package->amount * 100);
            // }
        //}
        
        
          $paymentSettings = resolve(\Modules\Payments\Entities\PaymentSetting::class)->toArray();
  $stripe_payment  = json_decode($paymentSettings['stripe_payment'], true);

        \Stripe\Stripe::setApiKey($stripe_payment['STRIPE_SECRET']);

        $session = \Stripe\Checkout\Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [
                [
                    'price_data' => [
                        'currency' => Currency::where('default',1)->first()->code,
                        'product_data' => [
                            'name' => "Payment"
                        ],
                        'unit_amount' => $amount,
                    ],
                    'quantity' => 1,
                ]
            ],
            'mode' => 'payment',
            'success_url' => route('stripe.success'),
            'cancel_url' => route('stripe.cancel'),
        ]);
        return response()->json(['id' => $session->id, 'status' => 200]);
    }

    public function success(Request $request) {
        try{
            
            $payment = ["status" => "Success"];

            $postal_data_id = $request->session()->get('postal_id');
            
         
            Postal::where('id',$postal_data_id)->update(['payment_status' => 'success']);
             
            $receiptlist=Postal::where('id',$postal_data_id)->get('receipt_pdf');
            foreach($receiptlist as $receipt){
                $receipt=$receipt->receipt_pdf;
            }
    
            if($request->session()->has('return_receipt')){
                $payment=$request->session()->get('return_receipt');
                }else{
                    $payment=0;
                }
                
            $adminTheme = env('ADMIN_THEME', 'adminLte');
            return view('postal::'.$adminTheme.'.pages.payments.postal-thanks-pay',compact('payment','receipt'));

            // $payment_type = Session::get('payment_type');

            // if ($payment_type == 'cart_payment') {
                // $checkoutController = new CheckoutController;
                // return $checkoutController->checkout_done( null, $payment, Session::get('order_id'));
            // }

            // if ($payment_type == 'wallet_payment') {
            //     $walletController = new WalletController;
            //     return $walletController->wallet_payment_done(session()->get('payment_data'), json_encode($payment));
            // }

            // if ($payment_type == 'customer_package_payment') {
            //     $customer_package_controller = new CustomerPackageController;
            //     return $customer_package_controller->purchase_payment_done(session()->get('payment_data'), json_encode($payment));
            // }
            // if($payment_type == 'seller_package_payment') {
            //     $seller_package_controller = new SellerPackageController;
            //     return $seller_package_controller->purchase_payment_done(session()->get('payment_data'), json_encode($payment));
            // }
        }
        catch (\Exception $e) {
            flash('Payment failed')->error();
    	    return redirect()->route('home');
        }
    }

    public function cancel(Request $request){
        flash('Payment is cancelled')->error();
        return redirect()->route('shipments.show', Session::get('order_id'));
    }
}
