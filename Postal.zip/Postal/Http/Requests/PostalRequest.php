<?php

namespace Modules\Postal\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Postal\Entities\Postal;

class PostalRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $email_validation = 'required|max:50|email|unique:users,email';
        $password_validation = 'string|min:6';
        if ($this->method() == 'PUT') {
            $user_id = Postal::where('id',$this->route('client'))->pluck('user_id')->first();
            $email_validation .= (',' . $user_id . 'id');
            $password_validation = 'nullable|' . $password_validation;
        } else {
            $password_validation = 'required|' . $password_validation;
        }
        return [
            'sender_data' => 'required',
            'destination_data' => 'required',
        ];
    }

    public function messages()
    {
        return [
                'responsible_mobile.regex' => __('cargo::view.please_enter_country_code'),
                'follow_up_mobile.regex'   => __('cargo::view.please_enter_country_code'),
        ];
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
}