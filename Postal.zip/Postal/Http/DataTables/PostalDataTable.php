<?php

namespace Modules\Postal\Http\DataTables;

use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;
use Yajra\DataTables\Html\Button;
use Modules\Postal\Entities\Postal;
use Illuminate\Http\Request;
use Modules\Cargo\Http\Filter\ShipmentFilter;

class PostalDataTable extends DataTable
{

    public $table_id = 'postals';
    public $btn_exports = [
        'excel',
        'print',
        'pdf'
    ];
    public $filters = ['total_amount', 'payment_method' ,'payment_status' ];
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     *
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->rawColumns(['action', 'select','total_amount'])

            
            ->filterColumn('total_amount', function($query, $keyword) {
                $query->where('total_amount', 'LIKE', "%$keyword%");
            })
            ->filterColumn('payment_method', function($query, $keyword) {
                $query->where('payment_method', 'LIKE', "%$keyword%");
            })
            ->filterColumn('payment_status', function($query, $keyword) {
                $query->where('payment_status', 'LIKE', "%$keyword%");
            })

            ->orderColumn('final_amount', function ($query, $order) {
                $query->orderBy('final_amount', $order);
            })

            ->addColumn('select', function (Postal $model) {
                $adminTheme = env('ADMIN_THEME', 'adminLte');
                return view($adminTheme.'.components.modules.datatable.columns.checkbox', ['model' => $model, 'ifHide' => $model->id == 0]);
            })
            ->editColumn('id', function (Postal $model) {
               return $model->id;
            })

            ->editColumn('total_Amount', function (Postal $model) {
                return format_price($model->total_Amount) ?? "";
            })


            ->editColumn('created_at', function (Postal $model) {
                return date('d M, Y H:i', strtotime($model->created_at));
            })
           

            ->addColumn('action', function (Postal $model) {
                $adminTheme = env('ADMIN_THEME', 'adminLte');return view('postal::'.$adminTheme.'.pages.postal.columns.actions', ['model' => $model, 'table_id' => $this->table_id]);
            });
    }

    /**
     * Get query source of dataTable.
     *
     * @param  Shipment  $model
     *
     * @return Shipment
     */
    public function query(Postal $model, Request $request)
    {
        $query = $model->getPostal($model,$request)->newQuery();

 
        // class filter for user only
        // $client_filter = new PlanFilter($query, $request);

        // $query = $client_filter->filterBy($this->filters);

        return $query;
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        $lang = \LaravelLocalization::getCurrentLocale();
        return $this->builder()
            ->setTableId($this->table_id)
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->stateSave(true)
            ->orderBy(1)
            ->responsive()
            ->autoWidth(false)
            ->parameters([
                'scrollX' => true,
                'dom' => 'Bfrtip',
                'language' => ['url' => "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/$lang.json"],
                'buttons' => [
                    ...$this->buttonsExport(),
                ],
            ])
            ->addTableClass('align-middle table-row-dashed fs-6 gy-5');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::computed('select')
                    ->title('
                        <div class="form-check form-check-sm form-check-custom form-check-solid">
                            <input class="form-check-input checkbox-all-rows" type="checkbox">
                        </div>
                    ')
                    ->responsivePriority(-1)
                    ->addClass('not-export')
                    ->width(50),
            Column::make('id')->title(__('postal::view.table.id'))->width(50),
            Column::make('total_Amount')->title(__('postal::view.total_amount')),
            Column::make('payment_method')->title(__('postal::view.payment_method')),
            Column::make('payment_status')->title(__('postal::view.payment_status')),
            Column::computed('action')
                ->title(__('view.action'))
                ->addClass('text-center not-export')
                ->responsivePriority(-1)
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'shipments_'.date('YmdHis');
    }


    /**
     * Transformer buttons export.
     *
     * @return string
     */
    protected function buttonsExport()
    {
        $btns = [];
        foreach($this->btn_exports as $btn) {
            $btns[] = [
                'extend' => $btn,
                'exportOptions' => [
                    'columns' => 'th:not(.not-export)'
                ]
            ];
        }
        return $btns;
    }
}