<?php

return [
    'name' => 'Postal',

    'postal' => [ 
        'Postal-data',
    ],
];
