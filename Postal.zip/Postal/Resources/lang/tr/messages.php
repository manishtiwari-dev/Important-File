<?php

return [

    'created' =>'Başarıyla oluşturuldu.',
    'deleted' => 'Başarıyla silindi.',
    'multi_deleted' => 'Seçilenler başarıyla silindi.',
    'saved' => 'Başarıyla kaydedildi.',
    'deleted_failed' => 'Öğe silinmedi.',
    'multi_deleted_failed' => 'Seçili silinmedi.',
    'select_error' => 'Lütfen öğeleri seçin',
    'invalid' => 'Geçersiz Öğe',
    'invalid_code' => 'Geçersiz kod',
    'invalid_link' => 'Geçersiz link',
    'invalid_data' => 'Geçersiz veri',
    'assigned' => 'Başarıyla atandı.',
    'somthing_wrong' => 'Yanlış Bir Şey!',
    'demo_mode' => 'Bu eylem demo modunda devre dışı bırakıldı',
    'imported' => 'başarıyla içe aktarıldı.',
    'something_wrong' => 'Bir şeyler yanlış gitti',
    'check_item' => 'Lütfen şu anda yeni oluşturulan yeni öğeyi kontrol edin!',
    'paying_item' => 'Ürününüzü ödemek için bağlantı var!',
    'are_you_sure' => 'Emin misin!',

];