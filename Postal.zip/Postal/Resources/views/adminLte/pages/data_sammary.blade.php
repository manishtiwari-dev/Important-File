@extends('blog::adminLte.layouts.master')

@section('pageTitle')
    {{ __('blog::view.post_list') }}
@endsection

@section('content')
    
{{-- @php
print_r($response);
@endphp --}}

    <div class="container-fluid right_bar">
    <div class="row">
        <div class="col-md-11  col-sm-12">
            <div class="col-md-12">
                <h3>{{ __('postal::view.Riassunto_Dati_Raccomandata') }}</h3>
            </div>
            <div class="col-md-12 ">
                <div class="shadow p-3 rounded" style="padding-bottom: 50px !important;" >
                    <form action="{{ route("checkout") }}" method="post"> 
                    @csrf  
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-4">
                                <h5> {{ __('postal::view.Mittente') }}</h5>
                                    <div class="border p-3">
                                    @foreach ($response as $key=>$data)
                                        
                                        <strong>{{ $data->mittente->nome}}</strong><br>
                                        {{$data->mittente->dug }} {{$data->mittente->indirizzo}} , {{$data->mittente->civico}} <br>
                                        {{ $data->mittente->cap}} {{$data->mittente->comune}} <br>({{$data->mittente->provincia}})
                                    @endforeach
                                    </div>
                                </div>
                                <div class="col-sm-4 ">
                                <h5>{{ __('postal::view.Destinatario')}}</h5>
                                    <div class="border p-3">
                                    @foreach ($response as $key=>$data)
                                        <strong>{{ $data->destinatari[0]->nome}}</strong><br> 
                                        {{$data->destinatari[0]->dug }} {{$data->destinatari[0]->indirizzo}} , {{$data->destinatari[0]->civico}} <br>
                                        {{ $data->destinatari[0]->cap}} {{$data->destinatari[0]->comune}} <br>({{$data->destinatari[0]->provincia}}) 
                                    @endforeach
                                    </div>
                                </div>
                                <div class="col-sm-4 ">
                                <h5>{{ __('postal::view.Riepilogo') }}</h5>
                                    <div class="border p-3">
                                     @foreach ($response as $key=>$data)
                                        <h5>Dettaglio</h5>
                                        codice servizio:
                                        <strong>{{$data->pricing->dettaglio[0]->codice_servizio}}</strong> <br>
                                        descrizione servizio:
                                        <strong>{{$data->pricing->dettaglio[0]->descrizione_servizio}}</strong> <br>
                                        percentuale iva:
                                        <strong>{{$data->pricing->dettaglio[0]->percentuale_iva}} €</strong> <br>
                                        quantita:
                                        <strong>{{$data->pricing->dettaglio[0]->quantita}} €</strong> <br>
                                        importo unitario totale:
                                        <strong>{{$data->pricing->dettaglio[0]->importo_unitario_totale}} €</strong> <br>
                                        importo unitario netto:
                                        <strong>{{$data->pricing->dettaglio[0]->importo_unitario_netto}} €</strong> <br>
                                        importo unitario iva:
                                        <strong>{{$data->pricing->dettaglio[0]->importo_unitario_iva}} €</strong> <br><br>
                                        
                                        <h5>Totale</h5>
                                        importo totale netto: 
                                        <strong>{{$data->pricing->totale->importo_totale_netto}} €</strong> <br>
                                        importo totale iva:
                                        <strong>{{$data->pricing->totale->importo_totale_iva}} €</strong> <br>
                                        importo totale:
                                        <strong>{{$data->pricing->totale->importo_totale}} €</strong> <br>


                                        
                                    @endforeach
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 mt-3">
                                <h5> {{ __('postal::view.Contenuto_del_documento') }}</h5>
                                    <div class="border p-3 text-center">
                                         @foreach ($response as $key=>$data)
                                        <strong>{{ $data->documento[0]}}</strong>
                                        @endforeach
                                        {{-- <strong>{{ $response[0]->documento_validato->pdf}}</strong> --}}
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="p-3">
                                <input id="btn_submit" style="float:right;" type="submit" class="btn btn-block btn-primary col-sm-3 mt-3" value="{{ __('postal::view.ANTEPRIMA_DI_INVIO') }}"> 
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection
