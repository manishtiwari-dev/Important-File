
@extends('blog::adminLte.layouts.master')

@section('pageTitle')
    {{ __('blog::view.post_list') }}
@endsection

@section('content')

@php
 $sublist = Modules\Cargo\Entities\Subscription::where('user_id',auth()->user()->id)->get('payment_status');
@endphp

	<!--begin::Layout-->
	<div class="flex-row-fluid">

		<!--begin::Section-->
		<div class="row">
			<div class="col-md-7 col-lg-12 col-xxl-7">
				<!--begin::Engage Widget 14-->
				<div class="card card-custom card-stretch gutter-b">
					<div class="card-body">
						<div id="kt_header_mobile" class="header-mobile align-items-center header-mobile-fixed">
							<!--begin::Logo-->
							

							<!--end::Logo-->
						</div>
						<div class="mt-5 row mb-17">
							<div class="col-lg-8">
								<h1>{{ __('cargo::view.payment_gateway') }}  </h1>
								<div class="d-flex justify-content-between">
									<p>{{ __('postal::view.thank_you') }}</p>
									
									<a href="{{ aurl('/') }}">{{ __('cargo::view.back_to_dashboard') }}</a>
								</div>

								<p>Your Transaction Id Is:- </p>
								@if($payment == 0.80)
								<p>Download Payment Receipt <a href="{{$receipt}}">Download</a></p>
								@endif
									
							</div>
							
						</div>
					</div>
				</div>
				<!--end::Engage Widget 14-->

			</div>
		</div>
		<!--end::Section-->
		<!--begin::Section-->
		<!--begin::Advance Table Widget 10-->
		
		<!--end::Advance Table Widget 10-->
		<!--end::Section-->
	</div>
	<!--end::Layout-->
										
@endsection