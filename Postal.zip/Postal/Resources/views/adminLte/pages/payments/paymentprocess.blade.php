

@extends('cargo::adminLte.layouts.master')

@section('pageTitle')
    {{ __('cargo::view.plan_list') }}
@endsection

@section('content')
@php

  $user_role = auth()->user()->role;
    $client = 4;

$client_id = Modules\Cargo\Entities\Client::where('user_id',auth()->user()->id)->pluck('id')->first();
$transactions  = Modules\Cargo\Entities\Transaction::where('client_id', $client_id )->orderBy('created_at','desc')->sum('value');

$total_Amount = session()->get('total_Amount');

@endphp

    <form role="form" action="{{ route('stripepost') }}"  id="payment-form">
       @csrf
       <div class="card mb-3">
            <div class="card-header">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Choose a payment method</font></font></h3>
            </div>
            <div class="card-body">
                <!-- RADIO CONTAINER -->
                <div class="row">
                    <div class="col-md-6"> 
                    <h3>Pay Via Card</h3>
                        <div class="fdpago form-check col-12 col-sm-3" id="fp_tarjeta">
                            <input id="checkbox_metodo_pago_tarjeta" name="check_method_page" value="1" class="form-check-input coupon_question" type="radio" required="">

                            <label class="form-check-label col-12" for="checkbox_metodo_pago_tarjeta">
                                <img src="https://www.sendiroo.it/design/ngg/20180419/img/creacion_envio/credit_card.svg" width="200" alt="">
                               
                            </label>
                        </div>
                    </div>
                    @if (in_array($user_role, [$client]) )
                    <div class="col-md-6">
                    <h3>Pay Via Wallet</h3>
                        <div class="row">
                        @if($transactions > $total_Amount)
                            <span id="walletvalue">
                                <div class="col-md-12">
                                    <div class="fdpago form-check col-12 col-sm-3" id="fp_tarjeta">
                                    
                                        <input id="walletcheck" name="check_method_page" value="2" class="form-check-input coupon_question" type="radio" required="">
                                        <label class="form-check-label col-12" for="walletcheck">
                                            <img src="https://crm.genial.do/images/visa_blue.jpg" class="img-fluid w-100">
                                        </label>
                                    </div>
                                </div>
                            </span>
                        @else
                            <span id="rechargedata">
                                <div class="col-md-12">
                                    <h4>Insufficient credit balance in your Wallet Please Recharge now</h4>
                                    <a href="{{ route('topup') }}" class="mb-0 font-weight-bold text-light-75 text-hover-primary font-size-h5 btn btn-outline-warning" style="border: 1px solid #ffd104; font-size: 20px;">
                                                    <h6>Recharge</h6>
                                                </a>
                                </div>
                            </span>
                        @endif
                        </div>
                        
                    </div>
                    @endif

                </div>
                <div class="row w-50"  style="float:right;">
                    <div class="col-md-12">
                        <input  class="btn btn-primary col-md-10 mt-10" id="payment" type="submit" value="Pay Now"> 
                    </div>
                </div>
            </div>
        </div>
    </form>
<script>

  //   $( window ).on( "load", function() {
   //     $("#walletvalue").show();
   //     $("#rechargedata").hide();
   // });

//$("#payment").click(function(){
//  if($transactions < $datalist->plan_amount){
 //  alert("hii");
//  }
//});

</script>
@endsection