@php
$user_role = auth()->user()->role;
$admin  = 1;
$branch = 3;
$client = 4;
@endphp

@extends('cargo::adminLte.layouts.master')

@section('pageTitle')
{{ __('postal::view.postal_list') }}
@endsection

@section('content')
<style>
    .breadcrumb {
        float: right;
    }
    .transactions .head-area {
        padding-bottom: 20px;
    }

    .transactions .head-area h4 {
        font-weight: 700;
    }

    h4, h4 > a {
        font-size: 32px;
        line-height: 41.6px;
        margin-top: -8px;
    }

    .align-items-center {
        align-items: center!important;
    }

    .d-flex {
        display: flex!important;
    }

    .transactions .transactions-right form {
        margin-right: 15px;
    }

    .flex-fill {
        flex: 1 1 auto!important;
    }

    .transactions .transactions-right form .form-group {
        padding: 0 12px;
        background: #f9f9f9;
        border: 1px solid #d0d3e8;
        border-radius: 10px;
    }

    img {
        max-width: 100%;
        height: auto;
    }

    img, svg {
        vertical-align: middle;
    }

    .transactions .transactions-right form .form-group input {
        background-color: transparent;
        border: none;
        padding-left: 10px;
    }

    input, textarea {
        padding: 10px 20px;
        color: var(--para-color);
        width: 100%;
        font-family: var(--body-font);
        background: var(--bs-white);
        border: 1px solid #eeecf7;
        border-radius: 10px;
    }
    a, a:focus, a:hover {
        text-decoration: none;
        outline: none;
        color: var(--para-color);
    }
    a {
        display: inline-block;
        color: var(--para-color);
        font-weight: 400;
        font-size: 18px;
        line-height: 30px;
    }
    .transactions .transactions-right a {
        font-weight: 700;
        color: #5B2EDF;
    }

    .transactions .transactions-main {
        background: #FFF;
        border-radius: 10px;
    }

    .transactions .transactions-main .top-items {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #EFEFEF;
        padding: 30px 30px 20px;
    }

    .transactions .transactions-main .top-items h6 {
        font-weight: 700;
    }

    h6, h6 > a {
        font-size: 18px;
        line-height: 23.4px;
        margin-top: -4px;
    }

    ul, ol {
        padding: 0;
        margin: 0;
        list-style: none;
    }

    .transactions .transactions-main .top-items li {
        margin-left: 15px;
    }

    p, span, li, label {
        margin: 0;
        font-family: var(--body-font);
        font-size: 18px;
        font-weight: 400;
        color: var(--para-color);
        line-height: 30px;
    }

    .transactions .transactions-main .top-items li a {
        display: flex;
        align-items: center;
    }

    .transactions-main .top-items li a img {
        margin-right: 5px;
    }

    .transactions .transactions-main .filters-item {
        display: flex;
        align-items: center;
        padding: 30px;
    }

    .transactions .transactions-main .filters-item .single-item {
        margin-right: 15px;
    }

    .transactions select {
        padding: 10px 20px;
        border: solid 1px #e8e8e8;
        cursor: pointer;
        outline: none;
    }

    .transactions .transactions-main .filters-item .single-item .nice-select {
        border-radius: 10px;
    }

    .nice-select .list {
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 0 1px rgb(68 68 68 / 11%);
        box-sizing: border-box;
        margin-top: 4px;
        opacity: 0;
        overflow: hidden;
        padding: 0;
        pointer-events: none;
        position: absolute;
        top: 100%;
        left: 0;
        -webkit-transform-origin: 50% 0;
        -ms-transform-origin: 50% 0;
        transform-origin: 50% 0;
        -webkit-transform: scale(0.75) translateY(-21px);
        -ms-transform: scale(0.75) translateY(-21px);
        transform: scale(0.75) translateY(-21px);
        -webkit-transition: all 0.2s cubic-bezier(0.5, 0, 0, 1.25), opacity 0.15s ease-out;
        transition: all 0.2s cubic-bezier(0.5, 0, 0, 1.25), opacity 0.15s ease-out;
        z-index: 9;
    }

    .nice-select .option.selected {
        font-weight: bold;
    }

    .nice-select .option {
        cursor: pointer;
        font-weight: 400;
        line-height: 40px;
        list-style: none;
        min-height: 40px;
        outline: none;
        padding-left: 18px;
        padding-right: 29px;
        text-align: left;
        -webkit-transition: all 0.2s;
        transition: all 0.2s;
    }

    .transactions .transactions-main .filters-item .single-item .nice-select::after {
        height: 9px;
        width: 9px;
    }

    .nice-select:after {
        border-bottom: 2px solid #999;
        border-right: 2px solid #999;
        content: '';
        display: block;
        height: 5px;
        margin-top: -4px;
        pointer-events: none;
        position: absolute;
        right: 12px;
        top: 50%;
        -webkit-transform-origin: 66% 66%;
        -ms-transform-origin: 66% 66%;
        transform-origin: 66% 66%;
        -webkit-transform: rotate(45deg);
        -ms-transform: rotate(45deg);
        transform: rotate(45deg);
        -webkit-transition: all 0.15s ease-in-out;
        transition: all 0.15s ease-in-out;
        width: 5px;
    }

    .transactions .table {
        --bs-table-bg: transparent;
        --bs-table-accent-bg: transparent;
        --bs-table-striped-color: #212529;
        --bs-table-striped-bg: rgba(0, 0, 0, 0.05);
        --bs-table-active-color: #212529;
        --bs-table-active-bg: rgba(0, 0, 0, 0.1);
        --bs-table-hover-color: #212529;
        --bs-table-hover-bg: rgba(0, 0, 0, 0.075);
        width: 100%;
        margin-bottom: 1rem;
        color: #212529;
        vertical-align: top;
        border-color: #dee2e6;
    }

    .transactions .transactions-main .table-responsive thead {
        background: #F6F5FF;
    }

    .transactions .table>thead {
        vertical-align: bottom;
    }

    .transactions tbody, td, tfoot, th, thead, tr {
        border-color: inherit;
        border-style: solid;
        border-width: 0;
    }

    .transactions .transactions-main .table-responsive tr {
        text-align: center;
        border-top: 1px solid #EFEFEF;
    }
    .transactions .transactions-main .table-responsive thead tr th:first-child {
        text-align: start;
        width: 35%;
    }

    .transactions .transactions-main .table-responsive thead tr th {
        color: #696D8D;
        font-weight: 400;
    }

    .transactions .transactions-main .table-responsive tr th {
        padding: 15px 30px;
    }

    .table thead th, .table td, .table th {
        border: none;
    }

    .transactions .transactions-main .table-responsive tbody {
        border: none;
    }

    .transactions .transactions-main .table-responsive tbody tr th:first-child {
        text-align: start;
    }

    .transactions .transactions-main .table-responsive tr th p:first-child {
        font-weight: 700;
    }

    .mdr {
        font-size: 16px;
        line-height: 22px;
    }

    .mt-40 {
        margin-top: 40px;
    }

    .justify-content-center {
        justify-content: center!important;
    }
    .pagination p, .pagination span, .pagination li, .pagination label {
        margin: 0;
        font-family: var(--body-font);
        font-size: 18px;
        font-weight: 400;
        color: var(--para-color);
        line-height: 30px;
    }
    .pagination {
        display: flex;
        padding-left: 0;
        list-style: none;
    }
    .pagination li {
        margin: 0 5px;
    }
    .pagination .page-item, .pagination .page-link {
        width: 34px;
        height: 34px;
        background: #F8F8F8;
        border-radius: 10px;
        border: none;
        color: var(--para-color);
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .pagination .page-item:first-child, .pagination .page-item:last-child, .pagination .page-link:first-child, .pagination .page-link:last-child {
        border-radius: 10px;
    }

    .pagination .page-item:first-child, .pagination .page-item:last-child, .pagination .page-link:first-child, .pagination .page-link:last-child {
        border-radius: 10px;
    }

    .pagination .page-item, .pagination .page-link {
        width: 34px;
        height: 34px;
        background: #F8F8F8;
        border-radius: 10px;
        border: none;
        color: var(--para-color);
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .page-link {
        position: relative;
        display: block;
        color: #0d6efd;
        text-decoration: none;
        background-color: #fff;
        border: 1px solid #dee2e6;
        transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }

    .page-link {
        padding: 0.375rem 0.75rem;
    }

    .transactions .transactions-main .table-responsive tr td p:first-child {
        font-weight: 700;
    }
    .transactions .transactions-main .table-responsive tbody tr .inprogress {
        color: #DBAF14;
    }

    .transactions .transactions-main .table-responsive tbody tr .completed {
        color: #49C96D;
    }

    .transactions .transactions-main .table-responsive tbody tr .pending {
        color: #F7A94A;
    }

    .transactions .transactions-main .table-responsive tbody tr .cancelled {
        color: #E9687F;
    }

    .mb-40 {
        margin-bottom: 40px;
    }

    .pagination .page-item:hover, .pagination .page-item.active, .pagination .page-link:hover, .pagination .page-link.active {
        background-color: #5B2EDF;
        color: var(--bs-white);
    }
</style>


<div class="transactions">
    <div class="head-area">
        <div class="row">
            <div class="col-lg-5 col-md-4">
            </div>
            <div class="col-lg-7 col-md-8">
                <div class="transactions-right d-flex align-items-center">
                    <form action="#" class="flex-fill">
                        <div class="form-group d-flex align-items-center">
                            <img src="http://softalab.com/paylio/paylio-dashboard/assets/images/icon/search.png" alt="icon">
                            <input type="text" placeholder="Type to search...">
                        </div>
                    </form>
                    <a href="javascript:void(0)">Monthly Statement</a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-12">
            <div class="transactions-main">
                <div class="top-items">
                    <h6>Postal Transactions</h6>
                    <div class="export-area">
                        <ul class="d-flex align-items-center">
                            <li><a href="javascript:void(0)"><img src="http://softalab.com/paylio/paylio-dashboard/assets/images/icon/printer.png" alt="icon">Print</a></li>
                            <li><a href="javascript:void(0)"><img src="http://softalab.com/paylio/paylio-dashboard/assets/images/icon/excel.png" alt="icon">Excel</a></li>
                            <li><a href="javascript:void(0)"><img src="http://softalab.com/paylio/paylio-dashboard/assets/images/icon/pdf.png" alt="icon">PDF</a></li>
                            <li><a href="javascript:void(0)"><img src="http://softalab.com/paylio/paylio-dashboard/assets/images/icon/csv.png" alt="icon">CSV</a></li>
                        </ul>
                    </div>
                </div>
                <div class="filters-item">
                    <div class="single-item">
                        <select>
                            <option value="1">23 Nov 2021- 21 Feb 2022</option>
                            <option value="2">23 Feb 2021- 21 Mar 2022</option>
                            <option value="3">23 Mar 2021- 21 Apr 2022</option>
                        </select>
                        <!--<div class="nice-select" tabindex="0"><span class="current">23 Nov 2021- 21 Feb 2022</span><ul class="list"><li data-value="1" class="option selected">23 Nov 2021- 21 Feb 2022</li><li data-value="2" class="option">23 Feb 2021- 21 Mar 2022</li><li data-value="3" class="option">23 Mar 2021- 21 Apr 2022</li></ul></div>-->
                    </div>
                    <div class="single-item">
                        <select>
                            <option value="1">Balance</option>
                            <option value="2">Balance</option>
                            <option value="3">Balance</option>
                        </select>
                        <!--<div class="nice-select" tabindex="0"><span class="current">Balance</span><ul class="list"><li data-value="1" class="option selected">Balance</li><li data-value="2" class="option">Balance</li><li data-value="3" class="option">Balance</li></ul></div>-->
                    </div>
                    <div class="single-item">
                        <select>
                            <option>All Filters</option>
                            <option value="1">Filters 1</option>
                            <option value="2">Filters 2</option>
                            <option value="3">Filters 3</option>
                        </select>
                        <!--<div class="nice-select" tabindex="0"><span class="current">All Filters</span><ul class="list"><li data-value="All Filters" class="option selected">All Filters</li><li data-value="1" class="option">Filters 1</li><li data-value="2" class="option">Filters 2</li><li data-value="3" class="option">Filters 3</li></ul></div>-->
                    </div>
                    <div class="single-item">
                        <button class="btn btn-warning">Clear Filters</button>
                    </div>
                </div>
                <?php if (count($allTransaction) > 0) { ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Name/ Service Provider</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (count($allTransaction) > 0) {
                                    foreach ($allTransaction as $SingleTra) {
                                        $dateTime = explode(' ', $SingleTra->created_at);
                                        $time = $dateTime[1];
                                        $date = $dateTime[0];
                                        ?>
                                        <tr data-bs-toggle="modal" data-bs-target="#transactionsMod">
                                            <th scope="row">
                                                <p><?php echo ucfirst(auth()->user()->name); ?></p>
                                                <p class="mdr"><?php echo isset($SingleTra->service_provider) ? ucfirst($SingleTra->service_provider) : ''; ?></p>
                                            </th>
                                            <td>
                                                <p><?php echo date('h:i:s a', strtotime($time)); ?></p>
                                                <p class="mdr"><?php echo date('d M Y', strtotime($date)); ?></p>
                                            </td>
                                            <td>
                                                <?php if ($SingleTra->payment_status == 'success') {
                                                    ?>
                                                    <p class="completed">Success</p>
                                                <?php } else {
                                                    ?>
                                                    <p class="pending">Pending</p>
                                                <?php }
                                                ?>
                                            </td>
                                            <td>
                                                <p>&nbsp;&euro;<?php echo isset($SingleTra->final_amount) ? $SingleTra->final_amount : '0'; ?></p>
                                                <!--<p class="mdr">$3.0</p>-->
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <?php if (count($allTransaction) > 20) { ?>
                        <nav aria-label = "Page navigation" class = "d-flex justify-content-center mt-40">
                            <ul class = "pagination justify-content-center align-items-center mb-40">
                                <li class = "page-item">
                                    <a class = "page-link previous" href = "javascript:void(0)" aria-label = "Previous">
                                        <i class = "fa-solid fa-angles-left"></i>
                                    </a>
                                </li>
                                <li class = "page-item">
                                    <a class = "page-link previous" href = "javascript:void(0)" aria-label = "Previous">
                                        <i class = "fa-solid fa-angle-left"></i>
                                    </a>
                                </li>
                                <li class = "page-item"><a class = "page-link" href = "javascript:void(0)">1</a></li>
                                <li class = "page-item"><a class = "page-link active" href = "javascript:void(0)">2</a></li>
                                <li class = "page-item"><a class = "page-link" href = "javascript:void(0)">3</a></li>
                                <li class = "page-item"><a class = "page-link" href = "javascript:void(0)">...</a></li>
                                <li class = "page-item">
                                    <a class = "page-link next" href = "javascript:void(0)" aria-label = "Next">
                                        <i class = "fa-solid fa-angle-right"></i>
                                    </a>
                                </li>
                                <li class = "page-item">
                                    <a class = "page-link next" href = "javascript:void(0)" aria-label = "Next">
                                        <i class = "fa-solid fa-angles-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <?php
                    }
                    ?>
                <?php } else {
                    ?>
                    <h5 style="text-align: center;color: red;padding-bottom: 20px;">No transaction available to display.</h5>
                    <?php
                }
                ?> 
            </div>
        </div>
    </div>
</div>
@endsection
