@extends('users::adminLte.layouts.master')

@section('pageTitle')
    {{ __('postal::view.postal_transaction') }} - {{$model->name}}
@endsection

@section('content')
    

    <!--begin::Basic info-->
    <div class="card mb-5 mb-xl-10">
        <!--begin::Card header-->
        {{-- <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details"> --}}
        <div class="card-header">
            <!--begin::Card title-->
            <div class="card-title m-0">
                <h3 class="fw-bolder m-0">{{ __('postal::view.postal_transaction_details') }}</h3>
            </div>
            <!--end::Card title-->

           

        </div>
        <!--begin::Card header-->
        <div class="card-body p-9">

         <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.sender_data') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                    @foreach ($senderData as $key => $value)
                        <span class="fw-bolder fs-6 text-gray-800"> {{  ucfirst(strtolower($key)) }} : {{$value}} <br> </span>
                    @endforeach

                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->

                <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.destination_data') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                    @foreach ($destinationData as $key=>$value)
                        <span class="fw-bolder fs-6 text-gray-800">{{  ucfirst(strtolower($key)) }} : {{$value}}<br> </span>
                    @endforeach
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->

                 <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.billing_Details') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                    @foreach ($billingDetails as $key=>$value)
                        <span class="fw-bolder fs-6 text-gray-800">{{  ucfirst(strtolower($key)) }} : {{$value}} <br> </span>
                    @endforeach
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->


                <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.service_provider') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800">{{  $model->service_provider }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->


                <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.total_amount') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800"><i class="fa-solid fa-euro-sign"></i></i>{{ $model->total_Amount }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->


                <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.tax_amount') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800"><i class="fa-solid fa-euro-sign"></i></i>{{  $model->tax_amount }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->


                 <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.final_amount') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800"><i class="fa-solid fa-euro-sign"></i></i>{{  $model->final_amount }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->



                <!--begin::Row  Email -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.payment_method') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800">{{ $model->payment_method }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->


                <!--begin::Row  Full name -->
                <div class="row mb-7">
                    <!--begin::Label-->
                    <label class="col-lg-4 fw-bold text-muted">{{ __('postal::view.payment_status') }}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <span class="fw-bolder fs-6 text-gray-800">{{ $model->payment_status }}</span>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Row-->



                @if($model->role == 0)
                    @if (app('hook')->get('overview_user_profile'))
                        @foreach(app('hook')->get('overview_user_profile') as $componentView)
                            {!! $componentView !!}
                        @endforeach
                    @endif
                @endif


        </div>
        <!--begin::Card header-->
    </div>
    <!--end::Basic info-->

@endsection