@extends('blog::adminLte.layouts.master')

@section('pageTitle')
    {{ __('blog::view.post_list') }}
@endsection

@section('content')
    
{{-- @php

print_r($datakey);

@endphp --}}
<style>
    label.error {
         color: #dc3545;
         font-size: 14px;
    }
</style>

<div class="row">
  <div class="col-md-11  col-sm-12 mt-4">
    <form action="{{ route("getpost") }}" id="signupForm">
      @csrf
      <div class="shadow p-3 row rounded" style="padding-bottom: 50px !important;">
        <div class="col-md-6">
          <div class="border p-3">
            <h5>{{ __('postal::view.Mittente') }}</h5>
            <div class="row g-3 mt-2">
              <div class="col-md-6">
                  <label class="form-label">{{ __('postal::view.nome') }}</label>
                  <input class="form-control" id="" type="text" name="nome" placeholder="{{ __('postal::view.nome') }}" value="">
              </div>
              <div class="col-md-6">
                  <label class="form-label">{{ __('postal::view.cognome') }}</label>
                  <input class="form-control" id="" type="text" name="cognome" placeholder="{{ __('postal::view.cognome') }}" value="" >
              </div>
            </div>
            <div class="row g-3 mt-2">
                <div class="col-md-6">
                  <label class="form-label">{{ __('postal::view.ragione_sociale') }} </label>
                  <input class="form-control" id="" type="text" name="ragione" placeholder="{{ __('postal::view.ragione_sociale') }}" value="">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">{{ __('postal::view.email') }} </label>
                  <input class="form-control" id="" name="email" type="email" placeholder="{{ __('postal::view.email') }} " value="" >
                </div>
            </div>
            <div class="row  mt-2">
              <div class="col-md-4">
                  <label class="form-label">{{ __('postal::view.cap') }}</label>
                  <input class="form-control" id="cap" type="text" name="cap" placeholder="{{ __('postal::view.cap') }}" value="" >
              </div>
              <div class="col-md-8">
                  <label class="form-label">{{ __('postal::view.comune') }}*</label>
                      <select class="form-control" id="comune" name="comune"   disabled value=""  >
                        <option  selected >{{ __('postal::view.select_comune') }}</option>
                </select>
              </div>
            </div>
            <div class="row  mt-2">
              <div class="col-md-12 mb-3">
                <label class="form-label">{{ __('postal::view.Province') }}*</label>
                  <select class="form-control" id="provincia" disabled name="provincia" placeholder="" value=""  >
                  <option>{{ __('postal::view.select_province') }}</option>
                </select>
              </div>
            </div>
            <div class="row  mt-2">
              <div class="col-md-3">
                  <label class="form-label">{{ __('postal::view.Indirizzo') }}</label> 
                    <select class="form-control" id="" name="dug_mittente" >
                  <option>{{ __('postal::view.Select_Indirizzo') }}</option>
                  <option value="Borgo">Borgo</option>
                  <option value="Campo">Campo</option>
                  <option value="CDA">Contrada</option>
                  <option value="Corso">Corso</option>
                  <option value="CRO">Crocevia</option>
                  <option value="FRZ">Frazione</option>
                  <option value="GAL">Galleria</option>
                  <option value="Largo">Largo</option>
                  <option value="LOC">Località</option>
                  <option value="PGA">Piaggia</option>
                  <option value="PZA">Piazza</option>
                  <option value="PLE">Piazzale</option>
                  <option value="PZL">Piazzale</option>
                  <option value="PTA">Piazzetta</option>
                  <option value="Rione">Rione</option>
                  <option value="SLT">Salita</option>
                  <option value="SZO">Spiazzo</option>
                  <option value="STR">Strada</option>
                  <option value="SST">Strada Statale</option>
                  <option selected value="TRV">Traversa</option>
                  <option value="Via">Via</option>
                  <option value="Viale">Viale</option>
                  <option value="VLO">Vicolo</option>
                </select>
              </div>
              <div class="col-md-6">
                  <label class="form-label">&nbsp;</label>
                  <input class="form-control" id="" type="text" name="indirizzo_mittente" placeholder="{{ __('postal::view.Indirizzo') }}" value="">
              </div>
              <div class="col-md-3">
                  <label class="form-label">{{ __('postal::view.civico') }}*</label>
                  <input class="form-control" id="" type="number" name="civico" placeholder="{{ __('postal::view.civico') }}" value="" >
              </div>
            </div> 
            
          </div>
      
        </div>
        <div class="col-md-6">
          <div class="border p-3">
            <h5>{{ __('postal::view.Destinatario_Singolo') }}</h5>
            <div class="row g-3 mt-2">
                <div class="col-md-6">
                  <label class="form-label">{{ __('postal::view.nome') }} </label>
                  <input class="form-control" id="" type="text" name="destinatario_nome" placeholder="{{ __('postal::view.nome') }}" value="">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">{{ __('postal::view.apellido_razón_social') }}*</label>
                  <input class="form-control" id="" name="destinatario_cognome" type="text" placeholder="{{ __('postal::view.apellido_razón_social') }}" value=" " >
                </div>
            </div>
            <div class="row  mt-2">
              <div class="col-md-12">
                  <label class="form-label">{{ __('postal::view.presso') }} (c/o)</label>
                  <input class="form-control" id="" type="text" name="destinatario_presso" placeholder="" value="" >
              </div>
              
            </div>
            <div class="row  mt-2">
            <div class="col-md-4">
                  <label class="form-label">{{ __('postal::view.cap') }}</label>
                  <input class="form-control" id="capcode" type="text" name="destinatario_cap" placeholder="{{ __('postal::view.cap') }}" >
              </div>
              <div class="col-md-8 mb-3">
                <label class="form-label">{{ __('postal::view.comune') }}*</label>
                
                <select class="form-control" disabled id="comunecode" name="destinatario_comune" value="" >
                  <option>Select</option>txtDate
                </select>
              </div>
            </div>
            <div class="row  mt-2">
              <div class="col-md-12">
                  <label class="form-label">{{ __('postal::view.Province') }}*</label>
                  <select class="form-control" id="provinciacode" name="destinatario_provincia" disabled placeholder="" value=""  >
                  <option>{{ __('postal::view.select_province') }}</option>
                </select>
              </div>
              
            </div> 
              <div class="row  mt-2">
                <div class="col-md-12">
                  <div class="row  mt-2">
                      <div class="col-md-3">
                      <label class="form-label">{{ __('postal::view.Indirizzo') }}*</label> 
                      <select class="form-control" id="" name="destinatario_dug_mittente" >
                      <option>{{ __('postal::view.Select_Indirizzo') }}</option>
                      <option value="Borgo">Borgo</option>
                      <option value="Campo">Campo</option>
                      <option value="CDA">Contrada</option>
                      <option value="Corso">Corso</option>
                      <option value="CRO">Crocevia</option>
                      <option value="FRZ">Frazione</option>
                      <option value="GAL">Galleria</option>
                      <option value="Largo">Largo</option>
                      <option value="LOC">Località</option>
                      <option value="PGA">Piaggia</option>
                      <option value="PZA">Piazza</option>
                      <option value="PLE">Piazzale</option>
                      <option value="PZL">Piazzale</option>
                      <option value="PTA">Piazzetta</option>
                      <option value="Rione">Rione</option>
                      <option value="SLT">Salita</option>
                      <option value="SZO">Spiazzo</option>
                      <option value="STR">Strada</option>
                      <option value="SST">Strada Statale</option>
                      <option value="TRV">Traversa</option>
                      <option selected value="Via">Via</option>
                      <option value="Viale">Viale</option>
                      <option value="VLO">Vicolo</option>
                    </select>
                  </div>
                  <div class="col-md-6">
                      <label class="form-label">&nbsp;</label>
                      <input class="form-control" id="" type="text" name="destinatario_indirizzo_mittente" placeholder="{{ __('postal::view.Indirizzo') }}" value="">
                  </div>
                  <div class="col-md-3">
                      <label class="form-label">{{ __('postal::view.civico') }}*</label>
                      <input class="form-control" id="" type="number" name="destinatario_civico" placeholder="{{ __('postal::view.civico') }} " value="" >
                  </div>
                </div>
              </div>
            </div> 
          </div>
      
        </div>
        <div class="col-md-6 mt-5">
          <div class="border p-3">
            <h5>{{ __('postal::view.componi_messaggio') }}</h5>
            <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
              <li class="nav-item" role="presentation">
                <a class="nav-link active" data-bs-toggle="tab" href="#primaryhome" role="tab" aria-selected="true">
                <div class="d-flex align-items-center">
                  <div class="tab-icon"><i class='bx bx-conversation'></i>
                  </div>
                  <div class="tab-title">{{ __('postal::view.componi_messaggio') }}</div>
                </div>
              </a>
              </li>

              <li class="nav-item" role="presentation">
              <a class="nav-link" data-bs-toggle="tab" href="#primaryprofile" role="tab" aria-selected="false">
                <div class="d-flex align-items-center">
                  <div class="tab-icon"><i class='bx bx-user-pin font-18 me-1'></i>
                  </div>
                  <div class="tab-title">{{ __('postal::view.Allega_Documenti') }}</div>
                </div>
              </a>
              </li>
              </ul>

              <div class="tab-content py-3">
              <div class="tab-pane fade show active" id="primaryhome" role="tabpanel">
                <textarea class="form-control editor" id="testo" name="testo" rows="3"></textarea>
              </div> 
              <div class="tab-pane fade" id="primaryprofile" role="tabpanel">
                {{ __('postal::view.file_upload') }} <br/> <br/>
{{-- 
                  <x-media-library-attachment  name="media" fields-view="uploads.blade.partials.fields" rules="mimes:jpg,jpeg,png,gif,pdf,bmp,svg,webp"/> --}}
                  <x-media-library-attachment name="image" rules="mimes:png,jpeg,pdf|max:1024"/>

              </div>
              
            </div> 

          </div>
        </div>
        <div class="col-md-6 mt-5">
          <div class="border p-3 nav nav-tabs">
            <h5>{{ __('postal::view.opzioni_aggiuntive') }}</h5>
              @foreach($datakey as $key => $value)
                <div class="col-lg-12">
                  <input id="ricevuta_invio_poste" class="option" type="radio" value="{{$value->tipologia}}" name="ricevuta_invio_poste">
                  <strong> {{ $value->descrizione }} </strong><br/>
                    
                </div>
              @endforeach
              <br><br>
              <p>{{ __('postal::view.for_receipt_please_choose') }}</p> 
                <div class="col-lg-12">
                  <input id="ricevuta_invio_poste" class="option" type="radio" value="0.80" name="return_receipt">
                  <strong> Return receipt +0.80 € </strong><br/>
                  <p>{{ __('postal::view.delivery_confirmation_registered_shipment') }}</p>
                </div>
            </div> 
          </div>
          <button type="submit" class="btn btn-block btn-primary col-sm-3 mt-3">{{ __('postal::view.ANTEPRIMA_DI_INVIO') }}</button>
        </div>
        
      </div>
      
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script type="text/javascript">
            $('#cap').on("keyup",function() {
              $('#comune').attr('disabled', false);
              $('#provincia').attr('disabled',false)
              const data = [];
              var postCode = $(this).val();
              var capResponse = pData = '';
            
              if(postCode.length >4)
                capResponse = $.parseJSON(changeUserStatus(postCode));

                pData = capResponse.data[0];

                var comune = '<option value="'+pData.comuni+'">'+pData.comuni+'</option>';

                var provincia ='<option value="'+pData.sigla_provincia+'">'+pData.nome_provincia+' ( '+ pData.sigla_provincia +')</option>';

                $("#provincia").html('');
                $("#provincia").append(provincia);
                $("#comune").html('');
                $("#comune").append(comune);

              
            });

            $('#capcode').on("keyup",function() {
              $('#comunecode').attr('disabled', false);
              $('#provinciacode').attr('disabled',false)
              var postCode = $(this).val();

              if(postCode.length >4)
              var capcodeResponse = $.parseJSON(changeUserStatus(postCode));


              pData =  capcodeResponse.data[0];

                var comune = '<option value="'+pData.comuni+'">'+pData.comuni+'</option>';

                var provincia ='<option value="'+pData.sigla_provincia+'">'+pData.nome_provincia+' ( '+ pData.sigla_provincia +')</option>';

                $("#provinciacode").html('');
                $("#provinciacode").append(provincia);
                $("#comunecode").html('');
                $("#comunecode").append(comune);


            });



            function changeUserStatus(postCode) {

                var pData = [];
                var url = '{{ route('getPostalDetails') }}';
                return ( $.ajax({
                    type: 'GET',
                    url: url,
                    data: 'post_code='+postCode+'&_token={{ csrf_token() }}',
                    dataType:'json',
                    global: false,
                    async: false,
                    success: function (response) {
                    }
                }).responseText);
            }
        </script>
        
        {{-- <script>
          $('#data_invio').datepicker();
          $('#data_invio').datepicker('setDate', 'today');
        </script> --}}
        <script>
            $().ready(function () {
 
            $("#signupForm").validate({
                // in 'rules' user have to specify all the constraints for respective fields
                rules: {
                    nome: "required",
                    cognome: "required",
                    ragione: "required",
                    cap: "required",
                    comune: "required",
                    provincia: "required",
                    dug_mittente: "required",
                    indirizzo_mittente: "required",
                    civico: "required",
                    destinatario_nome: "required",
                    destinatario_cognome: "required",
                    destinatario_presso: "required",
                    destinatario_cap: "required",
                    destinatario_comune: "required",
                    destinatario_provincia: "required",
                    destinatario_dug_mittente: "required",
                    destinatario_indirizzo_mittente: "required",
                    destinatario_civico: "required",
                    email: {
                        required: true,
                        email: true
                    },
                },
                // in 'messages' user have to specify message as per rules
                messages: {
                    nome: "Questo campo è obbligatorio",
                    cognome: "Questo campo è obbligatorio",
                    ragione: "Questo campo è obbligatorio",
                    cap: "Questo campo è obbligatorio",
                    comune: "Questo campo è obbligatorio",
                    provincia:"Questo campo è obbligatorio",
                    dug_mittente: "Questo campo è obbligatorio",
                    indirizzo_mittente: "Questo campo è obbligatorio",
                    civico: "Questo campo è obbligatorio",
                    destinatario_nome: "Questo campo è obbligatorio",
                    destinatario_cognome: "Questo campo è obbligatorio",
                    destinatario_presso: "Questo campo è obbligatorio",
                    destinatario_cap: "Questo campo è obbligatorio",
                    destinatario_comune: "Questo campo è obbligatorio",
                    destinatario_provincia: "Questo campo è obbligatorio",
                    destinatario_dug_mittente: "Questo campo è obbligatorio",
                    destinatario_indirizzo_mittente: "Questo campo è obbligatorio",
                    destinatario_civico: "Questo campo è obbligatorio",
                    email:"Questo campo è obbligatorio",
                }
            });
        });
 
    </script>


<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.4.0/mdb.min.js"
></script>

@endsection

