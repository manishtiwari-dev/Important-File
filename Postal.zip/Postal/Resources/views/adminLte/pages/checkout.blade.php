@extends('blog::adminLte.layouts.master')

@section('pageTitle')
    {{ __('blog::view.post_list') }}
@endsection

@section('content')


<div class="row">
        <div class="col-md-12  col-sm-12 mt-4">
        
            <div class="shadow p-3 row rounded" style="padding-bottom: 50px !important;">
            
            
              <div class="col-md-8">
               <form id="postal-payment-form" action="{{ route('paymentpost') }}" class="sr-payment-form">

                @php
                  $c_details = $checkoutdata['data']->mittente;
                  
                @endphp 
                <div class="border p-3">
                  <h5> {{ __('postal::view.I_TUOI_DATI') }}</h5>
                  <div class="row g-3 mt-2">
                     <div class="col-md-3">
                        <input type="radio" name="customer" id="customer"/>{{ __('postal::view.Privato') }}
                     </div>
                      <div class="col-md-3">
                        <input type="radio" name="customer" id="customer1"/> {{ __('postal::view.Azienda') }}
                     </div>
                  </div>
                  <div class="row g-3 mt-2">

                  <span id="privato">
                    <div class="row g-3 mt-2">
                      <div class="col-md-6">
                          <label class="form-label">{{ __('postal::view.nome') }}</label>
                          <input class="form-control" id="" type="text" name="nome" placeholder="{{ __('postal::view.nome') }}" value="{{ $c_details->nome}}">
                      </div>

                      
                      <div class="col-md-6">
                          <label class="form-label">{{ __('postal::view.cognome') }}</label>
                          <input class="form-control" id="" type="text" name="cognome" placeholder="{{ __('postal::view.cognome') }}" value="{{ $c_details->cognome}}" >
                      </div>
                    </div>
                  </span>
                  <span id="azienda">
                    <div class="row g-3 mt-2">
                      <div class="col-md-12">
                          <label class="form-label">{{ __('postal::view.vat_number') }}</label>
                          <input class="form-control" id="" type="text" name="vat_number" value="">
                      </div>

                      
                      <div class="col-md-6">
                          <label class="form-label">{{ __('postal::view.company_name') }}</label>
                          <input class="form-control" id="" type="text" name="comapany_name" value="" >
                      </div>
                      <div class="col-md-6">
                          <label class="form-label">{{ __('postal::view.pec_or_sdi_cde') }}</label>
                          <input class="form-control" id="" type="text" name="sdi_code" value="" >
                      </div>
                      </div>
                  </span>
                  </div>
                  <div class="row g-3 mt-2">
                    <div class="col-md-8">
                        <label class="form-label">{{ __('postal::view.email') }}</label>
                        <input class="form-control" id="" type="email" name="email" placeholder="{{ __('postal::view.email') }}" value="{{ $c_details->email}}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">{{ __('postal::view.Cellulare') }}</label>
                        <input class="form-control" id="" type="text" name="cellulare" placeholder="{{ __('postal::view.Cellulare') }}" value="" >
                    </div>
                  </div>
                  <div class="row g-3 mt-2">
                    <div class="col-md-9">
                        <label class="form-label">{{ __('postal::view.Indirizzo') }}</label>
                        <input class="form-control" id="" type="text" name="indirizzo" placeholder="" value="{{$c_details->dug }} {{$c_details->indirizzo}} {{$c_details->civico}}">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">{{ __('postal::view.cap') }}</label>
                        <input class="form-control" id="" type="text" name="cap" placeholder="" value="{{ $c_details->cap}}" >
                    </div>
                  </div>
                  <div class="row  mt-2">
                    <div class="col-md-6">
                        <label class="form-label">{{ __('postal::view.Città') }}</label> 
                         <select class="form-control" id="" name="citta" >
                        <option>{{$c_details->comune}}</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">{{ __('postal::view.Nazione') }}</label> 
                         <select class="form-control" id="" name="nazione" >
                         <option selected value="IT">Italy</option>
                      </select>
                    </div>
                   
                  </div> 
                </div>
               
              </div>

              <div class="col-md-4">
                <div class="border p-3">
                  <h5>{{ __('postal::view.purchase_summary') }}</h5>
                  
                    <table class="table table-sm subscription-price-preview-table mt-3">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">{{ __('postal::view.Qtà') }}</th>
                            <th scope="col">{{ __('postal::view.description') }}</th>
                            <th scope="col">{{ __('postal::view.iva') }}</th>
                            <th scope="col">{{ __('postal::view.eur') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach ($checkoutdata['data']->pricing->dettaglio as $key => $data)
                            <tr>
                                <td scope="col">{{$data->quantita}}</td>
                                <td scope="col">codice servizio-{{$data->codice_servizio}}</td>
                                <td scope="col">{{$data->percentuale_iva}}%</td>
                                <td scope="col">€{{$data->importo_unitario_totale}}</td>
                            </tr>
                        @endforeach
                        @if($payment == 0.80)
                            <tr>
                                <td scope="col"></td>
                                <td scope="col">receipt amount</td>
                                <td scope="col"></td>
                                <td scope="col">0.80</td>
                            </tr>
                        @endif
                             <tr>
                                <td scope="col"></td>
                                <td scope="col"><strong>{{ __('postal::view.total') }}</strong></td>
                                <td scope="col"></td>
                                 @if($payment == 0.80)
                                <td scope="col"><strong>€{{ $checkoutdata['data']->pricing->totale->importo_totale+0.80}}</strong></td>
                                @else
                                 <td scope="col"><strong>€{{ $checkoutdata['data']->pricing->totale->importo_totale}}</strong></td>
                                 @endif
                            </tr>

                            
                        
                        </tbody>
                    </table>
                    
                     @php
                      $c_details = $checkoutdata['data']->mittente;
                      
                    @endphp 
                        <h4 style="margin: 0px; cursor: default;">{{ __('postal::view.I_TUOI_DATI') }}</h4>
                        <ul style="list-style: none; padding-left: 0px; font-size: 12px; margin-bottom: 30px; cursor: default;">
                        <li style="cursor: default;"><strong style="cursor: default;">{{ __('postal::view.email') }}</strong> {{ $c_details->email}}</li>
                        <li style="cursor: default;"><strong style="cursor: default;">{{ __('postal::view.Cellulare') }}</strong> - </li>
                        <li style="cursor: default;"><strong style="cursor: default;">{{ __('postal::view.Indirizzo') }}</strong> - {{$c_details->dug }} {{$c_details->indirizzo}} {{$c_details->civico}} {{ $c_details->cap}} - {{$c_details->comune}} - {{$c_details->provincia}}</li>
                        <ul style="cursor: default;"></ul>
                        </ul>
                        

                </div>
                 
              </div>
              <div class="col-md-8">
              </div>
            <div class="col-md-4 mt-5" style="float:right;">
                <button class="btn btn-primary text-center w-100" style="float:right;" type="submit" id="postal-card-submit-btn">{{ __('postal::view.proceed_to_payment') }}</button>
              </div>
             </form>
             
        </div>
        
</div>
      

<script>
 $( window ).on( "load", function() {
        $("#privato").show();
         $("#azienda").hide();
    });

$("#customer").click(function(){
  $("#privato").show();
  $("#azienda").hide();
});

$("#customer1").click(function(){
  $("#privato").hide();
  $("#azienda").show();
});

</script>


@endsection