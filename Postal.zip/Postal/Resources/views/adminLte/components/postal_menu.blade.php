@php
    $user_role = auth()->user()->role;
    $admin = 1;
    $staff = 0;
    $branch = 3;
    $client = 4;
    $driver = 5;
@endphp

@if (auth()->user()->can('add-covered-countries') || $user_role == $admin || $user_role == $client)
    <li class="nav-item  {{ areActiveRoutes(['postal.index'], 'menu-is-opening menu-open active') }}">
        <a href="{{ fr_route('shipments.postal') }}"
            class="nav-link {{ areActiveRoutes(['postal.index'], 'menu-is-opening menu-open active') }}">
            <i class="fas fa-plus fa-fw"></i>
            {{ __('postal::view.create_new_postal') }}
        </a> 
    </li>
@endif

@if (auth()->user()->can('add-covered-countries') || $user_role == $admin || $user_role == $client)
    <li class="nav-item  {{ areActiveRoutes(['postal.index'], 'menu-is-opening menu-open active') }}">
        <a href="{{ fr_route('postal.index') }}"
            class="nav-link {{ areActiveRoutes(['postal.index'], 'menu-is-opening menu-open active') }}">
            <i class="fas fa-list fa-fw"></i>
            {{ __('postal::view.postal_list') }}
        </a> 
    </li>
@endif





