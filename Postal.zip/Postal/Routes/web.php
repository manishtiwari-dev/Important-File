<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
if (\Illuminate\Support\Facades\Schema::hasTable('translations') && check_module('localization')) {
    Route::group(
        [
            'prefix' => LaravelLocalization::setLocale(),
            'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]
        ], function(){
            
    Route::prefix('postal')->group(function() {
        Route::get('/', 'PostalController@index')->name('postal.index');
        
        Route::resource('postal','PostalController');

        Route::get('postal','PostalShipmentController@postalshippment')->name('shipments.postal');
        Route::get('/postalcode', 'PostalShipmentController@getPostalDetails')->name('getPostalDetails');
        Route::get('/getpost', 'PostalShipmentController@getpost')->name('getpost');
        Route::post('/checkout', 'PostalShipmentController@checkout')->name('checkout');


        //Stipe Start.

        Route::get('paymentProcess', 'StripePaymentController@paymentProcess')->name('paymentpost');
        Route::get('stripe', 'StripePaymentController@paymentMethod')->name('stripepost');
        Route::post('/stripe/create-checkout-session', 'StripePaymentController@create_checkout_session')->name('stripe.get_token');
        Route::any('/stripe/payment/callback', 'StripePaymentController@callback')->name('stripe.callback');
        Route::get('/stripe/success', 'StripePaymentController@success')->name('stripe.success');
        Route::get('/stripe/cancel', 'StripePaymentController@cancel')->name('stripe.cancel');
        //Stripe END
  
    });
});
}else{



}