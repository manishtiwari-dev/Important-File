<?php

namespace Modules\Postal\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Cargo\Entities\Branch;
use Modules\Cargo\Entities\Client;
use Modules\Cargo\Entities\Driver;
use Modules\Cargo\Entities\Staff;
use Spatie\Image\Manipulations;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Postal extends Model implements HasMedia
{
    use HasFactory;
    use InteractsWithMedia;


    protected $fillable = [];
    protected $guarded = [];
    protected $table = 'postals';

    public function getPostal($query)
    {
        $postal = $query;
        

        $user_role = auth()->user()->role;
        if(isset($user_role))
        {
            if($user_role == 4){
                $postal = Postal::where('created_by', auth()->user()->id);
            
            }


        } 


        return $postal;
    }
  
}
